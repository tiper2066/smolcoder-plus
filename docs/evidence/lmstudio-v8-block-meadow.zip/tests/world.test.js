import { test } from 'node:test';
import assert from 'node:assert/strict';
import { World } from '../src/world/world.js';
import { GRASS, DIRT, STONE, WOOD, LEAVES, WATER, AIR } from '../src/world/blocks.js';
import { Player, aabbIntersectsBlock, clampDT } from '../src/world/player.js';
import { raycast } from '../src/world/raycast.js';
import {
  saveWorld, loadWorld, saveMeta, loadMeta, clearSave, SAVE_KEYS
} from '../src/persistence.js';

// Minimal localStorage shim for Node tests
class MemStorage {
  constructor() { this.m = new Map(); }
  getItem(k) { return this.m.has(k) ? this.m.get(k) : null; }
  setItem(k, v) { this.m.set(k, String(v)); }
  removeItem(k) { this.m.delete(k); }
  clear() { this.m.clear(); }
}
globalThis.localStorage = new MemStorage();
globalThis.atob = (s) => Buffer.from(s, 'base64').toString('binary');
globalThis.btoa = (s) => Buffer.from(s, 'binary').toString('base64');

test('world is at least 48x48 and deterministic per seed', () => {
  const a = new World(42);
  const b = new World(42);
  assert.ok(a.size.x >= 48 && a.size.z >= 48);
  assert.ok(a.blocks.length === b.blocks.length);
  for (let i = 0; i < a.blocks.length; i += 997) {
    assert.equal(a.blocks[i], b.blocks[i]);
  }
  const c = new World(43);
  let diff = false;
  for (let i = 0; i < a.blocks.length; i += 13) {
    if (a.blocks[i] !== c.blocks[i]) { diff = true; break; }
  }
  assert.ok(diff, 'different seeds should produce different terrain');
});

test('terrain has grass/dirt/stone layers, a lake and trees', () => {
  const w = new World(42);
  let grass = 0, dirt = 0, stone = 0, water = 0, wood = 0, leaves = 0;
  for (let i = 0; i < w.blocks.length; i++) {
    switch (w.blocks[i]) {
      case GRASS: grass++; break;
      case DIRT: dirt++; break;
      case STONE: stone++; break;
      case WATER: water++; break;
      case WOOD: wood++; break;
      case LEAVES: leaves++; break;
    }
  }
  assert.ok(grass > 0, 'has grass');
  assert.ok(dirt > 0, 'has dirt');
  assert.ok(stone > 0, 'has stone');
  assert.ok(water > 0, 'has water (lake)');
  assert.ok(wood > 0, 'has wood (trees)');
  assert.ok(leaves > 0, 'has leaves');
});

test('block bounds: out-of-range reads return AIR, writes rejected', () => {
  const w = new World(42);
  assert.equal(w.getBlock(-1, 0, 0), AIR);
  assert.equal(w.getBlock(0, -1, 0), AIR);
  assert.equal(w.getBlock(0, 0, -1), AIR);
  assert.equal(w.getBlock(w.size.x, 0, 0), AIR);
  assert.equal(w.getBlock(0, w.size.y, 0), AIR);
  assert.equal(w.getBlock(0, 0, w.size.z), AIR);
  assert.equal(w.setBlock(-1, 0, 0, STONE), false);
  assert.equal(w.setBlock(w.size.x, 0, 0, STONE), false);
  assert.equal(w.tryPlace(w.size.x, 0, 0, STONE).ok, false);
  assert.equal(w.tryPlace(-1, 0, 0, STONE).ok, false);
});

test('edit persistence: serialize -> deserialize roundtrip preserves edits', () => {
  const w = new World(42);
  const sx = 5, sz = 5;
  const sy = w.surfaceHeight(sx, sz);
  w.tryPlace(sx, sy + 1, sz, WOOD);
  w.tryPlace(sx, sy + 2, sz, WOOD);
  w.tryRemove(sx, sy, sz);
  const before = { editCount: w.editCount };
  const ser = w.serialize();
  const w2 = World.deserialize(ser);
  assert.equal(w2.getBlock(sx, sy, sz), AIR, 'removed block stays removed');
  assert.equal(w2.getBlock(sx, sy + 1, sz), WOOD);
  assert.equal(w2.getBlock(sx, sy + 2, sz), WOOD);
  assert.equal(w2.editCount, before.editCount);
});

test('persistence module: save/load world and meta, invalid data safe', () => {
  clearSave();
  const w = new World(7);
  const sy = w.surfaceHeight(3, 3);
  w.tryPlace(3, sy + 1, 3, LEAVES);
  assert.ok(saveWorld(w));
  const loaded = loadWorld();
  assert.ok(loaded instanceof World);
  assert.equal(loaded.getBlock(3, sy + 1, 3), LEAVES);

  assert.ok(saveMeta({ selected: STONE, player: { x: 1, y: 2, z: 3 } }));
  const m = loadMeta();
  assert.equal(m.selected, STONE);
  assert.deepEqual(m.player, { x: 1, y: 2, z: 3 });

  // invalid data must not crash
  localStorage.setItem(SAVE_KEYS.world, '{not json');
  assert.equal(loadWorld(), null);
  localStorage.setItem(SAVE_KEYS.world, JSON.stringify({ v: 99, blocks: 'xx' }));
  assert.equal(loadWorld(), null);
  localStorage.setItem(SAVE_KEYS.meta, 'garbage');
  assert.equal(loadMeta(), null);
});

test('collision: player cannot pass through solid blocks', () => {
  const w = new World(42);
  const x = Math.floor(w.size.x / 2), z = Math.floor(w.size.z / 2);
  const h = w.surfaceHeight(x, z);
  const p = new Player(w, x + 0.5, h + 1.0, z + 0.5);
  // stand on ground, gravity should keep grounded
  p.update(1 / 60, {});
  assert.ok(p.y >= h + 0.99, 'feet stay at/above ground top');
  assert.ok(p.grounded, 'player is grounded on the surface');
});

test('jump: grounded jump lifts player, gravity brings back down', () => {
  const w = new World(42);
  const x = Math.floor(w.size.x / 2), z = Math.floor(w.size.z / 2);
  const h = w.surfaceHeight(x, z);
  const p = new Player(w, x + 0.5, h + 1.0, z + 0.5);
  p.update(1 / 60, {}); // settle
  const y0 = p.y;
  p.update(1 / 60, { jump: true });
  const y1 = p.y;
  assert.ok(y1 > y0, 'jump raises the player');
  assert.ok(!p.grounded, 'airborne after jump');
  // let gravity bring back down
  let grounded = false;
  for (let i = 0; i < 200; i++) {
    p.update(1 / 60, {});
    if (p.grounded) { grounded = true; break; }
  }
  assert.ok(grounded, 'player lands back on ground');
  assert.ok(Math.abs(p.y - (h + 1)) < 0.05, 'returns to ground level');
});

test('clampDT limits large frame deltas (background tab resume)', () => {
  assert.equal(clampDT(0.016), 0.016);
  assert.equal(clampDT(5), 0.05);
  assert.equal(clampDT(NaN), 0);
  assert.equal(clampDT(-1), 0);
});

test('wall collision: player cannot enter a solid block column', () => {
  const w = new World(42);
  const x = Math.floor(w.size.x / 2), z = Math.floor(w.size.z / 2);
  const h = w.surfaceHeight(x, z);
  // build a 1x3x1 wall in front of the player
  w.setBlock(x, h + 1, z + 2, STONE);
  w.setBlock(x, h + 2, z + 2, STONE);
  w.setBlock(x, h + 3, z + 2, STONE);
  const p = new Player(w, x + 0.5, h + 1.0, z + 0.5);
  p.update(1 / 60, {});
  // walk toward the wall (positive z direction)
  for (let i = 0; i < 60; i++) p.update(1 / 60, { dx: 0, dz: 1 });
  // player should not have passed through the block at z+2 (block occupies z+2..z+3)
  // player front face must stay before z+2
  assert.ok(p.z + 0.3 < z + 2 + 0.01, `player stopped before wall (z=${p.z})`);
  assert.ok(p.z > z + 0.5, `player moved toward wall (z=${p.z})`);
});

test('aabbIntersectsBlock detects player-body overlap for placement', () => {
  // player at (10.5, 20, 10.5) with height 1.8 covers y 20..21.8
  assert.equal(aabbIntersectsBlock(10, 20, 10, 10.5, 20, 10.5), true);
  assert.equal(aabbIntersectsBlock(10, 22, 10, 10.5, 20, 10.5), false);
  assert.equal(aabbIntersectsBlock(12, 20, 10, 10.5, 20, 10.5), false);
});

test('raycast finds the block in front and reports face for placement', () => {
  const w = new World(42);
  const x = Math.floor(w.size.x / 2), z = Math.floor(w.size.z / 2);
  const h = w.surfaceHeight(x, z);
  // player looking straight at the surface block from above
  const hit = raycast(w, { x: x + 0.5, y: h + 10, z: z + 0.5 }, { x: 0, y: -1, z: 0 }, 20);
  assert.ok(hit, 'raycast hit something');
  assert.equal(hit.x, x);
  assert.equal(hit.y, h);
  assert.equal(hit.z, z);
  assert.deepEqual(hit.face, { x: 0, y: 1, z: 0 }, 'face is +Y (top)');
});

test('raycast returns null when looking into open sky', () => {
  const w = new World(42);
  const hit = raycast(w, { x: 1, y: 100, z: 1 }, { x: 0, y: 1, z: 0 }, 10);
  assert.equal(hit, null);
});

test('faceBuilder: all rendered faces are wound CCW against their stored normal', async () => {
  const { buildExposedFaces } = await import('../src/render/faceBuilder.js');
  const w = new World(1);
  // Place a stone block in an air cell above the terrain so all 6 faces are exposed.
  // Find an air cell whose 6 face-neighbors are all air (fully isolated).
  let cell = null;
  const neighbors = [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]];
  outer: for (let y = w.size.y - 2; y > 25; y--) {
    for (let x = 3; x < w.size.x - 3; x++) {
      for (let z = 3; z < w.size.z - 3; z++) {
        if (w.getBlock(x, y, z) !== AIR) continue;
        if (neighbors.every(([dx,dy,dz]) => w.getBlock(x+dx, y+dy, z+dz) === AIR)) { cell = {x,y,z}; break outer; }
      }
    }
  }
  assert.ok(cell, 'found an isolated air cell');
  w.setBlock(cell.x, cell.y, cell.z, STONE);
  const buckets = buildExposedFaces(w);
  const bucket = buckets.find(b => b.type === STONE);
  assert.ok(bucket, 'stone bucket exists');
  const cross = (a, b) => [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
  const dot = (a, b) => a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
  const sub = (a, b) => [a[0]-b[0], a[1]-b[1], a[2]-b[2]];
  const base = [cell.x, cell.y, cell.z];
  const inBlock = (v) => v.every((c, i) => c >= base[i] - 1e-9 && c <= base[i] + 1 + 1e-9);
  const triCount = bucket.positions.length / 9;
  let checked = 0, bad = 0;
  for (let i = 0; i < triCount; i++) {
    const o = i * 9;
    const a = bucket.positions.slice(o, o + 3);
    const b = bucket.positions.slice(o + 3, o + 6);
    const c = bucket.positions.slice(o + 6, o + 9);
    if (!(inBlock(a) && inBlock(b) && inBlock(c))) continue;
    const n = bucket.normals.slice(o, o + 3);
    checked++;
    if (dot(cross(sub(b, a), sub(c, a)), n) <= 1e-9) bad++;
  }
  assert.equal(checked, 12, `expected 12 triangles for the placed block, got ${checked}`);
  assert.equal(bad, 0, `${bad} triangles wound against their outward normal`);
});

test('getBlock returns 0 (air) for empty cells and correct values for filled', () => {
  const w = new World(42);
  assert.equal(w.getBlock(0, 100, 0), AIR);
  const x = 5, z = 5;
  const h = w.surfaceHeight(x, z);
  assert.equal(w.getBlock(x, h, z) === AIR, false);
  assert.equal(w.getBlock(x, 0, z), STONE); // deep stone
});
