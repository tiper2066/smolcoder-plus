// three.js renderer for the voxel world. Builds one BufferGeometry per block
// type from exposed faces, adds ambient + directional lighting, a target
// outline and a sky gradient.
import * as THREE from 'three';
import { BLOCK_COLORS, GRASS, DIRT, STONE, WOOD, LEAVES, WATER, AIR } from '../world/blocks.js';
import { buildExposedFaces } from './faceBuilder.js';

const SKY_TOP = 0x8fd3ff;
const SKY_HORIZON = 0xcfe8ff;
const FOG_COLOR = 0xbfe0f5;

export function makeMaterial(type) {
  const colors = BLOCK_COLORS[type];
  if (!colors) return null;
  const mat = new THREE.MeshLambertMaterial({ color: colors.side });
  if (type === WATER) {
    mat.transparent = true;
    mat.opacity = 0.72;
    mat.depthWrite = false;
    mat.side = THREE.DoubleSide;
  }
  if (type === LEAVES) {
    mat.transparent = true;
    mat.opacity = 0.96;
  }
  return mat;
}

// Grass top is green, sides brown — we use vertex colors to differentiate.
function bakeVertexColors(geometry, type) {
  const colors = BLOCK_COLORS[type];
  const pos = geometry.attributes.position;
  const nor = geometry.attributes.normal;
  const count = pos.count;
  const col = new Float32Array(count * 3);
  const top = new THREE.Color(colors.top);
  const side = new THREE.Color(colors.side);
  for (let i = 0; i < count; i++) {
    const ny = nor.getY(i);
    // top face (ny ≈ +1) gets top color, otherwise side color
    const c = ny > 0.5 ? top : side;
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return geometry;
}

export class VoxelRenderer {
  constructor(canvasContainer) {
    this.container = canvasContainer;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(SKY_TOP);
    this.scene.fog = new THREE.Fog(FOG_COLOR, 30, 90);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.1, 300);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.domElement.style.display = 'block';
    canvasContainer.appendChild(this.renderer.domElement);

    // Lighting: ambient + warm directional sun
    const amb = new THREE.AmbientLight(0xbfd8ff, 0.55);
    const sun = new THREE.DirectionalLight(0xfff2d4, 1.05);
    sun.position.set(24, 40, 12);
    const skyLight = new THREE.HemisphereLight(0x9fcfff, 0x6a5a44, 0.35);
    this.scene.add(amb, sun, skyLight);

    // Target outline
    this.outline = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002, 1.002, 1.002)),
      new THREE.LineBasicMaterial({ color: 0x111820, linewidth: 2 })
    );
    this.outline.visible = false;
    this.scene.add(this.outline);

    this.meshes = new Map(); // type -> mesh
    this.resize();
  }

  resize() {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  // Rebuild all block meshes from the world. Called on startup and after edits.
  rebuild(world) {
    // remove old
    for (const m of this.meshes.values()) {
      this.scene.remove(m);
      m.geometry.dispose();
      m.material.dispose();
    }
    this.meshes.clear();

    const buckets = buildExposedFaces(world, { includeWater: true });
    for (const b of buckets) {
      if (b.positions.length === 0) continue;
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(b.positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(b.normals, 3));
      const mat = makeMaterial(b.type);
      if (!mat) continue;
      if (b.type === GRASS) {
        // vertex colors for grass top/side
        mat.vertexColors = true;
        bakeVertexColors(geo, b.type);
      }
      const mesh = new THREE.Mesh(geo, mat);
      mesh.frustumCulled = true;
      this.scene.add(mesh);
      this.meshes.set(b.type, mesh);
    }
  }

  // Fast path: rebuild a single block type's mesh after an edit.
  rebuildType(world, type) {
    const old = this.meshes.get(type);
    if (old) {
      this.scene.remove(old);
      old.geometry.dispose();
      old.material.dispose();
      this.meshes.delete(type);
    }
    const buckets = buildExposedFaces(world, { includeWater: true })
      .filter((b) => b.type === type);
    for (const b of buckets) {
      if (b.positions.length === 0) continue;
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(b.positions, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(b.normals, 3));
      const mat = makeMaterial(b.type);
      if (!mat) continue;
      if (b.type === GRASS) {
        mat.vertexColors = true;
        bakeVertexColors(geo, b.type);
      }
      const mesh = new THREE.Mesh(geo, mat);
      this.scene.add(mesh);
      this.meshes.set(b.type, mesh);
    }
  }

  setCamera(x, y, z, yaw, pitch) {
    this.camera.position.set(x, y, z);
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.set(pitch, yaw, 0);
  }

  setTarget(hit) {
    if (!hit) { this.outline.visible = false; return; }
    this.outline.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
    this.outline.visible = true;
  }

  render() { this.renderer.render(this.scene, this.camera); }
}
