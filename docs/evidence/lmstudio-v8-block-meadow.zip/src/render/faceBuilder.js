// Build a list of "exposed faces" for a World. A face is a unit square on the
// boundary of a solid block, exposed to air (or water). This lets the renderer
// use a single InstancedBufferGeometry for each block type and draw far fewer
// triangles than 6 faces per cube.
import { isOpaque, isSolid, AIR, WATER } from '../world/blocks.js';

// 6 faces of a unit cube (corner (0,0,0) to (1,1,1)) with outward normal.
// Winding: vertices are ordered counter-clockwise as seen from OUTSIDE the
// cube, so cross(v1-v0, v2-v0) points along the outward normal and the face
// is front-facing in three.js (which culls clockwise triangles).
const FACES = [
  { n: [ 1, 0, 0], c: [[1,0,0],[1,1,0],[1,1,1],[1,0,1]] }, // +X
  { n: [-1, 0, 0], c: [[0,0,1],[0,1,1],[0,1,0],[0,0,0]] }, // -X
  { n: [ 0, 1, 0], c: [[0,1,1],[1,1,1],[1,1,0],[0,1,0]] }, // +Y
  { n: [ 0,-1, 0], c: [[0,0,0],[1,0,0],[1,0,1],[0,0,1]] }, // -Y
  { n: [ 0, 0, 1], c: [[0,0,1],[1,0,1],[1,1,1],[0,1,1]] }, // +Z
  { n: [ 0, 0,-1], c: [[1,0,0],[0,0,0],[0,1,0],[1,1,0]] }  // -Z
];

// Returns an array of { type, positions: number[], normals: number[] }
export function buildExposedFaces(world, { includeWater = false } = {}) {
  const buckets = new Map(); // type -> { positions: [], normals: [], uvs: [] }
  const { x: wx, y: wy, z: wz } = world.size;

  const get = (type) => {
    let b = buckets.get(type);
    if (!b) { b = { type, positions: [], normals: [], uvs: [] }; buckets.set(type, b); }
    return b;
  };

  for (let y = 0; y < wy; y++) {
    for (let z = 0; z < wz; z++) {
      for (let x = 0; x < wx; x++) {
        const t = world.getBlock(x, y, z);
        if (t === AIR) continue;
        if (t === WATER && !includeWater) continue;
        if (!isOpaque(t) && t !== WATER) {
          // Leaves: draw all faces (translucent look)
          // handled below: same as solid but all 6 faces
        }
        const bucket = get(t);
        // For grass, use a different color on top (handled via material side
        // colors) — we keep one bucket per type and let the material handle it.
        for (const f of FACES) {
          const nb = world.getBlock(x + f.n[0], y + f.n[1], z + f.n[2]);
          const isLeaf = t === 5; // LEAVES
          // A face is drawn if the neighbor is air, out of bounds, water (unless we're water),
          // or if we're leaves (draw all)
          const draw = isLeaf ||
            nb === AIR ||
            !world.inBounds(x + f.n[0], y + f.n[1], z + f.n[2]) ||
            (t !== WATER && nb === WATER);
          if (!draw) continue;
          // 4 corners -> 2 triangles (0,1,2, 0,2,3)
          for (const idx of [0, 1, 2, 0, 2, 3]) {
            const c = f.c[idx];
            bucket.positions.push(x + c[0], y + c[1], z + c[2]);
            bucket.normals.push(f.n[0], f.n[1], f.n[2]);
            bucket.uvs.push(c[0], c[1]);
          }
        }
      }
    }
  }
  return Array.from(buckets.values());
}
