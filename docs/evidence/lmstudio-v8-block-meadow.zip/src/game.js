// Game state: world, player, input, selection, HUD, pause/resume, save/load,
// and the requestAnimationFrame loop. Exposes window.voxelDebug for the
// browser acceptance harness.
import * as THREE from 'three';
import { World } from './world/world.js';
import { Player, aabbIntersectsBlock } from './world/player.js';
import { raycast, placementCell } from './world/raycast.js';
import { PLACEABLE, GRASS, DIRT, STONE, WOOD, LEAVES, AIR } from './world/blocks.js';
import { VoxelRenderer } from './render/renderer.js';
import {
  saveWorld, loadWorld, saveMeta, loadMeta, clearSave
} from './persistence.js';

const REACH = 5.5;
const DEFAULT_SEED = 20240607;

export class Game {
  constructor(rootEl) {
    this.root = rootEl;
    this.paused = true;
    this.lastTime = 0;
    this.keys = new Set();
    this.yaw = 0;
    this.pitch = 0;
    this.selected = GRASS;
    this.fps = 0;
    this.fpsAccum = 0;
    this.fpsFrames = 0;

    this._initWorldAndPlayer();
    this._initRenderer();
    this._initInput();
    this._initUI();
    this._installDebug();

    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  _initWorldAndPlayer() {
    const saved = loadWorld();
    this.world = saved || new World(DEFAULT_SEED);
    const meta = loadMeta();

    let spawn = this.world.spawn;
    if (meta && meta.player) {
      const p = meta.player;
      // Only use the saved position if it is inside the world and not inside a solid.
      if (this.world.inBounds(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z))) {
        // ensure not embedded in solid
        const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
        let clear = true;
        for (let dy = 0; dy <= 1 && clear; dy++) {
          for (let dx = -1; dx <= 1 && clear; dx++) {
            for (let dz = -1; dz <= 1 && clear; dz++) {
              if (this.world.getBlock(bx + dx, by + dy, bz + dz) !== AIR &&
                  this.world.getBlock(bx + dx, by + dy, bz + dz) !== 6) clear = false;
            }
          }
        }
        if (clear) spawn = { x: p.x, y: p.y, z: p.z };
      }
    }
    if (meta && Number.isFinite(meta.selected)) this.selected = meta.selected;

    this.player = new Player(this.world, spawn.x, spawn.y, spawn.z);
  }

  _initRenderer() {
    this.renderer = new VoxelRenderer(this.root);
    this.renderer.rebuild(this.world);
  }

  _initInput() {
    window.addEventListener('keydown', (e) => this._onKeyDown(e));
    window.addEventListener('keyup', (e) => this._onKeyUp(e));
    window.addEventListener('blur', () => this.keys.clear());
    window.addEventListener('resize', () => this.renderer.resize());

    const canvas = this.renderer.renderer.domElement;
    canvas.addEventListener('mousedown', (e) => this._onMouseDown(e));
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    document.addEventListener('pointerlockchange', () => {
      if (document.pointerLockElement === canvas) {
        this.paused = false;
        this._showHud();
      } else {
        this.paused = true;
        this._showMenu(true);
      }
    });

    document.addEventListener('mousemove', (e) => {
      if (document.pointerLockElement !== canvas || this.paused) return;
      const sens = 0.0022;
      this.yaw -= e.movementX * sens;
      this.pitch -= e.movementY * sens;
      const lim = Math.PI / 2 - 0.01;
      if (this.pitch > lim) this.pitch = lim;
      if (this.pitch < -lim) this.pitch = -lim;
    });
  }

  _onKeyDown(e) {
    // Number keys 1-5 select hotbar slot
    if (e.code >= 'Digit1' && e.code <= 'Digit5') {
      const idx = Number(e.code.slice(-1)) - 1;
      this.selectSlot(idx);
      e.preventDefault();
      return;
    }
    if (e.code === 'KeyW' || e.code === 'KeyA' || e.code === 'KeyS' ||
        e.code === 'KeyD' || e.code === 'Space') {
      this.keys.add(e.code);
      e.preventDefault();
    }
    if (e.code === 'Escape') {
      // browser handles pointer unlock; pause handled in pointerlockchange
    }
  }

  _onKeyUp(e) { this.keys.delete(e.code); }

  _onMouseDown(e) {
    if (this.paused) return;
    const canvas = this.renderer.renderer.domElement;
    if (document.pointerLockElement !== canvas) return;
    if (e.button === 0) this._breakTarget();
    else if (e.button === 2) this._placeTarget();
  }

  _currentTarget() {
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(this.cameraEuler());
    const origin = new THREE.Vector3(this.player.x, this.player.y + 1.55, this.player.z);
    const hit = raycast(this.world,
      { x: origin.x, y: origin.y, z: origin.z },
      { x: dir.x, y: dir.y, z: dir.z },
      REACH);
    return hit;
  }

  cameraEuler() {
    return new THREE.Euler(this.pitch, this.yaw, 0, 'YXZ');
  }

  _breakTarget() {
    const hit = this._currentTarget();
    if (!hit) return;
    const r = this.world.tryRemove(hit.x, hit.y, hit.z);
    if (r) {
      this._rebuildAround(hit.x, hit.y, hit.z, hit.type);
    }
  }

  _placeTarget() {
    const hit = this._currentTarget();
    if (!hit) return;
    const cell = placementCell(hit);
    if (!cell) return;
    // Never place inside the player's body
    if (aabbIntersectsBlock(cell.x, cell.y, cell.z, this.player.x, this.player.y, this.player.z)) return;
    const r = this.world.tryPlace(cell.x, cell.y, cell.z, this.selected);
    if (r.ok) {
      this._rebuildAround(cell.x, cell.y, cell.z, this.selected);
      // the hit block may lose/gain an exposed face
      if (hit.type !== AIR && hit.type !== this.selected) {
        this.renderer.rebuildType(this.world, hit.type);
      }
    }
  }

  // Rebuild the edited block type and all solid neighbor types (their exposed
  // faces may have changed).
  _rebuildAround(x, y, z, editedType) {
    const types = new Set();
    if (editedType !== AIR) types.add(editedType);
    for (const [dx, dy, dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]) {
      const t = this.world.getBlock(x + dx, y + dy, z + dz);
      if (t !== AIR) types.add(t);
    }
    for (const t of types) this.renderer.rebuildType(this.world, t);
  }

  selectSlot(i) {
    if (i < 0 || i >= PLACEABLE.length) return;
    this.selected = PLACEABLE[i];
    this._updateHotbar();
    saveMeta(this._meta());
  }

  _meta() {
    return {
      selected: this.selected,
      player: { x: this.player.x, y: this.player.y, z: this.player.z }
    };
  }

  // ---------- UI ----------
  _initUI() {
    this.el = {
      hud: document.getElementById('hud'),
      crosshair: document.getElementById('crosshair'),
      fps: document.getElementById('fps'),
      hotbar: document.getElementById('hotbar'),
      menu: document.getElementById('menu'),
      toast: document.getElementById('toast')
    };
    this._hotbarSlots = Array.from(this.el.hotbar.querySelectorAll('.slot'));

    this.el.hotbar.addEventListener('click', (e) => {
      const btn = e.target.closest('.slot');
      if (!btn) return;
      const idx = Number(btn.dataset.index);
      this.selectSlot(idx);
    });

    document.getElementById('btn-save').addEventListener('click', () => this.save());
    document.getElementById('btn-new').addEventListener('click', () => this.confirmNewWorld());
    document.getElementById('btn-play').addEventListener('click', () => this.resume());
    document.getElementById('btn-menu-save').addEventListener('click', () => this.loadSavedWorld());
    document.getElementById('btn-menu-new').addEventListener('click', () => this.confirmNewWorld());

    this._updateHotbar();
  }

  _updateHotbar() {
    const idx = PLACEABLE.indexOf(this.selected);
    this._hotbarSlots.forEach((s, i) => {
      s.classList.toggle('selected', i === idx);
      s.setAttribute('aria-pressed', i === idx ? 'true' : 'false');
    });
  }

  _showHud() {
    this.el.hud.classList.add('visible');
    this.el.hud.setAttribute('aria-hidden', 'false');
    this.el.menu.classList.add('hidden');
  }

  _showMenu(asPause) {
    this.el.menu.classList.remove('hidden');
    const play = document.getElementById('btn-play');
    play.textContent = asPause ? '▶  Resume' : '▶  Play';
  }

  _toast(msg, ms = 1800) {
    this.el.toast.textContent = msg;
    this.el.toast.classList.add('show');
    clearTimeout(this._toastT);
    this._toastT = setTimeout(() => this.el.toast.classList.remove('show'), ms);
  }

  // ---------- actions ----------
  resume() {
    const canvas = this.renderer.renderer.domElement;
    if (document.pointerLockElement !== canvas) {
      const p = canvas.requestPointerLock && canvas.requestPointerLock({ unadjusted: true });
      if (p && p.catch) p.catch(() => {});
    }
  }

  save() {
    const okW = saveWorld(this.world);
    const okM = saveMeta(this._meta());
    this._toast(okW && okM ? 'World saved ✓' : 'Save failed');
  }

  confirmNewWorld() {
    if (window.confirm('Start a new world? Unsaved edits will be lost.')) {
      this.newWorld();
    }
  }

  newWorld() {
    clearSave();
    const seed = (Date.now() & 0xffffffff) ^ 0x9e3779b9;
    this.world = new World(seed);
    this.player = new Player(this.world, this.world.spawn.x, this.world.spawn.y, this.world.spawn.z);
    this.selected = GRASS;
    this.renderer.rebuild(this.world);
    this._updateHotbar();
    this._toast('New world generated ✨');
    this.save();
  }

  loadSavedWorld() {
    const w = loadWorld();
    if (!w) { this._toast('No saved world found'); return; }
    this.world = w;
    const meta = loadMeta();
    if (meta) {
      if (Number.isFinite(meta.selected)) this.selected = meta.selected;
      if (meta.player) {
        const p = meta.player;
        if (this.world.inBounds(Math.floor(p.x), Math.floor(p.y), Math.floor(p.z))) {
          this.player = new Player(this.world, p.x, p.y, p.z);
        }
      }
    }
    this.renderer.rebuild(this.world);
    this._updateHotbar();
    this._toast('Loaded saved world ✓');
    this.resume();
  }

  // ---------- debug API ----------
  _installDebug() {
    if (typeof window === 'undefined') return;
    window.voxelDebug = {
      snapshot: () => {
        const hit = this._currentTarget();
        return {
          player: { x: this.player.x, y: this.player.y, z: this.player.z },
          selected: this.selected,
          targeted: hit ? { x: hit.x, y: hit.y, z: hit.z } : null,
          editCount: this.world.editCount
        };
      },
      getBlock: (x, y, z) => this.world.getBlock(x, y, z),
      teleport: (x, y, z) => {
        this.player.x = x; this.player.y = y; this.player.z = z;
        this.player.vx = 0; this.player.vy = 0; this.player.vz = 0;
      }
    };
  }

  // ---------- main loop ----------
  _loop(t) {
    const dt = this.lastTime ? (t - this.lastTime) / 1000 : 0;
    this.lastTime = t;

    // FPS
    this.fpsAccum += dt;
    this.fpsFrames++;
    if (this.fpsAccum >= 0.5) {
      this.fps = Math.round(this.fpsFrames / this.fpsAccum);
      this.fpsAccum = 0; this.fpsFrames = 0;
      this._renderFps();
    }

    if (!this.paused) {
      let dx = 0, dz = 0;
      if (this.keys.has('KeyW')) { dx += Math.sin(this.yaw); dz -= Math.cos(this.yaw); }
      if (this.keys.has('KeyS')) { dx -= Math.sin(this.yaw); dz += Math.cos(this.yaw); }
      if (this.keys.has('KeyA')) { dx -= Math.cos(this.yaw); dz -= Math.sin(this.yaw); }
      if (this.keys.has('KeyD')) { dx += Math.cos(this.yaw); dz += Math.sin(this.yaw); }
      const jump = this.keys.has('Space');
      this.player.update(dt, { dx, dz, jump });
    }

    this.renderer.setCamera(this.player.x, this.player.y + 1.55, this.player.z, this.yaw, this.pitch);
    this.renderer.setTarget(this._currentTarget());
    this.renderer.render();

    requestAnimationFrame(this._loop);
  }

  _renderFps() {
    const el = this.el.fps;
    el.textContent = `${this.fps} FPS`;
    el.className = this.fps >= 50 ? 'ok' : this.fps >= 25 ? 'warn' : 'bad';
  }
}

export { PLACEABLE, GRASS, DIRT, STONE, WOOD, LEAVES };
