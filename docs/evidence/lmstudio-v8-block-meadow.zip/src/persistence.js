// localStorage persistence with safe parsing. Never throws on bad data.
import { World } from './world/world.js';
import { PLACEABLE } from './world/blocks.js';

const KEYS = {
  world: 'blockmeadow.world.v1',
  meta: 'blockmeadow.meta.v1' // { selected, player: {x,y,z} }
};

export function safeGetJSON(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

export function saveWorld(world) {
  try {
    localStorage.setItem(KEYS.world, JSON.stringify(world.serialize()));
    return true;
  } catch { return false; }
}

export function loadWorld() {
  const data = safeGetJSON(KEYS.world);
  if (!data) return null;
  try {
    const w = World.deserialize(data);
    if (!w || !w.blocks || w.blocks.length === 0) return null;
    return w;
  } catch { return null; }
}

export function saveMeta(meta) {
  try { localStorage.setItem(KEYS.meta, JSON.stringify(meta)); return true; }
  catch { return false; }
}

export function loadMeta() {
  const m = safeGetJSON(KEYS.meta);
  if (!m || typeof m !== 'object') return null;
  const out = {};
  if (PLACEABLE.includes(m.selected)) out.selected = m.selected;
  if (m.player && Number.isFinite(m.player.x) && Number.isFinite(m.player.y) && Number.isFinite(m.player.z)) {
    out.player = { x: m.player.x, y: m.player.y, z: m.player.z };
  }
  return Object.keys(out).length ? out : null;
}

export function clearSave() {
  try {
    localStorage.removeItem(KEYS.world);
    localStorage.removeItem(KEYS.meta);
    return true;
  } catch { return false; }
}

export const SAVE_KEYS = KEYS;
