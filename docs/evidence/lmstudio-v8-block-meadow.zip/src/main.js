// Entry point: boot the game into #app.
import { Game } from './game.js';

const root = document.getElementById('app');
window.blockMeadow = new Game(root);
