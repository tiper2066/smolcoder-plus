// Block type identifiers (shared by world logic and renderer).
export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const WOOD = 4;
export const LEAVES = 5;
export const WATER = 6;

// Palette used by both the HUD swatches and the 3D materials.
export const BLOCK_COLORS = {
  [GRASS]: { top: 0x6fbf62, side: 0x8a5a3b },
  [DIRT]: { top: 0x8a5a3b, side: 0x7c5033 },
  [STONE]: { top: 0x8a8f98, side: 0x7c828b },
  [WOOD]: { top: 0x7a5a34, side: 0x6b4e2c },
  [LEAVES]: { top: 0x4f9e4f, side: 0x448a44 },
  [WATER]: { top: 0x5ab8d6, side: 0x4aa3c0 }
};

export const BLOCK_NAMES = {
  [AIR]: 'air',
  [GRASS]: 'grass',
  [DIRT]: 'dirt',
  [STONE]: 'stone',
  [WOOD]: 'wood',
  [LEAVES]: 'leaves',
  [WATER]: 'water'
};

// Blocks the player can pick from the hotbar (number keys 1-5).
export const PLACEABLE = [GRASS, DIRT, STONE, WOOD, LEAVES];

export function isSolid(type) {
  return type !== AIR && type !== WATER;
}

export function isOpaque(type) {
  return type === GRASS || type === DIRT || type === STONE || type === WOOD || type === LEAVES;
}

export function isPlaceable(type) {
  return PLACEABLE.includes(type);
}
