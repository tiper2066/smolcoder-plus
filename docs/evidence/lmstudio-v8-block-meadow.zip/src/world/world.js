// Voxel world: block storage, terrain generation, bounds and edits.
// Pure JS (no DOM / three.js) so it is fully testable in Node.
import { AIR, GRASS, DIRT, STONE, WOOD, LEAVES, WATER, isSolid } from './blocks.js';
import { fbm, hash2, mulberry32 } from './noise.js';

export const WORLD_SIZE_X = 56; // >= 48 as required
export const WORLD_SIZE_Y = 32;
export const WORLD_SIZE_Z = 56;

const BASE = 12;      // flat base height
const HILLS = 14;     // hill amplitude
const LAKE_LEVEL = BASE + 2;

export class World {
  constructor(seed = 1337) {
    this.seed = seed >>> 0;
    this.size = { x: WORLD_SIZE_X, y: WORLD_SIZE_Y, z: WORLD_SIZE_Z };
    this.editCount = 0;
    // blocks stored as Map "x,y,z" -> type for sparse storage of edits
    // plus a base terrain generated on demand. Simpler: full Uint8 array.
    const n = this.size.x * this.size.y * this.size.z;
    this.blocks = new Uint8Array(n);
    this.lakeCenter = { x: 0, z: 0, r: 0 };
    this.spawn = { x: this.size.x / 2, y: 20, z: this.size.z / 2 };
    this.generate();
  }

  idx(x, y, z) {
    return (y * this.size.z + z) * this.size.x + x;
  }

  inBounds(x, y, z) {
    return x >= 0 && y >= 0 && z >= 0 &&
      x < this.size.x && y < this.size.y && z < this.size.z;
  }

  getBlock(x, y, z) {
    if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isInteger(z)) return AIR;
    if (!this.inBounds(x, y, z)) return AIR;
    return this.blocks[this.idx(x, y, z)];
  }

  setBlock(x, y, z, type) {
    if (!this.inBounds(x, y, z)) return false;
    if (type < 0 || type > 255) return false;
    this.blocks[this.idx(x, y, z)] = type;
    return true;
  }

  surfaceHeight(x, z) {
    for (let y = this.size.y - 1; y >= 0; y--) {
      const t = this.getBlock(x, y, z);
      if (t !== AIR && t !== WATER) return y;
    }
    return -1;
  }

  // ---------- deterministic terrain generation ----------
  generate() {
    const { x: wx, y: wy, z: wz } = this.size;
    const seed = this.seed;

    // Pick a deterministic lake spot away from edges and from spawn center.
    const rand = mulberry32(seed ^ 0x9e3779b9);
    const lx = 10 + Math.floor(rand() * (wx - 20));
    const lz = 10 + Math.floor(rand() * (wz - 20));
    const lr = 5 + Math.floor(rand() * 3); // radius 5..7
    this.lakeCenter = { x: lx, z: lz, r: lr };

    const heightAt = (x, z) => {
      const nx = x / wx, nz = z / wz;
      const n = fbm(seed, nx * 5, nz * 5, 4);
      // gentle hills
      let h = BASE + Math.floor(n * HILLS);
      // carve a bowl around the lake
      const dx = x - lx, dz = z - lz;
      const d = Math.sqrt(dx * dx + dz * dz);
      if (d < lr) {
        const t = 1 - d / lr;
        h = Math.min(h, BASE - 1 + Math.round(t * 2));
      }
      // clamp
      h = Math.max(3, Math.min(wy - 8, h));
      return h;
    };

    for (let x = 0; x < wx; x++) {
      for (let z = 0; z < wz; z++) {
        const h = heightAt(x, z);
        for (let y = 0; y <= h; y++) {
          let t;
          if (y === h) t = GRASS;
          else if (y >= h - 2) t = DIRT;
          else t = STONE;
          this.blocks[this.idx(x, y, z)] = t;
        }
        // fill lake water up to LAKE_LEVEL
        const dx = x - lx, dz = z - lz;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d < lr && h < LAKE_LEVEL) {
          for (let y = h + 1; y <= LAKE_LEVEL; y++) {
            this.blocks[this.idx(x, y, z)] = WATER;
          }
        }
      }
    }

    // Trees: deterministic scatter on grass, away from lake & world edges
    const tr = mulberry32(seed ^ 0x51ab);
    let planted = 0;
    let guard = 0;
    while (planted < 14 && guard < 400) {
      guard++;
      const tx = 3 + Math.floor(tr() * (wx - 6));
      const tz = 3 + Math.floor(tr() * (wz - 6));
      const dx = tx - lx, dz = tz - lz;
      if (Math.sqrt(dx * dx + dz * dz) < lr + 2) continue;
      const h = this.surfaceHeight(tx, tz);
      if (h < 3 || this.getBlock(tx, h, tz) !== GRASS) continue;
      const trunkH = 3 + Math.floor(tr() * 2); // 3..4
      let ok = true;
      for (let i = 0; i < trunkH && ok; i++) {
        if (this.getBlock(tx, h + 1 + i, tz) !== AIR) ok = false;
      }
      if (!ok) continue;
      for (let i = 0; i < trunkH; i++) this.setBlock(tx, h + 1 + i, tz, WOOD);
      // leaf canopy
      const topY = h + trunkH;
      for (let ox = -2; ox <= 2; ox++) {
        for (let oz = -2; oz <= 2; oz++) {
          for (let oy = 0; oy <= 1; oy++) {
            const dist = Math.abs(ox) + Math.abs(oz) + oy;
            if (dist > 3) continue;
            const bx = tx + ox, by = topY + oy, bz = tz + oz;
            if (this.getBlock(bx, by, bz) === AIR) this.setBlock(bx, by, bz, LEAVES);
          }
        }
      }
      this.setBlock(tx, topY + 1, tz, LEAVES);
      planted++;
    }

    // Spawn: safely above the surface at the world center
    const sx = Math.floor(wx / 2), sz = Math.floor(wz / 2);
    const sh = this.surfaceHeight(sx, sz);
    this.spawn = { x: sx + 0.5, y: (sh >= 0 ? sh : BASE) + 4.5, z: sz + 0.5 };
  }

  // ---------- edits with persistence ----------
  tryRemove(x, y, z) {
    const t = this.getBlock(x, y, z);
    if (t === AIR) return false;
    if (t === WATER) return false; // can't break water
    this.setBlock(x, y, z, AIR);
    this.editCount++;
    return true;
  }

  tryPlace(x, y, z, type) {
    if (!this.inBounds(x, y, z)) return { ok: false, reason: 'out-of-bounds' };
    const cur = this.getBlock(x, y, z);
    if (cur !== AIR && cur !== WATER) return { ok: false, reason: 'occupied' };
    this.setBlock(x, y, z, type);
    this.editCount++;
    return { ok: true };
  }

}

// ---------- serialization (base64, works in Node & browser) ----------
function toB64(u8) {
  let s = '';
  for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
  return btoa(s);
}
function fromB64(s) {
  const bin = atob(s);
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

World.prototype.serialize = function () {
  return {
    v: 1,
    seed: this.seed,
    size: this.size,
    blocks: toB64(this.blocks),
    editCount: this.editCount
  };
};

World.deserialize = function (data) {
  if (!data || typeof data !== 'object' || data.v !== 1 || !data.blocks) {
    throw new Error('bad world data');
  }
  const w = new World(data.seed);
  w.blocks = fromB64(data.blocks);
  w.editCount = Number.isFinite(data.editCount) ? data.editCount | 0 : 0;
  return w;
};
