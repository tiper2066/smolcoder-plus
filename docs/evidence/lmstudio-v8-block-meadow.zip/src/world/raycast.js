// Raycast through the voxel grid using the standard DDA (Amanatides & Woo).
// Returns the first solid (or any non-air) block hit and the face normal,
// or null. Used for the target outline and block break/place.
export function raycast(world, origin, dir, maxDist = 6) {
  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);

  const stepX = dir.x > 0 ? 1 : -1;
  const stepY = dir.y > 0 ? 1 : -1;
  const stepZ = dir.z > 0 ? 1 : -1;

  const tDeltaX = dir.x !== 0 ? Math.abs(1 / dir.x) : Infinity;
  const tDeltaY = dir.y !== 0 ? Math.abs(1 / dir.y) : Infinity;
  const tDeltaZ = dir.z !== 0 ? Math.abs(1 / dir.z) : Infinity;

  let tMaxX = dir.x !== 0 ? ((stepX > 0 ? (x + 1 - origin.x) : (origin.x - x)) * tDeltaX) : Infinity;
  let tMaxY = dir.y !== 0 ? ((stepY > 0 ? (y + 1 - origin.y) : (origin.y - y)) * tDeltaY) : Infinity;
  let tMaxZ = dir.z !== 0 ? ((stepZ > 0 ? (z + 1 - origin.z) : (origin.z - z)) * tDeltaZ) : Infinity;

  let face = null; // normal of the face we entered the block through
  let t = 0;

  for (let i = 0; i < 256; i++) {
    const type = world.getBlock(x, y, z);
    if (type !== 0) {
      return {
        x, y, z, type,
        face: face || { x: 0, y: 0, z: 0 },
        dist: t
      };
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      x += stepX; t = tMaxX; tMaxX += tDeltaX; face = { x: -stepX, y: 0, z: 0 };
    } else if (tMaxY < tMaxZ) {
      y += stepY; t = tMaxY; tMaxY += tDeltaY; face = { x: 0, y: -stepY, z: 0 };
    } else {
      z += stepZ; t = tMaxZ; tMaxZ += tDeltaZ; face = { x: 0, y: 0, z: -stepZ };
    }
    if (t > maxDist) return null;
    if (!world.inBounds(x, y, z)) return null;
  }
  return null;
}

// Compute the adjacent placement cell for a hit.
export function placementCell(hit) {
  if (!hit) return null;
  return {
    x: hit.x + hit.face.x,
    y: hit.y + hit.face.y,
    z: hit.z + hit.face.z
  };
}
