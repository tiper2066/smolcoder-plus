// Player physics: AABB collision against the voxel world, gravity, jumping.
// Pure JS, testable in Node. Coordinates in block space; the player AABB is
// 0.6 wide, 1.8 tall, centered on (x, z) with y being the feet position.
import { isSolid } from './blocks.js';

export const PLAYER_HALF_W = 0.3;
export const PLAYER_HEIGHT = 1.8;
export const GRAVITY = 24;          // blocks / s^2
export const JUMP_VELOCITY = 8.4;   // blocks / s
export const MOVE_SPEED = 5.2;      // blocks / s
export const MAX_FRAME_DT = 0.05;   // clamp large frame deltas (background tabs)

export function clampDT(dt) {
  if (!Number.isFinite(dt) || dt < 0) return 0;
  return Math.min(dt, MAX_FRAME_DT);
}

// Does the player AABB at (x,y,z) overlap any solid block?
function collides(world, x, y, z) {
  const hw = PLAYER_HALF_W, H = PLAYER_HEIGHT;
  const x0 = Math.floor(x - hw), x1 = Math.floor(x + hw);
  const y0 = Math.floor(y), y1 = Math.floor(y + H);
  const z0 = Math.floor(z - hw), z1 = Math.floor(z + hw);
  for (let bx = x0; bx <= x1; bx++)
    for (let by = y0; by <= y1; by++)
      for (let bz = z0; bz <= z1; bz++)
        if (isSolid(world.getBlock(bx, by, bz))) return true;
  return false;
}

export function aabbIntersectsBlock(bx, by, bz, px, py, pz) {
  return (
    bx < px + PLAYER_HALF_W && bx + 1 > px - PLAYER_HALF_W &&
    by < py + PLAYER_HEIGHT && by + 1 > py &&
    bz < pz + PLAYER_HALF_W && bz + 1 > pz - PLAYER_HALF_W
  );
}

// Snap the player out of a collision along one axis. Returns the corrected
// coordinate. If the player is not actually overlapping after the move, the
// original coordinate is returned.
function resolveAxis(world, axis, coord, oldCoord, velocity) {
  const other1 = axis === 'y' ? undefined : undefined;
  // We only need to know if still colliding at the new position
  // (the caller already confirmed a collision).
  // Push to the nearest face depending on direction of motion.
  const hw = PLAYER_HALF_W, H = PLAYER_HEIGHT;
  if (axis === 'x') {
    if (velocity > 0) {
      // moving +x: snap left face to the block's left
      return Math.floor(coord + hw) - hw - 0.001;
    } else if (velocity < 0) {
      return Math.floor(coord - hw) + 1 + hw + 0.001;
    }
    // zero velocity collision (e.g. at world edge): push out toward center
    return oldCoord;
  }
  if (axis === 'z') {
    if (velocity > 0) return Math.floor(coord + hw) - hw - 0.001;
    if (velocity < 0) return Math.floor(coord - hw) + 1 + hw + 0.001;
    return oldCoord;
  }
  // y
  if (velocity < 0) {
    // landing: feet to top of the block we hit
    return Math.floor(coord) + 1;
  }
  if (velocity > 0) {
    // head bump: top of head to bottom of block
    return Math.floor(coord + H) - H - 0.001;
  }
  return oldCoord;
}

export class Player {
  constructor(world, x, y, z) {
    this.world = world;
    this.x = x; this.y = y; this.z = z;
    this.vx = 0; this.vy = 0; this.vz = 0;
    this.grounded = false;
  }

  update(dt, input = { dx: 0, dz: 0, jump: false }) {
    dt = clampDT(dt);

    // horizontal velocity from input (already camera-relative)
    const len = Math.hypot(input.dx, input.dz);
    if (len > 0) {
      this.vx = (input.dx / len) * MOVE_SPEED;
      this.vz = (input.dz / len) * MOVE_SPEED;
    } else {
      this.vx = 0;
      this.vz = 0;
    }

    // gravity
    this.vy -= GRAVITY * dt;
    if (this.vy < -50) this.vy = -50;

    // jump when grounded
    if (input.jump && this.grounded) {
      this.vy = JUMP_VELOCITY;
      this.grounded = false;
    }

    const ox = this.x, oy = this.y, oz = this.z;

    // --- X axis ---
    this.x = this.x + this.vx * dt;
    if (collides(this.world, this.x, this.y, this.z)) {
      this.x = resolveAxis(this.world, 'x', this.x, ox, this.vx);
      this.vx = 0;
    }

    // --- Z axis ---
    this.z = this.z + this.vz * dt;
    if (collides(this.world, this.x, this.y, this.z)) {
      this.z = resolveAxis(this.world, 'z', this.z, oz, this.vz);
      this.vz = 0;
    }

    // --- Y axis ---
    this.y = this.y + this.vy * dt;
    const wasGrounded = this.grounded;
    this.grounded = false;
    if (collides(this.world, this.x, this.y, this.z)) {
      const vy = this.vy;
      this.y = resolveAxis(this.world, 'y', this.y, oy, vy);
      if (vy < 0) this.grounded = true;
      this.vy = 0;
    }

    // Grounded detection: solid block directly under the feet?
    const gy = Math.floor(this.y - 0.001);
    const checkSolid = (cx, cz) => {
      const bx = Math.floor(cx), bz = Math.floor(cz);
      return isSolid(this.world.getBlock(bx, gy, bz));
    };
    if (checkSolid(this.x - PLAYER_HALF_W + 0.05, this.z - PLAYER_HALF_W + 0.05) ||
        checkSolid(this.x + PLAYER_HALF_W - 0.05, this.z + PLAYER_HALF_W - 0.05) ||
        checkSolid(this.x, this.z)) {
      this.grounded = true;
    }

    // Keep inside the world horizontally
    const w = this.world.size;
    if (this.x < PLAYER_HALF_W) this.x = PLAYER_HALF_W;
    if (this.x > w.x - PLAYER_HALF_W) this.x = w.x - PLAYER_HALF_W;
    if (this.z < PLAYER_HALF_W) this.z = PLAYER_HALF_W;
    if (this.z > w.z - PLAYER_HALF_W) this.z = w.z - PLAYER_HALF_W;
    if (this.y < 0) { this.y = 0; this.vy = 0; this.grounded = true; }
  }

  get position() { return { x: this.x, y: this.y, z: this.z }; }
}
