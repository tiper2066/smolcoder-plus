# Block Meadow

A playable Minecraft-inspired voxel sandbox built with vanilla JavaScript, [Three.js](https://threejs.org/), and [Vite](https://vitejs.dev/).

## Features

- **Seeded deterministic terrain** — 56×56×32 world with rolling hills, grass/dirt/stone layers, trees, and a lake
- **First-person controls** — pointer-lock mouse look, WASD movement, gravity, jumping, solid AABB collision on all axes
- **Block editing** — left-click to break, right-click to place; visible target outline and crosshair
- **5-block hotbar** — grass, dirt, stone, wood, leaves (keys 1–5)
- **Save / Load / New World** — terrain edits, selected block, and player position persist in `localStorage`
- **Live FPS display**, ambient + directional lighting, attractive start/pause screen
- **`window.voxelDebug`** API for external inspection (see below)

## Quick start

```bash
npm install
npm run dev        # → http://localhost:5173
```

## Production build

```bash
npm run build      # outputs to dist/
npm run preview    # serves the built files at http://localhost:4173
```

## Tests

```bash
npm test           # runs 13 Node.js built-in test-runner tests (tests/*.test.js)
```

Covered: deterministic terrain generation, block bounds, edit persistence round-trip,
persistence module with invalid-data safety, solid-block collision, grounded jump,
frame-delta clamping, wall collision, AABB placement check, DDA raycast, `getBlock`.

## Controls

| Input | Action |
|---|---|
| Mouse move | Look around (pointer lock) |
| WASD | Move |
| Space | Jump |
| Left click | Break targeted block |
| Right click | Place selected block on adjacent face |
| 1–5 | Select grass / dirt / stone / wood / leaves |
| Esc | Pause / unlock pointer |

## Debug API

`window.voxelDebug` is exposed in the browser:

```js
voxelDebug.snapshot()
// → { player: {x,y,z}, selected: blockType, targeted: {x,y,z}|null, editCount: number }

voxelDebug.getBlock(x, y, z)   // → block type (0 = air)
voxelDebug.teleport(x, y, z)   // move the player
```

## Project structure

```
index.html              — DOM shell, HUD, start menu
src/
  main.js               — entry point
  game.js               — game loop, input, editing, save/load wiring
  persistence.js        — localStorage save/load (safe against bad data)
  world/
    blocks.js           — block type constants, palette, helpers
    noise.js            — seeded 2-D value noise
    world.js            — terrain generation, block storage, raycast-able grid
    player.js           — physics: gravity, collision, jump, clamped dt
    raycast.js          — DDA voxel raycast + placement cell helper
  render/
    renderer.js         — Three.js scene, lights, per-type meshes
    faceBuilder.js      — exposed-face mesh builder (no hidden faces)
tests/
  world.test.js         — Node test-runner suite
.scratch/
  browser-check.mjs     — Playwright end-to-end verification (34 checks)
```

## Browser verification

An end-to-end script (`.scratch/browser-check.mjs`) was run against the built
app with Playwright/Chromium, verifying all 34 checks: startup, `voxelDebug`
API shape, HUD elements and aria attributes, hotbar selection via number keys,
break/place editing with live `getBlock` reads, save + reload persistence, and
New World reset.

## Known limitations

- No block textures — flat colors per block type (grass top vs. side via two-tone material)
- Water is decorative (non-solid, non-placeable)
- Single world slot in `localStorage` (no multiple saved worlds)
- No multiplayer, no inventory, no item drops
