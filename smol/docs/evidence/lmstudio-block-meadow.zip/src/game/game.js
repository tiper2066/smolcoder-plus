// Game: wires world, player, renderer, input, UI and save together.
// Owns the game loop and the edit (remove/place) rules.
import { World } from '../world/world.js';
import { Player, clampDt } from '../player/player.js';
import { blockOverlapsPlayer } from '../player/collision.js';
import { raycastVoxel } from '../render/voxelRay.js';
import { Renderer } from '../render/renderer.js';
import { Input } from './input.js';
import { UI } from '../ui/ui.js';
import {
  saveWorld, loadWorld, savePlayer, loadPlayer, saveSelected, loadSelected, clearSave
} from './save.js';
import { HOTBAR, AIR, BLOCK_TYPES } from '../world/blocks.js';
import { inBounds } from '../world/terrain.js';

export const REACH = 6; // blocks

export class Game {
  constructor(canvas, uiRoot) {
    this.canvas = canvas;
    this.uiRoot = uiRoot;

    // ---- World & player ----
    const savedWorld = loadWorld();
    this.world = savedWorld ?? new World();
    if (savedWorld) this.world.setWorldSize?.(this.world.size);
    this.player = new Player(this.world);
    const savedPos = loadPlayer();
    if (savedPos) {
      this.player.position = { x: savedPos.x, y: savedPos.y, z: savedPos.z };
      if (!this.player.world.isSolid(Math.floor(savedPos.x), Math.floor(savedPos.y) - 1, Math.floor(savedPos.z))) {
        this.player.spawnAboveTerrain();
      }
    } else {
      this.player.spawnAboveTerrain();
    }
    this.selected = loadSelected();

    // ---- Renderer & UI ----
    this.renderer = new Renderer(canvas);
    this.renderer.setWorldSize(this.world.size);
    this.renderer.rebuild(this.world);
    this.ui = new UI(uiRoot);
    this.ui.setSelected(this.selected);

    // ---- Input ----
    this.input = new Input(canvas);
    this.input.onLockChange = (locked) => {
      if (locked) {
        this.paused = false;
        this.ui.hideOverlay();
        this._lastT = performance.now();
      } else {
        this.paused = true;
        this.ui.showOverlay('pause');
        this._autoSave();
      }
    };

    // Buttons.
    if (this.ui.pauseBtn) this.ui.pauseBtn.addEventListener('click', () => {
      if (!this.input.locked) this.input.requestLock();
    });
    const newWorld = () => this._newWorld();
    if (this.ui.newBtn) this.ui.newBtn.addEventListener('click', newWorld);
    if (this.ui.newBtn2) this.ui.newBtn2.addEventListener('click', newWorld);
    if (this.ui.saveBtn) this.ui.saveBtn.addEventListener('click', () => {
      this._autoSave();
      this.ui.flash('World saved');
    });
    if (this.ui.saveBtn2) this.ui.saveBtn2.addEventListener('click', () => {
      this._autoSave();
      this.ui.flash('World saved');
    });
    // Click on canvas when not locked -> lock.
    this.canvas.addEventListener('click', (e) => {
      if (!this.input.locked) this.input.requestLock();
    });

    // ---- State ----
    this.paused = true;
    this._lastT = performance.now();
    this._fpsAccum = 0;
    this._fpsFrames = 0;
    this.targeted = null; // {x,y,z} or null

    this._loop = this._loop.bind(this);
    requestAnimationFrame(this._loop);
  }

  _newWorld() {
    const ok = window.confirm('Create a new world? Current edits will be discarded.');
    if (!ok) return;
    clearSave();
    this.world = new World();
    this.player.setWorld(this.world);
    this.player.spawnAboveTerrain();
    this.renderer.setWorldSize(this.world.size);
    this.renderer.rebuild(this.world);
    this.targeted = null;
    this._autoSave();
    this.ui.flash('New world created');
  }

  _autoSave() {
    saveWorld(this.world);
    savePlayer(this.player);
    saveSelected(this.selected);
  }

  // Apply input deltas to the player facing.
  _applyMouseLook(frame) {
    const sens = 0.0024;
    this.player.facing.yaw -= frame.mouse.dx * sens;
    this.player.facing.pitch -= frame.mouse.dy * sens;
    const lim = Math.PI / 2 - 0.02;
    if (this.player.facing.pitch > lim) this.player.facing.pitch = lim;
    if (this.player.facing.pitch < -lim) this.player.facing.pitch = -lim;
  }

  _getCameraRay() {
    const p = this.player;
    const origin = {
      x: p.position.x,
      y: p.position.y + 1.55,
      z: p.position.z
    };
    const { yaw, pitch } = p.facing;
    const cp = Math.cos(pitch);
    const dir = {
      x: -Math.sin(yaw) * cp,
      y: -Math.sin(pitch),
      z: -Math.cos(yaw) * cp
    };
    return { origin, dir };
  }

  _updateTargeting() {
    const { origin, dir } = this._getCameraRay();
    const hit = raycastVoxel(this.world, origin, dir, REACH);
    this.targeted = hit ? { x: hit.x, y: hit.y, z: hit.z } : null;
    if (hit) this.renderer.setTarget(hit.x, hit.y, hit.z);
    else this.renderer.setTarget(null);
  }

  _doEdit(frame) {
    if (!frame.left && !frame.right) return;
    this._updateTargeting();
    const t = this.targeted;
    if (!t) return;

    const { origin, dir } = this._getCameraRay();
    const hit = raycastVoxel(this.world, origin, dir, REACH);
    if (!hit || !hit.face) return;

    if (frame.left) {
      this.world.removeBlock(t.x, t.y, t.z);
    } else {
      const px = t.x + hit.face.x;
      const py = t.y + hit.face.y;
      const pz = t.z + hit.face.z;
      if (!inBounds(px, py, pz)) return;
      if (this.world.getBlock(px, py, pz) !== AIR) return;
      const p = this.player.position;
      if (blockOverlapsPlayer(px, py, pz, p.x, p.y, p.z)) return;
      this.world.placeBlock(px, py, pz, this.selected);
    }
    this.renderer.rebuild(this.world);
    this._autoSave();
  }

  _selectHotbar(frame) {
    if (!frame.hotbar) return;
    const idx = Number(frame.hotbar) - 1;
    if (idx >= 0 && idx < HOTBAR.length) {
      this.selected = HOTBAR[idx];
      this.ui.setSelected(this.selected);
      saveSelected(this.selected);
    }
  }

  _loop(now) {
    requestAnimationFrame(this._loop);
    const dt = clampDt((now - this._lastT) / 1000);
    this._lastT = now;

    if (!this.paused && this.input.locked) {
      const frame = this.input.consume();
      this._applyMouseLook(frame);
      this._selectHotbar(frame);
      this.player.step(frame.keys, dt);
      this._doEdit(frame);
      this._updateTargeting();
    } else {
      // Still process hotbar selection even when paused/unlocked.
      const frame = this.input.consume();
      this._selectHotbar(frame);
    }

    this.renderer.updateCamera(this.player);
    this.renderer.render();

    // FPS
    this._fpsAccum += (now - (this._prevNow ?? now)) || 1;
    this._fpsFrames++;
    if (this._fpsAccum > 500) {
      const fps = (this._fpsFrames * 1000) / this._fpsAccum;
      this.ui.showFPS(fps);
      this._fpsAccum = 0;
      this._fpsFrames = 0;
    }
    this._prevNow = now;
  }

  // ---- Debug API (window.voxelDebug) ----
  snapshot() {
    return {
      player: {
        x: this.player.position.x,
        y: this.player.position.y,
        z: this.player.position.z
      },
      selected: BLOCK_TYPES[this.selected] ?? String(this.selected),
      targeted: this.targeted,
      editCount: this.world.editCount
    };
  }

  getBlock(x, y, z) {
    const t = this.world.getBlock(x, y, z);
    if (t === AIR) return 0;
    return BLOCK_TYPES[t] ?? t;
  }

  teleport(x, y, z) {
    if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return false;
    this.player.position.x = x;
    this.player.position.y = y;
    this.player.position.z = z;
    this.player.velocity = { x: 0, y: 0, z: 0 };
    return true;
  }
}
