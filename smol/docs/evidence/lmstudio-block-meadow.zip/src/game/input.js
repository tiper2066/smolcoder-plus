// Input state: keyboard, mouse, pointer lock.
// Reads from a canvas element; exposes `keys` and `mouse` state to the game loop.
export class Input {
  constructor(canvas) {
    this.canvas = canvas;
    this.keys = {
      forward: false, back: false, left: false, right: false,
      jump: false, sprint: false
    };
    this.mouse = { dx: 0, dy: 0 };
    this.clicks = { left: false, right: false };
    this.hoverKey = null; // most recent "1".."5" or "0" for hotbar
    this.locked = false;

    this.onLockChange = null;

    this._keydown = (e) => {
      const k = this._codeKey(e.code);
      if (k !== null) this.keys[k] = true;
      if (e.code.startsWith('Digit')) {
        const n = Number(e.code.slice(5));
        if (n >= 1 && n <= 5) this.hoverKey = String(n);
      }
    };
    this._keyup = (e) => {
      const k = this._codeKey(e.code);
      if (k !== null) this.keys[k] = false;
    };
    this._mousemove = (e) => {
      if (!this.locked) return;
      this.mouse.dx += e.movementX;
      this.mouse.dy += e.movementY;
    };
    this._mousedown = (e) => {
      if (!this.locked) return;
      if (e.button === 0) this.clicks.left = true;
      else if (e.button === 2) this.clicks.right = true;
    };
    this._contextmenu = (e) => e.preventDefault();
    this._lockchange = () => {
      this.locked = document.pointerLockElement === this.canvas;
      if (!this.locked) {
        // Reset held keys when unlocked so no keys stick after pause.
        for (const k in this.keys) this.keys[k] = false;
      }
      if (this.onLockChange) this.onLockChange(this.locked);
    };

    window.addEventListener('keydown', this._keydown);
    window.addEventListener('keyup', this._keyup);
    window.addEventListener('mousemove', this._mousemove);
    this.canvas.addEventListener('mousedown', this._mousedown);
    this.canvas.addEventListener('contextmenu', this._contextmenu);
    document.addEventListener('pointerlockchange', this._lockchange);
  }

  _codeKey(code) {
    switch (code) {
      case 'KeyW': case 'ArrowUp': return 'forward';
      case 'KeyS': case 'ArrowDown': return 'back';
      case 'KeyA': case 'ArrowLeft': return 'left';
      case 'KeyD': case 'ArrowRight': return 'right';
      case 'Space': return 'jump';
      case 'ShiftLeft': case 'ShiftRight': return 'sprint';
      default: return null;
    }
  }

  // Consume one frame of input. Returns the input object for this frame,
  // zeroed deltas, and sets the clicked flags (game should consume and reset).
  consume() {
    const frame = {
      keys: { ...this.keys },
      mouse: { dx: this.mouse.dx, dy: this.mouse.dy },
      left: this.clicks.left,
      right: this.clicks.right,
      hotbar: this.hoverKey
    };
    this.mouse.dx = 0;
    this.mouse.dy = 0;
    this.clicks.left = false;
    this.clicks.right = false;
    this.hoverKey = null;
    return frame;
  }

  requestLock() {
    this.canvas.requestPointerLock();
  }

  releaseLock() {
    if (document.pointerLockElement) document.exitPointerLock();
  }

  destroy() {
    window.removeEventListener('keydown', this._keydown);
    window.removeEventListener('keyup', this._keyup);
    window.removeEventListener('mousemove', this._mousemove);
    this.canvas.removeEventListener('mousedown', this._mousedown);
    this.canvas.removeEventListener('contextmenu', this._contextmenu);
    document.removeEventListener('pointerlockchange', this._lockchange);
  }
}
