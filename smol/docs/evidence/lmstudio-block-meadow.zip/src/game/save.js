// Save/load to localStorage with validation. Never throws to the caller.
import { World } from '../world/world.js';
import { HOTBAR, isValidBlockType } from '../world/blocks.js';

const KEY_WORLD = 'blockMeadow.world.v1';
const KEY_PLAYER = 'blockMeadow.player.v1';
const KEY_SELECTED = 'blockMeadow.selected.v1';

export function saveWorld(world) {
  try {
    localStorage.setItem(KEY_WORLD, JSON.stringify(world.serialize()));
    return true;
  } catch {
    return false;
  }
}

export function loadWorld() {
  try {
    const raw = localStorage.getItem(KEY_WORLD);
    if (!raw) return null;
    const data = JSON.parse(raw);
    return World.fromSerialized(data);
  } catch {
    return null;
  }
}

export function savePlayer(player) {
  try {
    localStorage.setItem(
      KEY_PLAYER,
      JSON.stringify({
        x: player.position.x,
        y: player.position.y,
        z: player.position.z
      })
    );
    return true;
  } catch {
    return false;
  }
}

export function loadPlayer() {
  try {
    const raw = localStorage.getItem(KEY_PLAYER);
    if (!raw) return null;
    const d = JSON.parse(raw);
    if (
      typeof d.x !== 'number' || typeof d.y !== 'number' || typeof d.z !== 'number' ||
      !Number.isFinite(d.x) || !Number.isFinite(d.y) || !Number.isFinite(d.z)
    ) return null;
    return { x: d.x, y: d.y, z: d.z };
  } catch {
    return null;
  }
}

export function saveSelected(type) {
  try {
    localStorage.setItem(KEY_SELECTED, JSON.stringify(type));
    return true;
  } catch {
    return false;
  }
}

export function loadSelected() {
  try {
    const raw = localStorage.getItem(KEY_SELECTED);
    if (!raw) return HOTBAR[0];
    const t = Number(JSON.parse(raw));
    return isValidBlockType(t) ? t : HOTBAR[0];
  } catch {
    return HOTBAR[0];
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(KEY_WORLD);
    localStorage.removeItem(KEY_PLAYER);
    localStorage.removeItem(KEY_SELECTED);
    return true;
  } catch {
    return false;
  }
}
