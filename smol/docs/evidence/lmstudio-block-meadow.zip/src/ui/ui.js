// DOM UI: start/pause overlay, crosshair, FPS, hotbar, save/new-world buttons.
// All styling is inline; no external assets.
import { HOTBAR, BLOCK_TYPES, BLOCK_COLORS } from '../world/blocks.js';

function cssColor(hex) {
  return '#' + hex.toString(16).padStart(6, '0');
}

export class UI {
  constructor(root) {
    this.root = root;
    this.crosshair = null;
    this.fps = null;
    this.hotbar = null;
    this.overlay = null;
    this.pauseBtn = null;
    this.saveBtn = null;
    this.newBtn = null;

    this._build();
  }

  _build() {
    // Crosshair.
    this.crosshair = document.createElement('div');
    this.crosshair.className = 'crosshair';
    this.crosshair.innerHTML = `<span class="ch-h"></span><span class="ch-v"></span>`;
    this.root.appendChild(this.crosshair);

    // FPS.
    this.fps = document.createElement('div');
    this.fps.className = 'fps';
    this.fps.textContent = 'FPS  --';
    this.root.appendChild(this.fps);

    // Hotbar.
    this.hotbar = document.createElement('div');
    this.hotbar.className = 'hotbar';
    for (let i = 0; i < HOTBAR.length; i++) {
      const t = HOTBAR[i];
      const cell = document.createElement('div');
      cell.className = 'hotbar-cell';
      cell.dataset.type = String(t);
      const sw = document.createElement('div');
      sw.className = 'swatch';
      sw.style.background = cssColor(BLOCK_COLORS[t]);
      const label = document.createElement('span');
      label.textContent = String(i + 1);
      const name = document.createElement('em');
      name.textContent = BLOCK_TYPES[t];
      cell.append(sw, label, name);
      this.hotbar.appendChild(cell);
    }
    this.root.appendChild(this.hotbar);

    // Action buttons (bottom-left, in-game).
    const actions = document.createElement('div');
    actions.className = 'actions';
    this.saveBtn = this._button('Save', 'btn');
    this.newBtn = this._button('New World', 'btn btn-danger');
    actions.append(this.saveBtn, this.newBtn);
    this.root.appendChild(actions);

    // Overlay (start + pause share one element).
    this.overlay = document.createElement('div');
    this.overlay.className = 'overlay';
    this.overlay.innerHTML = `
      <div class="card">
        <h1>Block Meadow</h1>
        <p class="tag">A tiny voxel sandbox</p>
        <ul class="controls">
          <li><b>WASD</b> — move</li>
          <li><b>Mouse</b> — look around</li>
          <li><b>Space</b> — jump</li>
          <li><b>Shift</b> — sprint</li>
          <li><b>Left click</b> — remove block</li>
          <li><b>Right click</b> — place block</li>
          <li><b>1–5</b> — select block</li>
          <li><b>Esc</b> — pause</li>
        </ul>
        <p class="palette">
          <span class="swatch" style="background:${cssColor(BLOCK_COLORS[1])}"></span> grass
          <span class="swatch" style="background:${cssColor(BLOCK_COLORS[2])}"></span> dirt
          <span class="swatch" style="background:${cssColor(BLOCK_COLORS[3])}"></span> stone
          <span class="swatch" style="background:${cssColor(BLOCK_COLORS[4])}"></span> wood
          <span class="swatch" style="background:${cssColor(BLOCK_COLORS[5])}"></span> leaves
        </p>
        <div class="row">
          <button id="play" class="btn btn-primary">Play</button>
          <button id="save" class="btn">Save</button>
          <button id="reset" class="btn btn-danger">New World</button>
        </div>
        <p class="hint">Progress is saved to your browser automatically.</p>
      </div>`;
    this.root.appendChild(this.overlay);

    this.pauseBtn = this.overlay.querySelector('#play');
    this.saveBtn2 = this.overlay.querySelector('#save');
    this.newBtn2 = this.overlay.querySelector('#reset');
  }

  _button(text, cls) {
    const b = document.createElement('button');
    b.className = cls;
    b.textContent = text;
    return b;
  }

  setSelected(type) {
    const cells = this.hotbar.querySelectorAll('.hotbar-cell');
    cells.forEach((c) => {
      c.classList.toggle('selected', Number(c.dataset.type) === type);
    });
  }

  showFPS(fps) {
    this.fps.textContent = 'FPS  ' + Math.round(fps);
  }

  showOverlay(title) {
    this.overlay.classList.remove('hidden');
    this.pauseBtn.textContent = title === 'pause' ? 'Resume' : 'Play';
  }

  hideOverlay() {
    this.overlay.classList.add('hidden');
  }

  flash(message) {
    let el = this.root.querySelector('.flash');
    if (!el) {
      el = document.createElement('div');
      el.className = 'flash';
      this.root.appendChild(el);
    }
    el.textContent = message;
    clearTimeout(this._flashT);
    this._flashT = setTimeout(() => { el.textContent = ''; }, 1400);
  }
}
