// First-person player: position, velocity, gravity, jump, movement + collision.
import { boxIntersectsWorld, moveAxis, PLAYER_HEIGHT } from './collision.js';

export const GRAVITY = 22; // blocks/s^2
export const JUMP_SPEED = 8.4;
export const WALK_SPEED = 5.2; // blocks/s
export const SPRINT_SPEED = 8.0;
export const MAX_FALL = 40;
// Clamp per-frame delta so a backgrounded tab never launches or buries the player.
export const MAX_DT = 1 / 20; // 50 ms

export function clampDt(dt) {
  if (!Number.isFinite(dt) || dt < 0) return 0;
  return Math.min(dt, MAX_DT);
}

// True when a solid block sits directly below the feet (foot box).
function feetSupported(world, x, y, z) {
  const by = Math.floor(y - 1e-4) - 1;
  return (
    world.isSolid(Math.floor(x - 0.25), by, Math.floor(z)) ||
    world.isSolid(Math.floor(x + 0.25), by, Math.floor(z)) ||
    world.isSolid(Math.floor(x), by, Math.floor(z - 0.25)) ||
    world.isSolid(Math.floor(x), by, Math.floor(z + 0.25)) ||
    world.isSolid(Math.floor(x), by, Math.floor(z))
  );
}

export class Player {
  constructor(world, x = 24, y = 20, z = 24) {
    this.world = world;
    this.position = { x, y, z }; // feet
    this.velocity = { x: 0, y: 0, z: 0 };
    this.grounded = false;
    this.facing = { yaw: 0, pitch: 0 };
  }

  // Drop from spawn until a safe standing spot is found.
  spawnAboveTerrain() {
    const { x, z } = this.position;
    let y = this.world.height - 1;
    while (y > 0 && !this.world.isSolid(x, y, z)) y--;
    if (this.world.isSolid(x, y, z)) this.position.y = y + 1;
    let guard = 0;
    while (
      boxIntersectsWorld(this.world, this.position.x, this.position.y, this.position.z) &&
      guard++ < 10
    ) {
      this.position.x += 1;
    }
    this.velocity = { x: 0, y: 0, z: 0 };
    this.grounded = false;
  }

  setWorld(world) {
    this.world = world;
  }

  // inputs: { forward, back, left, right, jump, sprint } booleans; dt seconds.
  step(inputs, dt) {
    dt = clampDt(dt);
    const speed = inputs.sprint ? SPRINT_SPEED : WALK_SPEED;
    const { yaw } = this.facing;
    const sin = Math.sin(yaw);
    const cos = Math.cos(yaw);

    let mx = 0;
    let mz = 0;
    if (inputs.forward) { mx -= sin * speed; mz -= cos * speed; }
    if (inputs.back) { mx += sin * speed; mz += cos * speed; }
    if (inputs.left) { mx -= cos * speed; mz += sin * speed; }
    if (inputs.right) { mx += cos * speed; mz -= sin * speed; }

    this.velocity.y -= GRAVITY * dt;
    if (this.velocity.y < -MAX_FALL) this.velocity.y = -MAX_FALL;

    if (inputs.jump && this.grounded) {
      this.velocity.y = JUMP_SPEED;
      this.grounded = false;
    }

    const p = this.position;
    const nx = moveAxis(this.world, 'x', p.x, mx * dt, p.y, p.x, p.z);
    const nz = moveAxis(this.world, 'z', p.z, mz * dt, p.y, nx, p.z);
    p.x = nx;
    p.z = nz;

    const dy = this.velocity.y * dt;
    const newY = moveAxis(this.world, 'y', p.y, dy, p.y, p.x, p.z);
    if (newY !== p.y) {
      // Moved freely in Y (in the air).
      this.grounded = false;
    } else if (dy < 0) {
      // Fell and stopped: landed.
      this.grounded = true;
      this.velocity.y = 0;
    } else if (dy > 0) {
      // Rose and stopped: hit ceiling.
      this.velocity.y = 0;
      this.grounded = false;
    }
    p.y = newY;
  }
}
