// Voxel AABB collision helpers. Pure functions over a World-like object
// (needs: isSolid(x,y,z)). Player is an axis-aligned box of width PLAYER_WIDTH
// centered on (x,z) and spanning [y, y+PLAYER_HEIGHT].
export const PLAYER_WIDTH = 0.6;
export const PLAYER_HEIGHT = 1.7;
export const HALF_W = PLAYER_WIDTH / 2;
const EPS = 1e-6;

// True if the player box at (x, y, z) overlaps any solid block.
// (x,z) is center; y is the feet.
export function boxIntersectsWorld(world, x, y, z) {
  const minX = Math.floor(x - HALF_W);
  const maxX = Math.floor(x + HALF_W);
  const minY = Math.floor(y);
  const maxY = Math.floor(y + PLAYER_HEIGHT - EPS);
  const minZ = Math.floor(z - HALF_W);
  const maxZ = Math.floor(z + HALF_W);

  for (let bx = minX; bx <= maxX; bx++) {
    for (let by = minY; by <= maxY; by++) {
      for (let bz = minZ; bz <= maxZ; bz++) {
        if (world.isSolid(bx, by, bz)) return true;
      }
    }
  }
  return false;
}

// Move the player along one axis, stopping at the first collision.
// If the full delta would land inside a solid, snap to the boundary face.
// Returns the resulting coordinate.
export function moveAxis(world, axis, pos, delta, yFeet, x, z) {
  if (delta === 0) return pos;
  const target = pos + delta;

  // Fast path: no collision at the destination.
  let nx = x, ny = yFeet, nz = z;
  if (axis === 'x') nx = target;
  else if (axis === 'y') ny = target;
  else nz = target;
  if (!boxIntersectsWorld(world, nx, ny, nz)) return target;

  // Binary-search for the closest free position along the axis.
  let lo = pos, hi = target;
  for (let i = 0; i < 32; i++) {
    const mid = (lo + hi) / 2;
    let mx = x, my = yFeet, mz = z;
    if (axis === 'x') mx = mid;
    else if (axis === 'y') my = mid;
    else mz = mid;
    if (boxIntersectsWorld(world, mx, my, mz)) hi = mid;
    else lo = mid;
  }
  return lo;
}

// True if a solid block at (bx,by,bz) overlaps the player box (placement rule).
export function blockOverlapsPlayer(bx, by, bz, px, py, pz) {
  return (
    bx + 1 > px - HALF_W &&
    bx < px + HALF_W &&
    by + 1 > py &&
    by < py + PLAYER_HEIGHT &&
    bz + 1 > pz - HALF_W &&
    bz < pz + HALF_W
  );
}
