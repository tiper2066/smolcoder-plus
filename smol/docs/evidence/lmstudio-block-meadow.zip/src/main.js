// Entry point: create the game and expose the debug API.
import './styles.css';
import { Game } from './game/game.js';

const canvas = document.getElementById('game');
const uiRoot = document.getElementById('ui');

const game = new Game(canvas, uiRoot);

window.voxelDebug = {
  snapshot: () => game.snapshot(),
  getBlock: (x, y, z) => game.getBlock(x, y, z),
  teleport: (x, y, z) => game.teleport(x, y, z)
};

window.addEventListener('resize', () => game.renderer.resize());
