// Three.js renderer: scene, lighting, sky, instanced terrain with
// exposed-face culling, target outline, and frame updates.
import * as THREE from 'three';
import { BLOCK_COLORS, HOTBAR, AIR, WATER, isSolid } from '../world/blocks.js';

const TYPE_TO_INDEX = { 1: 0, 2: 1, 3: 2, 4: 3, 5: 4 };

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9fd4f5); // sky
    this.scene.fog = new THREE.Fog(0x9fd4f5, 40, 120);

    this.camera = new THREE.PerspectiveCamera(70, 1, 0.1, 400);
    this.camera.position.set(0, 20, 0);

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Lighting: soft ambient + a warm directional "sun".
    const ambient = new THREE.AmbientLight(0xffffff, 0.55);
    this.scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xfff2d4, 1.0);
    sun.position.set(40, 80, 20);
    this.scene.add(sun);
    const hemi = new THREE.HemisphereLight(0xcfe8ff, 0x6a8f5a, 0.35);
    this.scene.add(hemi);

    // Water plane (subtle, translucent) rendered as a single quad at water level.
    this.buildWater();

    this.meshes = {}; // type -> InstancedMesh
    this.buildMeshes();

    // Target outline box.
    const outlineGeo = new THREE.BoxGeometry(1.002, 1.002, 1.002);
    const outlineMat = new THREE.LineBasicMaterial({ color: 0x111111 });
    this.outline = new THREE.LineSegments(new THREE.EdgesGeometry(outlineGeo), outlineMat);
    this.outline.visible = false;
    this.scene.add(this.outline);

    this.resize();
  }

  buildWater() {
    // A translucent plane at y = water level across the whole world.
    const waterMat = new THREE.MeshLambertMaterial({
      color: BLOCK_COLORS[WATER],
      transparent: true,
      opacity: 0.72,
      depthWrite: false
    });
    const geo = new THREE.PlaneGeometry(this.worldSize ?? 48, this.worldSize ?? 48);
    this.waterMesh = new THREE.Mesh(geo, waterMat);
    this.waterMesh.rotation.x = -Math.PI / 2;
    this.waterMesh.position.set(24, 4.02, 24);
    this.scene.add(this.waterMesh);
  }

  buildMeshes() {
    const boxGeo = new THREE.BoxGeometry(1, 1, 1);
    for (const type of HOTBAR) {
      const mat = new THREE.MeshLambertMaterial({
        color: BLOCK_COLORS[type],
        // Slight per-face shading variation for visual interest.
        emissive: new THREE.Color(BLOCK_COLORS[type]).multiplyScalar(0.04)
      });
      const mesh = new THREE.InstancedMesh(boxGeo, mat, 0);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.count = 0;
      this.meshes[type] = mesh;
      this.scene.add(mesh);
    }
  }

  setWorldSize(size) {
    this.worldSize = size;
    if (this.waterMesh) {
      const g = new THREE.PlaneGeometry(size, size);
      this.waterMesh.geometry.dispose();
      this.waterMesh.geometry = g;
      this.waterMesh.position.set(size / 2, 4.02, size / 2);
    }
  }

  // Rebuild instance data for all block types (full world pass).
  // Only blocks with at least one exposed (air/water) neighbor are rendered.
  rebuild(world) {
    const counts = {};
    const list = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    for (const [k, t] of world.blocks) {
      if (!(t in list)) continue;
      const [x, y, z] = k.split(',').map(Number);
      if (
        world.getBlock(x + 1, y, z) === AIR ||
        world.getBlock(x - 1, y, z) === AIR ||
        world.getBlock(x, y + 1, z) === AIR ||
        world.getBlock(x, y - 1, z) === AIR ||
        world.getBlock(x, y, z + 1) === AIR ||
        world.getBlock(x, y, z - 1) === AIR ||
        world.getBlock(x + 1, y, z) === WATER ||
        world.getBlock(x - 1, y, z) === WATER ||
        world.getBlock(x, y + 1, z) === WATER ||
        world.getBlock(x, y, z + 1) === WATER ||
        world.getBlock(x, y, z - 1) === WATER
      ) {
        list[t].push([x, y, z]);
      }
    }
    const m = new THREE.Matrix4();
    for (const type of HOTBAR) {
      const arr = list[type];
      let mesh = this.meshes[type];
      if (arr.length > mesh.count) {
        mesh.dispose();
        const geo = new THREE.BoxGeometry(1, 1, 1);
        const mat = new THREE.MeshLambertMaterial({ color: BLOCK_COLORS[type] });
        mesh = new THREE.InstancedMesh(geo, mat, arr.length);
        mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.scene.remove(this.meshes[type]);
        this.meshes[type] = mesh;
        this.scene.add(mesh);
      }
      let i = 0;
      for (const [x, y, z] of arr) {
        m.setPosition(x + 0.5, y + 0.5, z + 0.5);
        mesh.setMatrixAt(i++, m);
      }
      mesh.count = i;
      mesh.instanceMatrix.needsUpdate = true;
    }
  }

  // Show the target outline around the block at (x,y,z) or hide it.
  setTarget(x, y, z) {
    if (x === null) {
      this.outline.visible = false;
      return;
    }
    this.outline.visible = true;
    this.outline.position.set(x + 0.5, y + 0.5, z + 0.5);
  }

  updateCamera(player) {
    const eyeY = player.position.y + 1.55;
    this.camera.position.set(player.position.x, eyeY, player.position.z);
    const { yaw, pitch } = player.facing;
    // Convert yaw/pitch to a quaternion (order: yaw around Y, then pitch around X).
    const q = new THREE.Quaternion();
    const qYaw = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
    const qPitch = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -pitch);
    q.multiplyQuaternions(qYaw, qPitch);
    this.camera.quaternion.copy(q);
  }

  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
