// DDA voxel ray cast (Amanatides & Woo). Returns the first solid block hit
// within `maxDist`, plus the face it hit (for placement) and the entry point.
import { isSolid } from '../world/blocks.js';

export function raycastVoxel(world, origin, dir, maxDist = 6) {
  let x = Math.floor(origin.x);
  let y = Math.floor(origin.y);
  let z = Math.floor(origin.z);

  const stepX = dir.x > 0 ? 1 : dir.x < 0 ? -1 : 0;
  const stepY = dir.y > 0 ? 1 : dir.y < 0 ? -1 : 0;
  const stepZ = dir.z > 0 ? 1 : dir.z < 0 ? -1 : 0;

  const tDeltaX = dir.x !== 0 ? Math.abs(1 / dir.x) : Infinity;
  const tDeltaY = dir.y !== 0 ? Math.abs(1 / dir.y) : Infinity;
  const tDeltaZ = dir.z !== 0 ? Math.abs(1 / dir.z) : Infinity;

  let tMaxX =
    dir.x > 0 ? (x + 1 - origin.x) / dir.x : dir.x < 0 ? (x - origin.x) / dir.x : Infinity;
  let tMaxY =
    dir.y > 0 ? (y + 1 - origin.y) / dir.y : dir.y < 0 ? (y - origin.y) / dir.y : Infinity;
  let tMaxZ =
    dir.z > 0 ? (z + 1 - origin.z) / dir.z : dir.z < 0 ? (z - origin.z) / dir.z : Infinity;

  let face = null; // last axis stepped -> placement offset
  let t = 0;

  while (t <= maxDist) {
    if (isSolid(world.getBlock(x, y, z))) {
      return {
        x, y, z,
        face, // {x: -1|0|1, y:..., z:...} or null if origin was inside a solid block
        t
      };
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      x += stepX; t = tMaxX; tMaxX += tDeltaX; face = { x: -stepX, y: 0, z: 0 };
    } else if (tMaxY < tMaxZ) {
      y += stepY; t = tMaxY; tMaxY += tDeltaY; face = { x: 0, y: -stepY, z: 0 };
    } else {
      z += stepZ; t = tMaxZ; tMaxZ += tDeltaZ; face = { x: 0, y: 0, z: -stepZ };
    }
  }
  return null;
}
