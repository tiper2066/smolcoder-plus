// Small, fast, seedable PRNG (mulberry32). Deterministic across platforms.
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Deterministic value-noise 2D, built on the seeded PRNG.
// Returns a smooth function noise(x, y) in [0, 1].
export function makeValueNoise2D(seed) {
  const rand = mulberry32(seed);

  // Hash a lattice cell to a stable pseudo-random value in [0,1].
  function hash(ix, iy) {
    let h = (ix * 374761393 + iy * 668265263) ^ (seed >>> 0);
    h = (h ^ (h >>> 13)) >>> 0;
    h = Math.imul(h, 1274126177) >>> 0;
    return (h >>> 8) / 16777216;
  }

  function smooth(t) {
    return t * t * (3 - 2 * t);
  }

  return function noise2D(x, y) {
    const ix = Math.floor(x);
    const iy = Math.floor(y);
    const fx = x - ix;
    const fy = y - iy;
    const a = hash(ix, iy);
    const b = hash(ix + 1, iy);
    const c = hash(ix, iy + 1);
    const d = hash(ix + 1, iy + 1);
    const u = smooth(fx);
    const v = smooth(fy);
    const top = a + (b - a) * u;
    const bottom = c + (d - c) * u;
    return top + (bottom - top) * v;
  };
}
