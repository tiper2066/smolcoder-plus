// Block type constants and metadata. 0 = air.
export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const WOOD = 4;
export const LEAVES = 5;
export const WATER = 6;

export const BLOCK_TYPES = {
  [GRASS]: 'grass',
  [DIRT]: 'dirt',
  [STONE]: 'stone',
  [WOOD]: 'wood',
  [LEAVES]: 'leaves',
  [WATER]: 'water'
};

// Order shown in the hotbar (keys 1-5).
export const HOTBAR = [GRASS, DIRT, STONE, WOOD, LEAVES];

// Colors used by the renderer (original palette).
export const BLOCK_COLORS = {
  [GRASS]: 0x6abf4b,
  [DIRT]: 0x8a5a33,
  [STONE]: 0x8d8d94,
  [WOOD]: 0x7a5230,
  [LEAVES]: 0x3f9e3f,
  [WATER]: 0x4a7fd4
};

export function isSolid(type) {
  return type !== AIR && type !== WATER;
}

export function isValidBlockType(type) {
  return (
    Number.isInteger(type) &&
    type >= GRASS &&
    type <= LEAVES
  );
}
