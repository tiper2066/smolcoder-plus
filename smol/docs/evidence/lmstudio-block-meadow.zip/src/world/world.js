// World: the live block store + edit API + bounds + persistence payload.
import {
  WORLD_SIZE,
  WORLD_HEIGHT,
  inBounds,
  generateTerrain,
  LAKE
} from './terrain.js';
import { AIR, WATER, isValidBlockType, isSolid } from './blocks.js';

const key = (x, y, z) => `${x},${y},${z}`;

export class World {
  constructor(seed = 1337) {
    this.seed = seed;
    this.size = WORLD_SIZE;
    this.height = WORLD_HEIGHT;
    this.lake = LAKE;
    this.blocks = generateTerrain(seed);
    this.editCount = 0;
    this.changed = new Set(); // keys touched by edits (for re-meshing)
  }

  getBlock(x, y, z) {
    if (!inBounds(x, y, z)) return AIR;
    const t = this.blocks.get(key(x, y, z));
    return t === undefined ? AIR : t;
  }

  setBlock(x, y, z, type) {
    if (!inBounds(x, y, z)) return false;
    if (type === AIR) {
      if (!this.blocks.has(key(x, y, z))) return false;
      this.blocks.delete(key(x, y, z));
    } else {
      if (!isValidBlockType(type)) return false;
      const k = key(x, y, z);
      if (this.blocks.get(k) === type) return false;
      this.blocks.set(k, type);
    }
    this.editCount++;
    this.changed.add(key(x, y, z));
    return true;
  }

  // Remove a block (left click).
  removeBlock(x, y, z) {
    const t = this.getBlock(x, y, z);
    if (t === AIR) return false;
    if (t === WATER) return false; // water is not breakable
    return this.setBlock(x, y, z, AIR);
  }

  // Place a block on a face adjacent to the targeted block.
  placeBlock(x, y, z, type) {
    if (this.getBlock(x, y, z) !== AIR) return false;
    return this.setBlock(x, y, z, type);
  }

  isSolid(x, y, z) {
    return isSolid(this.getBlock(x, y, z));
  }

  markAllChanged() {
    for (const k of this.blocks.keys()) this.changed.add(k);
  }

  // ---- Persistence ----
  serialize() {
    const edits = [];
    // Re-derive edits by diffing against a fresh deterministic terrain.
    const fresh = generateTerrain(this.seed);
    for (const [k, v] of this.blocks) {
      if (fresh.get(k) !== v) edits.push(k + ':' + v);
    }
    for (const k of fresh.keys()) {
      if (!this.blocks.has(k)) edits.push(k + ':0');
    }
    return {
      version: 1,
      seed: this.seed,
      size: this.size,
      height: this.height,
      editCount: this.editCount,
      edits
    };
  }

  static fromSerialized(data) {
    if (!data || typeof data !== 'object' || data.version !== 1) {
      throw new Error('bad world data');
    }
    if (!Number.isInteger(data.seed) || data.seed < 0 || data.seed > 0xffffffff) {
      throw new Error('bad seed');
    }
    if (!Array.isArray(data.edits)) throw new Error('bad edits');
    const w = new World(data.seed);
    for (const item of data.edits) {
      if (typeof item !== 'string') throw new Error('bad edit item');
      const ci = item.lastIndexOf(':');
      if (ci <= 0) throw new Error('bad edit item');
      const parts = item.slice(0, ci).split(',');
      if (parts.length !== 3) throw new Error('bad edit item');
      const x = Number(parts[0]);
      const y = Number(parts[1]);
      const z = Number(parts[2]);
      const type = Number(item.slice(ci + 1));
      if (!inBounds(x, y, z)) throw new Error('edit out of bounds');
      if (type === AIR || type === 0) w.blocks.delete(key(x, y, z));
      else {
        if (!isValidBlockType(type) && type !== 6) throw new Error('bad type');
        w.blocks.set(key(x, y, z), type);
      }
    }
    w.editCount = Number.isInteger(data.editCount) && data.editCount >= 0 ? data.editCount : 0;
    return w;
  }
}
