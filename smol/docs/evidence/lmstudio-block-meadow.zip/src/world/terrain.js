// Deterministic terrain generation: hills, a lake, grass/dirt/stone layers and trees.
import { makeValueNoise2D, mulberry32 } from './rng.js';
import { GRASS, DIRT, STONE, WOOD, LEAVES, WATER, AIR } from './blocks.js';

export const WORLD_SIZE = 48; // X and Z extent in blocks
export const WORLD_HEIGHT = 24; // Y extent in blocks

// The lake occupies a circular region.
export const LAKE = { cx: 30, cz: 30, r: 7 };

export function inBounds(x, y, z) {
  return (
    Number.isInteger(x) &&
    Number.isInteger(y) &&
    Number.isInteger(z) &&
    x >= 0 && x < WORLD_SIZE &&
    z >= 0 && z < WORLD_SIZE &&
    y >= 0 && y < WORLD_HEIGHT
  );
}

// Height of the terrain surface (index of the top solid block) at (x, z).
export function terrainHeight(x, z, seed) {
  if (x < 0 || x >= WORLD_SIZE || z < 0 || z >= WORLD_SIZE) return 0;
  const noise = makeValueNoise2D(seed);
  let h =
    4 +
    noise(x * 0.06, z * 0.06) * 7 +
    noise(x * 0.15, z * 0.15) * 3.2;

  // Flatten the lake basin.
  const dx = x - LAKE.cx;
  const dz = z - LAKE.cz;
  const d = Math.sqrt(dx * dx + dz * dz);
  if (d < LAKE.r) {
    const t = d / LAKE.r; // 0 center -> 1 edge
    h = 3 + t * t * 3.5; // sink toward the center
  }

  return Math.max(1, Math.min(WORLD_HEIGHT - 6, Math.floor(h)));
}

// Build the initial block grid as a plain object "x,y,z" -> type.
export function generateTerrain(seed) {
  const blocks = new Map();

  for (let x = 0; x < WORLD_SIZE; x++) {
    for (let z = 0; z < WORLD_SIZE; z++) {
      const h = terrainHeight(x, z, seed);
      const dx = x - LAKE.cx;
      const dz = z - LAKE.cz;
      const inLake = Math.sqrt(dx * dx + dz * dz) < LAKE.r;

      // Stone bed, dirt layer, grass top.
      for (let y = 0; y <= h; y++) {
        let type;
        if (inLake && y <= h - 1) {
          // Water fills the basin above bedrock, sand-free: water down to y=1.
          type = WATER;
        } else if (y === h) {
          type = inLake ? DIRT : GRASS;
        } else if (y >= h - 2) {
          type = DIRT;
        } else {
          type = STONE;
        }
        // Water sits where the surface is low, inside the lake radius.
        if (inLake && y > h && y <= 4) {
          blocks.set(`${x},${y},${z}`, WATER);
          continue;
        }
        blocks.set(`${x},${y},${z}`, type);
      }
    }
  }

  plantTrees(blocks, seed);
  return blocks;
}

// Deterministic trees on grass, away from the lake.
function plantTrees(blocks, seed) {
  const rand = mulberry32((seed ^ 0x9e3779b9) >>> 0);
  const key = (x, y, z) => `${x},${y},${z}`;

  for (let i = 0; i < 14; i++) {
    const x = 3 + Math.floor(rand() * (WORLD_SIZE - 6));
    const z = 3 + Math.floor(rand() * (WORLD_SIZE - 6));
    const dx = x - LAKE.cx;
    const dz = z - LAKE.cz;
    if (Math.sqrt(dx * dx + dz * dz) < LAKE.r + 2) continue;
    if (blocks.get(key(x, 0, z)) === undefined) continue;

    // Find surface.
    let y = WORLD_HEIGHT - 1;
    while (y > 0 && !isSurface(blocks, x, y, z)) y--;
    if (blocks.get(key(x, y, z)) !== GRASS) continue;
    if (blocks.get(key(x, y + 1, z)) !== undefined) continue;

    const trunkH = 4 + Math.floor(rand() * 2);
    for (let t = 1; t <= trunkH; t++) blocks.set(key(x, y + t, z), WOOD);
    const topY = y + trunkH;
    // Leaf cluster.
    for (let lx = -2; lx <= 2; lx++)
      for (let lz = -2; lz <= 2; lz++)
        for (let ly = -1; ly <= 1; ly++) {
          if (Math.abs(lx) + Math.abs(lz) + Math.abs(ly) > 3) continue;
          const k = key(x + lx, topY + ly, z + lz);
          if (!blocks.has(k)) blocks.set(k, LEAVES);
        }
    // Cap leaf.
    blocks.set(key(x, topY + 2, z), LEAVES);
  }
}

function isSurface(blocks, x, y, z) {
  const t = blocks.get(`${x},${y},${z}`);
  return t !== undefined && t !== AIR && t !== WATER;
}
