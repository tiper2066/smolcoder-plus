# Block Meadow

A tiny, original Minecraft-inspired voxel sandbox built with **Three.js** and **Vite**.
No external artwork — all visuals are generated from geometry and a hand-picked color palette.

## Quick start

```bash
npm install
npm run dev        # start the dev server (http://localhost:5173)
```

Open the printed URL in a browser. Click the **Play** button to lock the pointer and start.

## Controls

| Input            | Action                     |
| ---------------- | -------------------------- |
| **W A S D**      | Move                      |
| **Mouse**        | Look around               |
| **Space**        | Jump                      |
| **Shift**        | Sprint                    |
| **Left click**   | Remove targeted block     |
| **Right click**  | Place selected block      |
| **1 – 5**        | Select block (grass, dirt, stone, wood, leaves) |
| **Esc**          | Pause / unlock pointer    |

## Features

- **Seeded deterministic terrain** (48 × 48 blocks) with rolling hills, a small lake, grass/dirt/stone layers, and scattered trees.
- **First-person controls** with pointer lock, gravity, grounded jumping, and solid collision on all axes.
- **Block editing** — break blocks with left click, place with right click (never inside the player or outside the world).
- **Hotbar** with 5 selectable block types, shown with color swatches and labels.
- **Start / pause overlay** with controls, a color palette legend, and **Save** / **New World** buttons.
- **Live FPS counter** in the top-left corner.
- **Save & restore** — terrain edits, selected block, and player position persist to `localStorage`.
- **Debug API** — `window.voxelDebug` exposes `snapshot()`, `getBlock(x,y,z)`, and `teleport(x,y,z)` for automated verification.

## Development

```bash
npm test           # run the automated test suite (Node's built-in test runner)
npm run build      # production build to dist/
npm run preview    # serve the production build locally
```

### Tests

The suite covers:

- **Deterministic terrain** — same seed produces identical worlds; different seeds differ.
- **Terrain content** — grass/dirt/stone layers, a lake, and trees are all present.
- **Block bounds** — out-of-range coordinates are rejected; `getBlock` returns air outside the world.
- **Edit persistence** — `serialize` / `fromSerialized` round-trips edits; invalid data is rejected without crashing.
- **Collision & jump rules** — gravity, landing, jumping, wall collision, and large-delta clamping.
- **Save/load** — round-trips player position, selected block, and world edits; corrupted saves are handled gracefully.
- **Debug API** — `snapshot()`, `getBlock()`, and `teleport()` return correct values.

## Project structure

```
src/
  world/        blocks.js, rng.js, terrain.js, world.js
  player/       collision.js, player.js
  render/       renderer.js, voxelRay.js
  game/         input.js, save.js, game.js
  ui/           ui.js
  styles.css
  main.js
tests/          terrain, world, collision, save, debug tests
```

## Known limitations

- Terrain is regenerated from the seed + edit list on load; there is no streaming or chunking.
- The lake is a fixed circular basin; there is no flowing water or fluid simulation.
- Trees are placed deterministically but may occasionally overlap or sit on slopes.
- The WebGL context is faked in Node tests — rendering correctness must be verified in a browser.
