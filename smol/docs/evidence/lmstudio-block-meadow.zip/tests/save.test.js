import { test } from 'node:test';
import assert from 'node:assert/strict';
// A minimal in-memory localStorage shim so the module can run under Node.
const store = new Map();
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
  clear: () => store.clear()
};

const { saveWorld, loadWorld, savePlayer, loadPlayer, saveSelected, loadSelected, clearSave } = await import('../src/game/save.js');
const { World } = await import('../src/world/world.js');
const { GRASS, STONE, DIRT } = await import('../src/world/blocks.js');

test('save/load world round-trips edits', () => {
  clearSave();
  const w = new World(31);
  let grass = null;
  for (const [k, t] of w.blocks) {
    if (t === GRASS) { grass = k.split(',').map(Number); break; }
  }
  const [gx, gy, gz] = grass;
  w.removeBlock(gx, gy, gz);
  w.placeBlock(gx, gy + 1, gz, STONE);

  assert.ok(saveWorld(w), 'save should succeed');
  const loaded = loadWorld();
  assert.ok(loaded instanceof World);
  assert.equal(loaded.getBlock(gx, gy, gz), 0);
  assert.equal(loaded.getBlock(gx, gy + 1, gz), STONE);
});

test('loadWorld returns null when no save exists', () => {
  clearSave();
  assert.equal(loadWorld(), null);
});

test('loadWorld returns null (not throw) on corrupted save', () => {
  globalThis.localStorage.setItem('blockMeadow.world.v1', '{not json');
  assert.equal(loadWorld(), null);
});

test('loadWorld returns null on structurally invalid data', () => {
  globalThis.localStorage.setItem('blockMeadow.world.v1', JSON.stringify({ version: 99 }));
  assert.equal(loadWorld(), null);
  globalThis.localStorage.setItem('blockMeadow.world.v1', JSON.stringify({ version: 1, seed: -1 }));
  assert.equal(loadWorld(), null);
  globalThis.localStorage.setItem('blockMeadow.world.v1', JSON.stringify({ version: 1, seed: 1, edits: 'nope' }));
  assert.equal(loadWorld(), null);
});

test('save/load player position round-trips', () => {
  clearSave();
  const fake = { position: { x: 1.5, y: 2.5, z: 3.5 } };
  assert.ok(savePlayer(fake));
  const p = loadPlayer();
  assert.deepEqual(p, { x: 1.5, y: 2.5, z: 3.5 });
});

test('loadPlayer returns null on bad data', () => {
  globalThis.localStorage.setItem('blockMeadow.player.v1', 'nope');
  assert.equal(loadPlayer(), null);
  globalThis.localStorage.setItem('blockMeadow.player.v1', JSON.stringify({ x: 'a' }));
  assert.equal(loadPlayer(), null);
  globalThis.localStorage.setItem('blockMeadow.player.v1', JSON.stringify({ x: 1, y: 2 }));
  assert.equal(loadPlayer(), null);
});

test('save/load selected block round-trips', () => {
  clearSave();
  assert.ok(saveSelected(STONE));
  assert.equal(loadSelected(), STONE);
  assert.ok(saveSelected(DIRT));
  assert.equal(loadSelected(), DIRT);
});

test('loadSelected falls back to a valid default on bad data', () => {
  globalThis.localStorage.setItem('blockMeadow.selected.v1', '999');
  const t = loadSelected();
  assert.ok(t >= 1 && t <= 5, `expected a valid hotbar block, got ${t}`);
});

test('clearSave removes all keys', () => {
  saveWorld(new World(1));
  savePlayer({ position: { x: 1, y: 2, z: 3 } });
  saveSelected(1);
  clearSave();
  assert.equal(loadWorld(), null);
  assert.equal(loadPlayer(), null);
});
