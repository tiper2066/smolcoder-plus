import { test } from 'node:test';
import assert from 'node:assert/strict';
import { World } from '../src/world/world.js';
import { GRASS, DIRT, STONE, WOOD, LEAVES, AIR, WATER } from '../src/world/blocks.js';
import { inBounds } from '../src/world/terrain.js';

test('world exposes getBlock and in-bounds lookups', () => {
  const w = new World(11);
  // Top of the world should be air.
  assert.equal(w.getBlock(10, 30, 10), AIR);
  // Below that there should be some solid terrain.
  let found = false;
  for (let y = 1; y < 20; y++) {
    if (w.getBlock(10, y, 10) !== AIR && w.getBlock(10, y, 10) !== WATER) {
      found = true;
      break;
    }
  }
  assert.ok(found, 'expected solid terrain at (10,?,10)');
});

test('world.getBlock returns AIR outside bounds', () => {
  const w = new World(11);
  assert.equal(w.getBlock(-1, 0, 0), AIR);
  assert.equal(w.getBlock(100, 0, 0), AIR);
  assert.equal(w.getBlock(0, 100, 0), AIR);
});

test('world.removeBlock only removes existing solid blocks', () => {
  const w = new World(11);
  // Find a grass block.
  let target = null;
  for (const [k, t] of w.blocks) {
    if (t === GRASS) { target = k.split(',').map(Number); break; }
  }
  assert.ok(target, 'expected a grass block');
  const [x, y, z] = target;
  assert.ok(w.removeBlock(x, y, z), 'remove should succeed');
  assert.equal(w.getBlock(x, y, z), AIR);
  assert.equal(w.removeBlock(x, y, z), false, 'second remove should fail');
  assert.equal(w.editCount, 1);
});

test('world.removeBlock refuses water and air', () => {
  const w = new World(11);
  assert.equal(w.removeBlock(-5, -5, -5), false);
  // Water is not breakable.
  let water = null;
  for (const [k, t] of w.blocks) {
    if (t === WATER) { water = k.split(',').map(Number); break; }
  }
  if (water) {
    const [x, y, z] = water;
    assert.equal(w.removeBlock(x, y, z), false, 'water should not be removable');
  }
});

test('world.placeBlock only places in air inside bounds', () => {
  const w = new World(11);
  // Find an air cell adjacent to a solid block.
  let spot = null;
  outer: for (let x = 1; x < w.size - 1; x++) {
    for (let z = 1; z < w.size - 1; z++) {
      for (let y = 1; y < w.height - 1; y++) {
        if (w.getBlock(x, y, z) === AIR) { spot = [x, y, z]; break outer; }
      }
    }
  }
  assert.ok(spot, 'expected an air cell');
  const [x, y, z] = spot;
  assert.ok(w.placeBlock(x, y, z, STONE), 'place should succeed in air');
  assert.equal(w.getBlock(x, y, z), STONE);
  assert.equal(w.placeBlock(x, y, z, DIRT), false, 'place should fail where occupied');
  assert.equal(w.placeBlock(-1, 0, 0, STONE), false, 'place should fail out of bounds');
  assert.equal(w.placeBlock(0, 0, 0, 99), false, 'place should fail with invalid type');
});

test('world.setBlock rejects out-of-bounds and invalid types', () => {
  const w = new World(11);
  assert.equal(w.setBlock(-1, 0, 0, STONE), false);
  assert.equal(w.setBlock(0, 0, 0, 99), false);
  assert.equal(w.setBlock(0, 0, 0, 'x'), false);
});

test('world.serialize / fromSerialized round-trips edits', () => {
  const w = new World(21);
  // Make a few edits.
  let grass = null;
  for (const [k, t] of w.blocks) {
    if (t === GRASS) { grass = k.split(',').map(Number); break; }
  }
  const [gx, gy, gz] = grass;
  w.removeBlock(gx, gy, gz);
  w.placeBlock(gx, gy + 1, gz, WOOD);
  const data = w.serialize();
  const w2 = World.fromSerialized(data);
  assert.equal(w2.getBlock(gx, gy, gz), AIR);
  assert.equal(w2.getBlock(gx, gy + 1, gz), WOOD);
  // Other blocks should match.
  let checked = 0;
  for (const [k, t] of w.blocks) {
    if (checked++ > 200) break;
    const [x, y, z] = k.split(',').map(Number);
    assert.equal(w2.getBlock(x, y, z), t);
  }
});

test('World.fromSerialized rejects invalid data without crashing', () => {
  assert.throws(() => World.fromSerialized(null));
  assert.throws(() => World.fromSerialized({}));
  assert.throws(() => World.fromSerialized({ version: 1, seed: -1 }));
  assert.throws(() => World.fromSerialized({ version: 1, seed: 1, edits: 'nope' }));
  assert.throws(() => World.fromSerialized({ version: 1, seed: 1, edits: ['x,y,z:3'] }));
  assert.throws(() => World.fromSerialized({ version: 1, seed: 1, edits: ['0,0,0:99'] }));
  assert.throws(() => World.fromSerialized({ version: 1, seed: 1, edits: ['9999,0,0:3'] }));
});

test('World.fromSerialized accepts an empty edits list', () => {
  const data = { version: 1, seed: 5, edits: [] };
  const w = World.fromSerialized(data);
  assert.ok(w instanceof World);
});
