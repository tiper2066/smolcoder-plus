import { test } from 'node:test';
import assert from 'node:assert/strict';
import { generateTerrain, terrainHeight, WORLD_SIZE, WORLD_HEIGHT, inBounds, LAKE } from '../src/world/terrain.js';
import { GRASS, DIRT, STONE, WATER, AIR } from '../src/world/blocks.js';

test('terrain is deterministic for the same seed', () => {
  const a = generateTerrain(42);
  const b = generateTerrain(42);
  assert.deepEqual([...a.entries()].sort(), [...b.entries()].sort());
});

test('terrain differs for different seeds', () => {
  const a = generateTerrain(1);
  const b = generateTerrain(2);
  assert.notDeepEqual([...a.entries()].sort(), [...b.entries()].sort());
});

test('terrain is at least 48x48 blocks', () => {
  assert.ok(WORLD_SIZE >= 48, 'WORLD_SIZE must be >= 48');
});

test('terrain has grass, dirt and stone layers', () => {
  const t = generateTerrain(7);
  let grass = 0, dirt = 0, stone = 0;
  for (const v of t.values()) {
    if (v === GRASS) grass++;
    else if (v === DIRT) dirt++;
    else if (v === STONE) stone++;
  }
  assert.ok(grass > 0, 'expected grass blocks');
  assert.ok(dirt > 0, 'expected dirt blocks');
  assert.ok(stone > 0, 'expected stone blocks');
});

test('terrain has a lake (water blocks inside the lake radius)', () => {
  const t = generateTerrain(7);
  let water = 0;
  for (const [k] of t) {
    if (t.get(k) === WATER) water++;
  }
  assert.ok(water > 0, 'expected water blocks in the lake');
});

test('terrain has trees (wood + leaves)', () => {
  const t = generateTerrain(7);
  let wood = 0, leaves = 0;
  for (const v of t.values()) {
    if (v === 4) wood++;
    else if (v === 5) leaves++;
  }
  assert.ok(wood > 0, 'expected wood blocks (tree trunks)');
  assert.ok(leaves > 0, 'expected leaf blocks (tree canopies)');
});

test('terrainHeight is deterministic', () => {
  const h1 = terrainHeight(10, 20, 99);
  const h2 = terrainHeight(10, 20, 99);
  assert.equal(h1, h2);
});

test('inBounds rejects out-of-range coordinates', () => {
  assert.ok(inBounds(0, 0, 0));
  assert.ok(inBounds(WORLD_SIZE - 1, WORLD_HEIGHT - 1, WORLD_SIZE - 1));
  assert.ok(!inBounds(-1, 0, 0));
  assert.ok(!inBounds(WORLD_SIZE, 0, 0));
  assert.ok(!inBounds(0, WORLD_HEIGHT, 0));
  assert.ok(!inBounds(0, 0, WORLD_SIZE));
  assert.ok(!inBounds(1.5, 0, 0));
});

test('terrainHeight stays within the world height', () => {
  for (let x = 0; x < WORLD_SIZE; x += 3) {
    for (let z = 0; z < WORLD_SIZE; z += 3) {
      const h = terrainHeight(x, z, 5);
      assert.ok(h >= 1, 'height must be >= 1');
      assert.ok(h < WORLD_HEIGHT, 'height must be < WORLD_HEIGHT');
    }
  }
});
