import { test } from 'node:test';
import assert from 'node:assert/strict';
import { boxIntersectsWorld, moveAxis, blockOverlapsPlayer, HALF_W, PLAYER_HEIGHT } from '../src/player/collision.js';
import { Player, clampDt, GRAVITY, JUMP_SPEED, MAX_DT } from '../src/player/player.js';
import { World } from '../src/world/world.js';
import { STONE, AIR } from '../src/world/blocks.js';

// A minimal world with a flat floor at y=0 (top of block at y=0).
function flatWorld() {
  const w = new World(1);
  w.blocks.clear();
  // 48x48 floor at y=0 (solid), air above.
  for (let x = 0; x < w.size; x++)
    for (let z = 0; z < w.size; z++)
      w.blocks.set(`${x},0,${z}`, STONE);
  return w;
}

test('boxIntersectsWorld detects overlap with a solid floor', () => {
  const w = flatWorld();
  // Feet at y=0.05 -> box spans [0.05, 1.75], overlapping block row y=0.
  assert.ok(boxIntersectsWorld(w, 10, 0.05, 10));
  // Feet at y=1.0 -> box spans [1.0, 2.7], no overlap with row y=0.
  assert.ok(!boxIntersectsWorld(w, 10, 1.0, 10));
});

test('moveAxis stops at a wall', () => {
  const w = flatWorld();
  // Wall at x=20 (a vertical column of solid blocks).
  for (let y = 0; y < 5; y++) w.blocks.set(`20,${y},10`, STONE);
  // Start at x=10, move +5 in x -> should stop just before 20.
  const nx = moveAxis(w, 'x', 10, 5, 1.0, 10, 10);
  assert.ok(nx < 20, 'should not pass the wall');
  assert.ok(nx > 10, 'should have moved forward');
  // Moving in -x should go all the way.
  const nx2 = moveAxis(w, 'x', 10, -5, 1.0, 10, 10);
  assert.equal(nx2, 5);
});

test('blockOverlapsPlayer matches AABB overlap', () => {
  // Player centered at (10, 0.0, 10), width 0.6, height 1.7.
  // Block at (9, 0, 9) -> overlaps (x: [9,10] vs [9.7,10.3]; y: [0,1] vs [0,1.7]; z: [9,10] vs [9.7,10.3]).
  assert.ok(blockOverlapsPlayer(9, 0, 9, 10, 0, 10));
  // Block at (11, 0, 10) -> x: [11,12] vs [9.7,10.3] -> no overlap.
  assert.ok(!blockOverlapsPlayer(11, 0, 10, 10, 0, 10));
  // Block at (10, 2, 10) -> y: [2,3] vs [0,1.7] -> no overlap.
  assert.ok(!blockOverlapsPlayer(10, 2, 10, 10, 0, 10));
  // Block at (10, -1, 10) -> y: [-1,0] vs [0,1.7] -> no overlap (touching at y=0 only).
  assert.ok(!blockOverlapsPlayer(10, -1, 10, 10, 0, 10));
});

test('player falls under gravity and lands on the floor', () => {
  const w = flatWorld();
  const p = new Player(w, 10, 10, 10);
  p.position = { x: 10, y: 10, z: 10 };
  // Step until grounded or a guard is hit.
  let guard = 0;
  while (!p.grounded && guard++ < 100) {
    p.step({ forward: false, back: false, left: false, right: false, jump: false, sprint: false }, 1 / 60);
  }
  assert.ok(p.grounded, 'player should land on the floor');
  assert.ok(p.position.y > 0.9 && p.position.y < 1.1, `player feet should be near y=1 (got ${p.position.y})`);
});

test('player jumps and returns to the ground', () => {
  const w = flatWorld();
  const p = new Player(w, 10, 1, 10);
  p.position = { x: 10, y: 1, z: 10 };
  p.grounded = true;
  // Jump.
  p.step({ forward: false, back: false, left: false, right: false, jump: true, sprint: false }, 1 / 60);
  assert.ok(p.position.y > 1, 'player should rise after jump');
  // Let gravity pull back down.
  let guard = 0;
  while (guard++ < 200 && !p.grounded) {
    p.step({ forward: false, back: false, left: false, right: false, jump: false, sprint: false }, 1 / 60);
  }
  assert.ok(p.grounded, 'player should land back on the floor');
  assert.ok(Math.abs(p.position.y - 1) < 0.1, `player should return near y=1 (got ${p.position.y})`);
});

test('player cannot jump while in the air', () => {
  const w = flatWorld();
  const p = new Player(w, 10, 5, 10);
  p.position = { x: 10, y: 5, z: 10 };
  p.grounded = false;
  p.velocity.y = 0;
  p.step({ forward: false, back: false, left: false, right: false, jump: true, sprint: false }, 1 / 60);
  // Velocity should be negative (gravity) because jump was ignored.
  assert.ok(p.velocity.y < 0, 'jump should be ignored when not grounded');
});

test('clampDt bounds large frame deltas', () => {
  assert.equal(clampDt(0.016), 0.016);
  assert.equal(clampDt(10), MAX_DT);
  assert.equal(clampDt(-1), 0);
  assert.equal(clampDt(NaN), 0);
  assert.equal(clampDt(Infinity), 0);
});

test('a huge dt does not bury the player', () => {
  const w = flatWorld();
  const p = new Player(w, 10, 5, 10);
  p.position = { x: 10, y: 5, z: 10 };
  p.velocity = { x: 0, y: 0, z: 0 };
  // Simulate resuming from a backgrounded tab: a single 5-second delta is
  // clamped so the player must not launch or bury, then continues stepping.
  p.step({ forward: false, back: false, left: false, right: false, jump: false, sprint: false }, 5);
  assert.ok(p.position.y < 5, 'player should have fallen, not flown');
  assert.ok(p.position.y > 0, 'player must not be buried in the first clamped step');
  // Continue stepping until grounded (or 600 frames).
  let guard = 0;
  while (guard++ < 600 && !p.grounded) {
    p.step({ forward: false, back: false, left: false, right: false, jump: false, sprint: false }, 1 / 60);
  }
  assert.ok(p.grounded, 'player should eventually land on the floor');
  assert.ok(Math.abs(p.position.y - 1) < 0.1, `player should land at floor, got y=${p.position.y}`);
});

test('player walks and is stopped by a wall (solid collision on X axis)', () => {
  const w = flatWorld();
  // A wall spanning the full height at x=20, z=10.
  for (let y = 0; y < 10; y++) w.blocks.set(`20,${y},10`, STONE);
  const p = new Player(w, 10, 1, 10);
  p.position = { x: 10, y: 1, z: 10 };
  p.grounded = true;
  p.facing = { yaw: 0, pitch: 0 }; // yaw=0 -> forward is -Z
  // Forward (facing -Z) walks toward z=0, not the wall.
  // To walk +x, face yaw = -PI/2 (so forward = +X).
  p.facing.yaw = -Math.PI / 2;
  let guard = 0;
  while (guard++ < 60) {
    p.step({ forward: true, back: false, left: false, right: false, jump: false, sprint: false }, 1 / 60);
  }
  assert.ok(p.position.x < 20, `player should not pass the wall (x=${p.position.x})`);
  assert.ok(p.position.x > 10, 'player should have moved toward the wall');
});

test('player walks and is stopped by a wall (solid collision on Z axis)', () => {
  const w = flatWorld();
  // A wall spanning the full height at z=20, x=10.
  for (let y = 0; y < 10; y++) w.blocks.set(`10,${y},20`, STONE);
  const p = new Player(w, 10, 1, 10);
  p.position = { x: 10, y: 1, z: 10 };
  p.grounded = true;
  p.facing = { yaw: Math.PI, pitch: 0 }; // yaw=PI -> forward is +Z
  let guard = 0;
  while (guard++ < 60) {
    p.step({ forward: true, back: false, left: false, right: false, jump: false, sprint: false }, 1 / 60);
  }
  assert.ok(p.position.z < 20, `player should not pass the wall (z=${p.position.z})`);
  assert.ok(p.position.z > 10, 'player should have moved toward the wall');
});
