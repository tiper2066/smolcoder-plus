import { test } from 'node:test';
import assert from 'node:assert/strict';
// Minimal DOM shims so game.js can be imported under Node.
globalThis.window = {
  addEventListener: () => {},
  removeEventListener: () => {},
  devicePixelRatio: 1,
  innerWidth: 800,
  innerHeight: 600,
  confirm: () => true,
  performance: { now: () => 0 },
  requestPointerLock: () => {},
  exitPointerLock: () => {}
};
globalThis.document = {
  addEventListener: () => {},
  removeEventListener: () => {},
  pointerLockElement: null,
  getElementById: () => null,
  createElement: () => ({
    style: {}, appendChild: () => {}, append: () => {}, addEventListener: () => {},
    querySelectorAll: () => [], querySelector: () => null,
    dataset: {}, classList: { add: () => {}, remove: () => {}, toggle: () => {} },
    textContent: '', innerHTML: '', className: ''
  }),
  body: { appendChild: () => {} }
};
globalThis.localStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
  clear: () => {}
};
globalThis.requestAnimationFrame = () => 0;
globalThis.cancelAnimationFrame = () => {};

// A canvas with a no-op WebGL context so Three.js's WebGLRenderer can be
// constructed under Node without a real GPU.
function fakeCanvas() {
  const noop = () => {};
  const ctx = {
    canvas: { style: {} },
    // Three.js reads many gl constants as properties (gl.VERSION, etc.).
    // Provide them all, plus a getParameter fallback.
    VERSION: 'WebGL 2.0 (fake)',
    getContextAttributes: () => ({ alpha: true, depth: true, stencil: true, antialias: false, premultipliedAlpha: true, preserveDrawingBuffer: false }),
    MAX_COMBINED_TEXTURE_IMAGE_UNITS: 32,
    MAX_VERTEX_ATTRIBS: 16,
    MAX_TEXTURE_IMAGE_UNITS: 16,
    MAX_VERTEX_TEXTURE_IMAGE_UNITS: 16,
    MAX_TEXTURE_SIZE: 4096,
    MAX_CUBE_MAP_TEXTURE_SIZE: 4096,
    MAX_VERTEX_UNIFORM_VECTORS: 400,
    MAX_VARYING_VECTORS: 30,
    MAX_FRAGMENT_UNIFORM_VECTORS: 220,
    MAX_SAMPLES: 4,
    SCISSOR_BOX: [0, 0, 800, 600],
    VIEWPORT: [0, 0, 800, 600],
    TEXTURE_2D: 3553,
    TEXTURE_3D: 32879,
    TEXTURE_2D_ARRAY: 35866,
    TEXTURE_MIN_FILTER: 10241,
    TEXTURE_MAG_FILTER: 10240,
    RGBA: 6408,
    UNSIGNED_BYTE: 5121,
    VERTEX_SHADER: 35633,
    FRAGMENT_SHADER: 35632,
    HIGH_FLOAT: 36327,
    MEDIUM_FLOAT: 36326,
    COMPILE_STATUS: 33333,
    LINK_STATUS: 35714,
    VALIDATE_STATUS: 35715,
    ACTIVE_UNIFORMS: 35718,
    ACTIVE_ATTRIBUTES: 35721,
    COMPLETION_STATUS_KHR: 35716,
    getParameter: (p) => {
      const self = ctx;
      for (const k of Object.keys(self)) {
        if (self[k] === p) return self[k]; // numeric constant matches its own value
      }
      if (p === 0x1F02) return 32; // MAX_COMBINED_TEXTURE_IMAGE_UNITS
      if (p === 0x0D05) return 'WebGL 2.0 (fake)'; // VERSION
      if (p === 0x0C11) return [0, 0, 800, 600]; // SCISSOR_BOX
      if (p === 0x0CA2) return [0, 0, 800, 600]; // VIEWPORT
      if (p === 0x0D32) return 16; // MAX_VERTEX_ATTRIBS
      if (p === 0x0864) return 4096; // MAX_TEXTURE_SIZE
      if (p === 0x0865) return 4096; // MAX_CUBE_MAP_TEXTURE_SIZE
      if (p === 0x0884) return 16; // MAX_TEXTURE_IMAGE_UNITS
      if (p === 0x8B4C) return 16; // MAX_VERTEX_TEXTURE_IMAGE_UNITS
      if (p === 0x0DF8) return 400; // MAX_VERTEX_UNIFORM_VECTORS
      if (p === 0x8B49) return 30; // MAX_VARYING_VECTORS
      if (p === 0x8DF8) return 220; // MAX_FRAGMENT_UNIFORM_VECTORS
      if (p === 0x8D56) return 4; // MAX_SAMPLES
      return 0;
    },
    getShaderPrecisionFormat: () => ({ precision: 23, range: 127 }),
    getExtension: () => null,
    getShaderInfoLog: () => '',
    getProgramInfoLog: () => '',
    getShaderParameter: () => true,
    getProgramParameter: () => true,
    getUniformLocation: () => null,
    getAttribLocation: () => 0,
    createShader: () => ({}),
    createProgram: () => ({}),
    createBuffer: () => ({}),
    createTexture: () => ({}),
    createFramebuffer: () => ({}),
    createRenderbuffer: () => ({}),
    createQuery: () => ({}),
    shaderSource: noop,
    attachShader: noop,
    linkProgram: noop,
    useProgram: noop,
    deleteShader: noop,
    deleteProgram: noop,
    bindBuffer: noop,
    bufferData: noop,
    bindTexture: noop,
    texParameteri: noop,
    texImage2D: noop,
    texImage3D: noop,
    bindFramebuffer: noop,
    bindRenderbuffer: noop,
    renderbufferStorage: noop,
    framebufferTexture2D: noop,
    framebufferRenderbuffer: noop,
    checkFramebufferStatus: () => 36053,
    viewport: noop,
    scissor: noop,
    clear: noop,
    clearColor: noop,
    clearDepth: noop,
    clearStencil: noop,
    enable: noop,
    disable: noop,
    blendFunc: noop,
    depthFunc: noop,
    depthMask: noop,
    cullFace: noop,
    frontFace: noop,
    enableVertexAttribArray: noop,
    disableVertexAttribArray: noop,
    vertexAttribPointer: noop,
    uniform1i: noop,
    uniform1f: noop,
    uniform2f: noop,
    uniform3f: noop,
    uniform4f: noop,
    uniformMatrix4fv: noop,
    uniformMatrix3fv: noop,
    drawArrays: noop,
    drawElements: noop,
    drawElementsInstanced: noop,
    drawArraysInstanced: noop,
    pixelStorei: noop,
    getError: () => 0,
    finish: noop,
    flush: noop,
    isContextLost: () => false,
    getSupportedExtensions: () => []
  };
  return {
    clientWidth: 800,
    clientHeight: 600,
    style: {},
    getContext: () => ctx,
    addEventListener: () => {},
    removeEventListener: () => {},
    getBoundingClientRect: () => ({ left: 0, top: 0, right: 800, bottom: 600, width: 800, height: 600, x: 0, y: 0 })
  };
}

test('Game.snapshot returns the exact debug fields', async () => {
  const { Game } = await import('../src/game/game.js');
  const canvas = fakeCanvas();
  const ui = { append: () => {}, appendChild: () => {}, addEventListener: () => {}, querySelector: () => null, querySelectorAll: () => [], textContent: '' };
  const game = new Game(canvas, ui);
  const snap = game.snapshot();
  assert.ok('player' in snap, 'snapshot has player');
  assert.ok('selected' in snap, 'snapshot has selected');
  assert.ok('targeted' in snap, 'snapshot has targeted');
  assert.ok('editCount' in snap, 'snapshot has editCount');
  assert.ok('x' in snap.player && 'y' in snap.player && 'z' in snap.player);
  assert.equal(typeof snap.editCount, 'number');
  assert.ok(snap.targeted === null || ('x' in snap.targeted && 'y' in snap.targeted && 'z' in snap.targeted));
});

test('Game.getBlock returns 0 for air and string name for blocks', async () => {
  const { Game } = await import('../src/game/game.js');
  const canvas = fakeCanvas();
  const ui = { append: () => {}, appendChild: () => {}, addEventListener: () => {}, querySelector: () => null, querySelectorAll: () => [], textContent: '' };
  const game = new Game(canvas, ui);
  // Air returns 0 (number) — use out-of-bounds position
  const air = game.getBlock(-1, 0, 0);
  assert.equal(air, 0);
  // Find an air position inside the world (y < 24) and place a block there
  let spot = null;
  outer: for (let y = 23; y >= 0; y--) {
    if (game.world.getBlock(20, y, 20) === 0) { spot = [20, y, 20]; break; }
  }
  assert.ok(spot, 'found an air position');
  game.world.placeBlock(spot[0], spot[1], spot[2], 5); // leaves
  const t = game.getBlock(spot[0], spot[1], spot[2]);
  assert.equal(t, 'leaves');
});

test('Game.teleport moves the player and clears velocity', async () => {
  const { Game } = await import('../src/game/game.js');
  const canvas = fakeCanvas();
  const ui = { append: () => {}, appendChild: () => {}, addEventListener: () => {}, querySelector: () => null, querySelectorAll: () => [], textContent: '' };
  const game = new Game(canvas, ui);
  game.teleport(5, 10, 5);
  assert.equal(game.player.position.x, 5);
  assert.equal(game.player.position.y, 10);
  assert.equal(game.player.position.z, 5);
  assert.equal(game.player.velocity.x, 0);
  assert.equal(game.player.velocity.y, 0);
  assert.equal(game.player.velocity.z, 0);
});

test('Game.teleport rejects non-finite coordinates', async () => {
  const { Game } = await import('../src/game/game.js');
  const canvas = fakeCanvas();
  const ui = { append: () => {}, appendChild: () => {}, addEventListener: () => {}, querySelector: () => null, querySelectorAll: () => [], textContent: '' };
  const game = new Game(canvas, ui);
  const before = { ...game.player.position };
  game.teleport(NaN, 10, NaN);
  assert.equal(game.player.position.x, before.x);
  assert.equal(game.player.position.z, before.z);
});
