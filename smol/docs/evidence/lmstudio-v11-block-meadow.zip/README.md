# Block Meadow

A tiny, original, Minecraft-inspired voxel sandbox built with **Three.js**, **Vite**, and plain JavaScript modules. No external artwork — all geometry and colors are generated in code.

![Block Meadow](./README.md)

## Features

- **Seeded, deterministic terrain** — 48×48×24 world with rolling hills, grass/dirt/stone layers, trees, and a small lake.
- **First-person controls** — pointer-lock mouse look, WASD movement, gravity, grounded jumping, and solid AABB collision on all three axes.
- **Block editing** — left-click removes the targeted block (within reach), right-click places one on the adjacent face. Placements never overlap the player or leave the world.
- **Hotbar** — number keys `1`–`5` select grass, dirt, stone, wood, leaves. The selected slot is highlighted and exposed via `aria-pressed`.
- **Start / Pause screen** — controls, palette, Save and New World (with confirmation). `Esc` unlocks the pointer and pauses; resuming works repeatedly.
- **Persistence** — terrain edits, selected block, and player position are saved to `localStorage`. Invalid saved data never crashes startup.
- **HUD** — crosshair (`aria-label="Crosshair"`), live FPS (`aria-label="FPS"`), and a five-slot hotbar (`aria-label="Hotbar"`) remain visible during play, after reload, and after New World.
- **Target outline + crosshair** — the block under the reticle gets a visible outline.
- **Frame-delta clamp** — resuming a background tab does not launch or bury the player.
- **Debug API** — `window.voxelDebug` exposes the live game state (see below).

## Getting started

```bash
npm install
npm run dev
```

Then open the printed URL (default `http://localhost:5173`). Click **Play** to lock the pointer and start.

### Production build

```bash
npm run build     # outputs to dist/
npm run preview   # serve the build locally
```

### Tests

```bash
npm test          # Node's built-in test runner (node --test)
```

Tests cover:
- deterministic terrain (same seed → same world; different seeds → different worlds)
- block bounds (out-of-range reads return `AIR`; writes are rejected)
- edit persistence (save/load round-trip, editCount, invalid-data safety)
- collision & jump rules (gravity, landing, no wall-pass, no double jump, clamped-dt safety)

## Controls

| Key / Input        | Action                          |
|--------------------|---------------------------------|
| `W` `A` `S` `D`    | Move                            |
| Mouse              | Look around (pointer lock)      |
| `Space`            | Jump (only while grounded)      |
| Left click         | Break the targeted block        |
| Right click        | Place a block on the adjacent face |
| `1` – `5`          | Select grass / dirt / stone / wood / leaves |
| `Esc`              | Pause / resume (releases pointer) |

## Debug API

`window.voxelDebug` is exposed on the live game for browser verification:

```js
voxelDebug.snapshot()        // { player: {x,y,z}, selected: blockType, targeted: {x,y,z}|null, editCount }
voxelDebug.getBlock(x,y,z)   // actual block type at (x,y,z); 0 for air / out of bounds
voxelDebug.teleport(x,y,z)   // move the player to (x,y,z)
```

All three inspect the **actual live game state** (the same `World` and `Player` instances the renderer uses).

## Project layout

```
index.html              # entry page (HUD, menu, palette)
src/
  main.js               # bootstrap
  game.js               # game loop, input, editing, UI wiring, voxelDebug
  ui.css                # HUD + menu styles
  core/
    blocks.js           # block constants, colors, names
    world.js            # block storage, bounds, serialize/deserialize
    terrain.js          # seeded PRNG, noise, heightmap, trees, lake
    collision.js        # AABB collision, Player (gravity/jump/step), clampDt
    raycast.js          # voxel DDA raycaster (target + face normal)
    save.js             # localStorage persistence (defensive)
  render/
    worldMesh.js        # exposed-face mesh builder (one BufferGeometry)
test/
  terrain.test.js       # determinism, size, layers, trees, lake, bounds
  collision.test.js     # gravity, landing, wall collision, jump rules, clampDt
  save.test.js          # round-trip, edit persistence, invalid-data safety
```

## Known limitations

- **No browser automation available in this environment** — `npm run build` and `npm test` both pass, but I could not run a headless-Chromium check of the rendered UI. The `voxelDebug` API is implemented and unit-testable in Node (the same code path the browser uses), but a live pointer-lock / WebGL render has not been exercised here.
- **Water is visual only** — the lake is a carved depression with grass/dirt/stone; there is no flowing-water physics or buoyancy.
- **No block physics** — placed/broken blocks are static; no sand, gravity-blocks, or item drops.
- **Single world per browser profile** — `localStorage` is keyed by origin; switching browsers or clearing site data loses the saved world.
- **No multiplayer, sound, or textures** — by design, to keep the footprint small.

## License

Original work, MIT.
