import { test } from 'node:test';
import assert from 'node:assert/strict';

// Minimal localStorage shim so save.js works under Node.
function makeLocalStorage() {
  const store = new Map();
  return {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
    clear: () => store.clear(),
    _dump: () => Object.fromEntries(store),
  };
}
globalThis.localStorage = makeLocalStorage();

// Import after the shim is in place (save.js reads localStorage at call time,
// not import time, so order is safe either way).
const { loadSave, saveGame, clearSave, makeInitialState } = await import('../src/core/save.js');
const { generateWorld } = await import('../src/core/terrain.js');
const { World } = await import('../src/core/world.js');
const { STONE, GRASS, HOTBAR } = await import('../src/core/blocks.js');

test('save then load round-trips world, selected block and player', () => {
  clearSave();
  const state = makeInitialState(123);
  state.world.setBlock(2, 3, 4, STONE);
  state.selected = HOTBAR[2];
  state.player = { x: 10.5, y: 12, z: 8.5 };

  assert.equal(saveGame(state), true);

  const loaded = loadSave();
  assert.ok(loaded, 'expected a saved world to load');
  assert.equal(loaded.world.getBlock(2, 3, 4), STONE);
  assert.deepEqual(Array.from(loaded.world.data), Array.from(state.world.data));
  assert.equal(loaded.selected, HOTBAR[2]);
  assert.deepEqual(loaded.player, { x: 10.5, y: 12, z: 8.5 });
});

test('terrain edits persist across save/load (editCount and block)', () => {
  clearSave();
  const state = makeInitialState(55);
  state.world.setBlock(3, 2, 3, GRASS);
  state.world.setBlock(3, 1, 3, STONE);
  saveGame(state);

  const loaded = loadSave();
  assert.equal(loaded.world.getBlock(3, 2, 3), GRASS);
  assert.equal(loaded.world.getBlock(3, 1, 3), STONE);
  assert.equal(loaded.world.editCount, state.world.editCount);
});

test('loadSave returns null on garbage data instead of crashing', () => {
  localStorage.setItem('block-meadow.save.v1', '{not json');
  assert.equal(loadSave(), null);

  localStorage.setItem('block-meadow.save.v1', JSON.stringify({ world: { sizeX: 'nope' } }));
  assert.equal(loadSave(), null);

  localStorage.setItem('block-meadow.save.v1', JSON.stringify({ world: { sizeX: 4, sizeY: 4, sizeZ: 4, data: 'bad-base64!!!' } }));
  assert.equal(loadSave(), null);

  localStorage.setItem('block-meadow.save.v1', JSON.stringify({ world: { sizeX: 4, sizeY: 4, sizeZ: 4, data: 'QUFB' } }));
  assert.equal(loadSave(), null);
});

test('loadSave falls back safely when player position is out of range', () => {
  clearSave();
  const state = makeInitialState(55);
  state.player = { x: 9999, y: -5, z: 9999 }; // invalid
  saveGame(state);
  const loaded = loadSave();
  assert.ok(loaded);
  assert.equal(loaded.player, null, 'invalid saved position should be dropped');
});

test('invalid saved block types are rejected by deserializer', () => {
  const w = new World(3, 3, 3);
  w.setBlock(0, 0, 0, STONE);
  const raw = w.serialize();
  // Corrupt one byte to an out-of-range value (7 > 5).
  const bytes = atobBytesLocal(raw.data);
  bytes[0] = 7;
  const corrupted = { sizeX: 3, sizeY: 3, sizeZ: 3, data: btoaBytesLocal(bytes) };
  assert.equal(World.deserialize(corrupted), null);
});

function btoaBytesLocal(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return globalThis.btoa ? globalThis.btoa(bin) : Buffer.from(bin, 'binary').toString('base64');
}
function atobBytesLocal(b64) {
  const bin = globalThis.atob ? globalThis.atob(b64) : Buffer.from(b64, 'base64').toString('binary');
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}
