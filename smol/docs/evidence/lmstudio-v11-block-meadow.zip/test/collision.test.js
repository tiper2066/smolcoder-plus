import { test } from 'node:test';
import assert from 'node:assert/strict';

import { World } from '../src/core/world.js';
import { Player, clampDt, boxCollides, JUMP_VELOCITY, GRAVITY } from '../src/core/collision.js';
import { STONE, DIRT, GRASS, AIR } from '../src/core/blocks.js';

function flatWorld(size = 8, height = 4) {
  const w = new World(size, size + 8, size);
  for (let x = 0; x < size; x++) {
    for (let z = 0; z < size; z++) {
      for (let y = 0; y < height; y++) w.setBlock(x, y, z, y === height - 1 ? GRASS : STONE);
    }
  }
  return w;
}

test('clampDt bounds large frame deltas', () => {
  assert.equal(clampDt(0), 0);
  assert.ok(clampDt(0.016) < 0.02);
  // A 5-second tab-resume delta must be clamped to <= 50ms.
  assert.ok(clampDt(5) <= 0.05 + 1e-9);
  assert.equal(clampDt(-1), 0);
  assert.equal(clampDt(Infinity), 0);
});

test('player falls under gravity and lands on the ground', () => {
  const w = flatWorld();
  const p = new Player(w);
  p.spawn(3.5, 3.5, 20);
  // Should be resting on the surface (top block y=3, so feet at y=4).
  assert.equal(p.pos.y, 4);
  assert.equal(p.onGround, true);

  // Step with no input: gravity pulls, ground holds.
  p.step(1 / 60, {});
  assert.equal(p.pos.y, 4);
  assert.equal(p.onGround, true);
  assert.equal(p.vel.y, 0);
});

test('player cannot pass through solid blocks (horizontal collision)', () => {
  const w = flatWorld();
  // Wall at x=5
  for (let y = 4; y <= 8; y++) w.setBlock(5, y, 3, STONE);
  const p = new Player(w);
  p.spawn(2.5, 3.5, 4);
  // Move right (toward the wall) many steps.
  for (let i = 0; i < 240; i++) p.step(1 / 60, { right: 1 });
  // Player's right edge is pos.x + 0.3; wall left face is x=5. Must stay < 5.
  assert.ok(p.pos.x + 0.3 < 5 + 1e-3, `expected to stop before wall, at x=${p.pos.x}`);
});

test('player jumps only when grounded and rises then falls', () => {
  const w = flatWorld();
  const p = new Player(w);
  p.spawn(3.5, 3.5, 20);
  p.step(1 / 60, {});
  assert.equal(p.onGround, true);
  const start = p.pos.y;

  p.step(1 / 60, { jump: true });
  assert.ok(p.pos.y > start, 'jump should raise the player');
  assert.equal(p.onGround, false);

  // Let it arc back down.
  for (let i = 0; i < 120; i++) p.step(1 / 60, {});
  assert.equal(p.pos.y, start, 'player should land back on the ground');
  assert.equal(p.onGround, true);
});

test('jumping while airborne does not add velocity (no double jump)', () => {
  const w = flatWorld();
  const p = new Player(w);
  p.spawn(3.5, 3.5, 20);
  p.step(1 / 60, {});
  p.step(1 / 60, { jump: true }); // first jump, now airborne
  const vyAfterFirst = p.vel.y;
  p.step(1 / 60, {}); // one frame of flight
  const vyMid = p.vel.y;
  p.step(1 / 60, { jump: true }); // attempted second jump in the air
  // vel.y must not have been reset to JUMP_VELOCITY (air jump did nothing),
  // and gravity must keep acting (vel.y keeps decreasing).
  assert.ok(
    Math.abs(p.vel.y - JUMP_VELOCITY) > 0.1,
    `air jump should not re-trigger jump velocity (got ${p.vel.y}, JUMP=${JUMP_VELOCITY})`
  );
  assert.ok(p.vel.y < vyMid, 'gravity should keep acting while airborne');
});

test('boxCollides detects solid overlap and free space', () => {
  const w = new World(8, 8, 8);
  w.setBlock(4, 4, 4, STONE);
  assert.equal(boxCollides(w, 4.5, 4, 4.5), true);   // box around the stone
  assert.equal(boxCollides(w, 6.5, 4, 4.5), false);  // clear of it
});

test('a large clamped dt does not bury the player through the floor', () => {
  const w = flatWorld();
  const p = new Player(w);
  p.spawn(3.5, 3.5, 20);
  p.step(1 / 60, {});
  const resting = p.pos.y;
  // Simulate a tab-resume: a huge dt, clamped by clampDt.
  p.step(clampDt(5.0), {});
  assert.equal(p.pos.y, resting, 'player must stay on the floor after a big clamped frame');
  assert.ok(p.pos.y >= 0, 'player must not be buried below the world');
});
