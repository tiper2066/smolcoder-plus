// Render the world as a single BufferGeometry of exposed faces (culling
// hidden faces). Rebuilds when the world changes. Uses vertex colors and a
// single MeshLambertMaterial with lighting for a soft, original look.

import * as THREE from 'three';
import { BLOCK_COLORS } from '../core/blocks.js';

const FACES = [
  // dir, corner order (CCW when viewed from outside), shade
  { dir: [0, 1, 0],  corners: [[0,1,1],[1,1,1],[1,1,0],[0,1,0]], key: 'top',    shade: 1.0 },
  { dir: [0,-1, 0],  corners: [[0,0,0],[1,0,0],[1,0,1],[0,0,1]], key: 'bottom', shade: 0.55 },
  { dir: [ 1,0, 0],  corners: [[1,0,1],[1,0,0],[1,1,0],[1,1,1]], key: 'side',   shade: 0.85 },
  { dir: [-1,0, 0],  corners: [[0,0,0],[0,0,1],[0,1,1],[0,1,0]], key: 'side',   shade: 0.85 },
  { dir: [ 0,0, 1],  corners: [[0,0,1],[1,0,1],[1,1,1],[0,1,1]], key: 'side',   shade: 0.95 },
  { dir: [ 0,0,-1],  corners: [[1,0,0],[0,0,0],[0,1,0],[1,1,0]], key: 'side',   shade: 0.75 },
];

export function buildWorldGeometry(world) {
  const positions = [];
  const normals = [];
  const colors = [];
  const uvs = [];
  const indices = [];
  let quadCount = 0;

  const colorCache = {};
  function faceColor(type, key, shade) {
    const id = type + '_' + key;
    if (colorCache[id]) return colorCache[id];
    const c = BLOCK_COLORS[type] || BLOCK_COLORS[1];
    const base = c[key] || c.top;
    const r = ((base >> 16) & 255) / 255 * shade;
    const g = ((base >> 8) & 255) / 255 * shade;
    const b = (base & 255) / 255 * shade;
    colorCache[id] = { r, g, b };
    return colorCache[id];
  }

  for (let x = 0; x < world.sizeX; x++) {
    for (let y = 0; y < world.sizeY; y++) {
      for (let z = 0; z < world.sizeZ; z++) {
        const type = world.getBlock(x, y, z);
        if (type === 0) continue;
        for (const face of FACES) {
          const nx = x + face.dir[0];
          const ny = y + face.dir[1];
          const nz = z + face.dir[2];
          const neighbor = world.getBlock(nx, ny, nz);
          // Exposed if neighbor is air or out of bounds (we treat out-of-bounds
          // as exposed so the world edges are visible).
          if (world.inBounds(nx, ny, nz) && neighbor !== 0) continue;
          const col = faceColor(type, face.key, face.shade);
          const base = quadCount * 4;
          for (const c of face.corners) {
            positions.push(x + c[0], y + c[1], z + c[2]);
            normals.push(face.dir[0], face.dir[1], face.dir[2]);
            colors.push(col.r, col.g, col.b);
            uvs.push(c[0], c[1]);
          }
          indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
          quadCount++;
        }
      }
    }
  }

  const geom = new THREE.BufferGeometry();
  geom.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geom.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geom.setIndex(indices);
  geom.computeBoundingSphere();
  geom.userData.quadCount = quadCount;
  return geom;
}

// A small wireframe box used to outline the targeted block.
export function makeTargetOutline() {
  const geom = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.004, 1.004, 1.004));
  const mat = new THREE.LineBasicMaterial({ color: 0x1a1a1a, transparent: true, opacity: 0.85 });
  const line = new THREE.LineSegments(geom, mat);
  line.visible = false;
  return line;
}
