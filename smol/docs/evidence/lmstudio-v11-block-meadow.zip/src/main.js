import { startGame } from './game.js';

// Start immediately; the menu overlays until Play / pointer lock.
startGame();
