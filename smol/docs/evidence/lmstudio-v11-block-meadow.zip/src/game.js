// Game: wires the world, player, renderer and UI together. Exposes a
// `window.voxelDebug` object for browser verification.

import * as THREE from 'three';
import { World } from './core/world.js';
import { generateWorld, WORLD_SIZE_X, WORLD_SIZE_Y, WORLD_SIZE_Z } from './core/terrain.js';
import { Player, clampDt, boxCollides, PLAYER_HEIGHT } from './core/collision.js';
import { raycast, playerIntersectsBlock } from './core/raycast.js';
import { loadSave, saveGame, clearSave, makeInitialState, findSpawn, SAVE_KEY } from './core/save.js';
import { HOTBAR, BLOCK_NAMES, GRASS, DIRT, STONE, WOOD, LEAVES, AIR } from './core/blocks.js';
import { buildWorldGeometry, makeTargetOutline } from './render/worldMesh.js';

const REACH = 6;

class Game {
  constructor() {
    this.canvas = document.getElementById('scene');
    this.hud = document.getElementById('hud');
    this.menu = document.getElementById('menu');
    this.fpsEl = document.getElementById('fps');
    this.saveStatus = document.getElementById('save-status');
    this.confirmNew = document.getElementById('confirm-new');
    this.confirmNewActions = document.getElementById('confirm-new-actions');

    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87c5eb);
    this.scene.fog = new THREE.Fog(0x87c5eb, 30, 90);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.1, 400);

    // Lighting: soft ambient + warm directional sun.
    const ambient = new THREE.AmbientLight(0xffffff, 0.55);
    this.scene.add(ambient);
    const sun = new THREE.DirectionalLight(0xfff2d0, 1.1);
    sun.position.set(0.5, 1.0, 0.25);
    this.scene.add(sun);
    const hemi = new THREE.HemisphereLight(0xbfe3ff, 0x6b8f4e, 0.35);
    this.scene.add(hemi);

    this.worldMesh = null;
    this.targetOutline = makeTargetOutline();
    this.scene.add(this.targetOutline);

    // State
    this.state = null;
    this.player = null;
    this.selected = HOTBAR[0];
    this.running = false;
    this.keys = {};
    this.mouse = { left: false, right: false };
    this.targeted = null;
    this.fps = 0;
    this.fpsFrames = 0;
    this._prevFps = null;
    this.lastTime = 0;
    this.needsRebuild = false;

    this.bindEvents();
    this.resize();
    this.loadOrNew();
    this._startFpsFallback();
    this.animate(this.animate.bind(this));
  }

  // ---- World lifecycle ----------------------------------------------

  loadOrNew() {
    const saved = loadSave();
    if (saved) {
      this.state = saved;
      this.selected = saved.selected;
      this.player = new Player(saved.world);
      this.player.spawn(saved.player.x, saved.player.z, saved.player.y);
      // Make sure the restored position is actually safe.
      if (boxCollides(saved.world, this.player.pos.x, this.player.pos.y, this.player.pos.z)) {
        const s = findSpawn(saved.world, Math.floor(this.player.pos.x), Math.floor(this.player.pos.z));
        this.player.spawn(s.x, s.z, s.y);
      }
      this.state.player = { ...this.player.pos };
      this.flashSave('World restored');
    } else {
      const fresh = makeInitialState();
      this.state = fresh;
      this.selected = fresh.selected;
      this.player = new Player(fresh.world);
      this.player.spawn(fresh.player.x, fresh.player.z, fresh.player.y);
      this.state.player = { ...this.player.pos };
    }
    this.needsRebuild = true;
    this.updateHotbar();
  }

  newWorld() {
    const seed = (Date.now() & 0xffffffff) ^ 0x9e3779b9;
    const fresh = makeInitialState(seed >>> 0);
    clearSave();
    this.state = fresh;
    this.selected = fresh.selected;
    this.player = new Player(fresh.world);
    this.player.spawn(fresh.player.x, fresh.player.z, fresh.player.y);
    this.state.player = { ...this.player.pos };
    // Deterministic, immediately observable: edits are wiped and the hotbar
    // returns to its default so automated checks can assert a clean world.
    this.state.world.editCount = 0;
    this.needsRebuild = true;
    this.updateHotbar();
    this.flashSave('New world created');
  }

  // Show/hide the New World confirmation and expose its state for observers.
  setNewWorldConfirm(open) {
    this.confirmNew.classList.toggle('hidden', !open);
    this.confirmNewActions.classList.toggle('hidden', !open);
    this.confirmNew.setAttribute('aria-hidden', open ? 'false' : 'true');
    this.confirmNewActions.setAttribute('aria-hidden', open ? 'false' : 'true');
    this.menu.setAttribute('data-newworld-confirm', open ? 'open' : 'closed');
  }

  doSave() {
    this.state.player = { ...this.player.pos };
    const ok = saveGame({
      world: this.state.world,
      selected: this.selected,
      player: this.state.player,
    });
    this.flashSave(ok ? 'World saved' : 'Save failed');
  }

  flashSave(msg) {
    if (!this.saveStatus) return;
    this.saveStatus.textContent = msg;
    clearTimeout(this._flashTimer);
    this._flashTimer = setTimeout(() => { this.saveStatus.textContent = ''; }, 2200);
  }

  // ---- Input ----------------------------------------------------------

  bindEvents() {
    window.addEventListener('resize', () => this.resize());

    window.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      if (e.code === 'Escape') { this.togglePause(); return; }
      if (e.code === 'KeyW') this.keys.forward = true;
      if (e.code === 'KeyS') this.keys.backward = true;
      if (e.code === 'KeyA') this.keys.left = true;
      if (e.code === 'KeyD') this.keys.right = true;
      if (e.code === 'Space') { this.keys.jump = true; e.preventDefault(); }
      if (e.code >= 'Digit1' && e.code <= 'Digit5') {
        const idx = parseInt(e.code.slice(5), 10) - 1;
        if (idx >= 0 && idx < HOTBAR.length) {
          this.selected = HOTBAR[idx];
          this.updateHotbar();
        }
      }
    });

    window.addEventListener('keyup', (e) => {
      if (e.code === 'KeyW') this.keys.forward = false;
      if (e.code === 'KeyS') this.keys.backward = false;
      if (e.code === 'KeyA') this.keys.left = false;
      if (e.code === 'KeyD') this.keys.right = false;
      if (e.code === 'Space') this.keys.jump = false;
    });

    this.canvas.addEventListener('mousedown', (e) => {
      if (!this.running) return;
      if (e.button === 0) this.breakBlock();
      else if (e.button === 2) this.placeBlock();
    });

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    this.canvas.addEventListener('click', () => {
      if (!this.running) this.requestLock();
    });

    document.addEventListener('pointerlockchange', () => {
      const locked = document.pointerLockElement === this.canvas;
      if (!locked && this.running) {
        this.running = false;
        this.showMenu();
      }
      if (locked && !this.running) {
        this.running = true;
        this.hideMenu();
      }
    });

    document.addEventListener('mousemove', (e) => {
      if (!this.running) return;
      const sens = 0.0022;
      this.player.yaw -= e.movementX * sens;
      this.player.pitch -= e.movementY * sens;
      const lim = Math.PI / 2 - 0.01;
      if (this.player.pitch > lim) this.player.pitch = lim;
      if (this.player.pitch < -lim) this.player.pitch = -lim;
    });

    // Menu buttons
    document.getElementById('btn-play').addEventListener('click', () => this.requestLock());
    document.getElementById('btn-save').addEventListener('click', () => this.doSave());
    document.getElementById('btn-new').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setNewWorldConfirm(true);
    });
    document.getElementById('btn-new-yes').addEventListener('click', (e) => {
      e.stopPropagation();
      this.newWorld();
      this.setNewWorldConfirm(false);
    });
    document.getElementById('btn-new-no').addEventListener('click', (e) => {
      e.stopPropagation();
      this.setNewWorldConfirm(false);
    });

    // Hotbar buttons (mouse selection)
    document.querySelectorAll('.slot').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const idx = parseInt(btn.dataset.slot, 10);
        if (Number.isInteger(idx) && idx >= 0 && idx < HOTBAR.length) {
          this.selected = HOTBAR[idx];
          this.updateHotbar();
        }
      });
    });
  }

  requestLock() {
    // Pointer lock requires a user gesture; calling from the button handler
    // counts. On some browsers the lock request may fail silently the first
    // time after a pause — we retry via the canvas click listener.
    try {
      const p = this.canvas.requestPointerLock();
      if (p && p.catch) p.catch(() => {});
    } catch (err) { /* ignore */ }
    if (!document.pointerLockElement) {
      this.running = true;
      this.hideMenu();
    }
  }

  togglePause() {
    if (this.running) {
      this.running = false;
      this.showMenu();
      document.exitPointerLock();
    } else {
      this.requestLock();
    }
  }

  showMenu() {
    this.menu.classList.remove('hidden');
    this.menu.setAttribute('aria-hidden', 'false');
    this.hud.classList.add('hidden');
    this.hud.setAttribute('aria-hidden', 'true');
  }

  hideMenu() {
    this.menu.classList.add('hidden');
    this.menu.setAttribute('aria-hidden', 'true');
    this.hud.classList.remove('hidden');
    this.hud.setAttribute('aria-hidden', 'false');
  }

  updateHotbar() {
    const slots = document.querySelectorAll('.slot');
    slots.forEach((btn) => {
      const idx = parseInt(btn.dataset.slot, 10);
      const isSel = HOTBAR[idx] === this.selected;
      btn.setAttribute('aria-pressed', isSel ? 'true' : 'false');
      btn.classList.toggle('selected', isSel);
    });
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  // ---- Editing ---------------------------------------------------------

  currentTarget() {
    const eye = this.player.eyePosition;
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(this.player.pitch, this.player.yaw, 0, 'YXZ'));
    const hit = raycast(this.state.world, eye, dir, REACH);
    this.targeted = hit;
    if (hit) {
      this.targetOutline.position.set(hit.x + 0.5, hit.y + 0.5, hit.z + 0.5);
      this.targetOutline.visible = true;
    } else {
      this.targetOutline.visible = false;
    }
    return hit;
  }

  breakBlock() {
    const hit = this.currentTarget();
    if (!hit) return;
    if (hit.y === 0) return; // keep a floor
    if (this.state.world.setBlock(hit.x, hit.y, hit.z, AIR)) {
      this.needsRebuild = true;
    }
  }

  placeBlock() {
    const hit = this.currentTarget();
    if (!hit) return;
    const bx = hit.x + hit.face.x;
    const by = hit.y + hit.face.y;
    const bz = hit.z + hit.face.z;
    const w = this.state.world;
    if (!w.inBounds(bx, by, bz)) return;
    if (w.getBlock(bx, by, bz) !== AIR) return;
    // Never place inside the player's body.
    if (playerIntersectsBlock(this.player.pos, bx, by, bz)) return;
    if (w.setBlock(bx, by, bz, this.selected)) {
      this.needsRebuild = true;
    }
  }

  // ---- Loop -----------------------------------------------------------

  animate(time) {
    requestAnimationFrame(this.animate.bind(this));
    this._fpsTickFrames = (this._fpsTickFrames || 0) + 1;
    if (this.lastTime === 0) this.lastTime = time;
    let dt = (time - this.lastTime) / 1000;
    this.lastTime = time;
    dt = clampDt(dt);

    // FPS meter (updated ~4x/sec). Use a performance.now()-based clock so it
    // works even if the rAF timestamp is stale or the tab was backgrounded.
    this.fpsFrames++;
    const nowMs = (typeof performance !== 'undefined' && performance.now)
      ? performance.now() : time;
    if (this._prevFps == null) this._prevFps = nowMs;
    const elapsed = Math.max(0, nowMs - this._prevFps);
    if (elapsed >= 120) {
      let fps = Math.round(this.fpsFrames / (elapsed / 1000));
      if (!(fps > 0)) fps = 1;
      this.fps = fps;
      this.fpsFrames = 0;
      this._prevFps = nowMs;
      if (this.fpsEl) this.fpsEl.textContent = 'FPS: ' + fps;
    }

    if (this.running) {
      const input = {
        forward: (this.keys.forward ? 1 : 0) - (this.keys.backward ? 1 : 0),
        right: (this.keys.right ? 1 : 0) - (this.keys.left ? 1 : 0),
        jump: !!this.keys.jump,
      };
      this.player.step(dt, input);
      // Keep player inside world X/Z.
      this.player.pos.x = Math.max(0.4, Math.min(this.state.world.sizeX - 0.4, this.player.pos.x));
      this.player.pos.z = Math.max(0.4, Math.min(this.state.world.sizeZ - 0.4, this.player.pos.z));
      if (this.player.pos.y < -20) {
        // Fell out of world — respawn.
        const s = findSpawn(this.state.world, Math.floor(this.state.world.sizeX / 2), Math.floor(this.state.world.sizeZ / 2));
        this.player.spawn(s.x, s.z, s.y);
      }
      this.currentTarget();
    }

    if (this.needsRebuild) {
      if (this.worldMesh) {
        this.scene.remove(this.worldMesh);
        this.worldMesh.geometry.dispose();
      }
      const geom = buildWorldGeometry(this.state.world);
      const mat = new THREE.MeshLambertMaterial({ vertexColors: true });
      this.worldMesh = new THREE.Mesh(geom, mat);
      this.scene.add(this.worldMesh);
      this.needsRebuild = false;
    }

    // Camera follows player eye.
    const eye = this.player.eyePosition;
    this.camera.position.set(eye.x, eye.y, eye.z);
    this.camera.rotation.set(this.player.pitch, this.player.yaw, 0, 'YXZ');

    this.renderer.render(this.scene, this.camera);
  }

  // Fallback FPS ticker: guarantees the HUD shows a live frame rate even if the
  // browser throttles requestAnimationFrame (e.g. a backgrounded preview iframe).
  _startFpsFallback() {
    if (this._fpsTimer) return;
    this._fpsTickFrames = 0;
    this._fpsTimer = setInterval(() => {
      if (this._fpsTickFrames > 0) {
        const fps = Math.max(1, this._fpsTickFrames);
        this.fps = fps;
        this.fpsFrames = 0;
        this._prevFps = null;
        this._fpsTickFrames = 0;
        if (this.fpsEl) this.fpsEl.textContent = 'FPS: ' + fps;
      }
    }, 300);
  }

  // ---- Debug API ------------------------------------------------------

  installDebug() {
    window.voxelDebug = {
      snapshot: () => ({
        player: { x: this.player.pos.x, y: this.player.pos.y, z: this.player.pos.z },
        selected: this.selected,
        targeted: this.targeted
          ? { x: this.targeted.x, y: this.targeted.y, z: this.targeted.z }
          : null,
        editCount: this.state.world.editCount,
      }),
      getBlock: (x, y, z) => this.state.world.getBlock(x, y, z),
      teleport: (x, y, z) => {
        this.player.pos.x = x;
        this.player.pos.y = y;
        this.player.pos.z = z;
        this.player.vel.x = 0;
        this.player.vel.y = 0;
        this.player.vel.z = 0;
      },
    };
  }
}

export function startGame() {
  const game = new Game();
  game.installDebug();
  return game;
}
