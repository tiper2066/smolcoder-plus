// World: an immutable-ish block store over a fixed box [0, sizeX) x [0, sizeY) x [0, sizeZ).
// All logic (bounds, edits, serialization) lives here so it can be unit-tested without Three.js.

import { AIR, isSolid } from './blocks.js';

export class World {
  constructor(sizeX, sizeY, sizeZ) {
    this.sizeX = sizeX;
    this.sizeY = sizeY;
    this.sizeZ = sizeZ;
    this.data = new Uint8Array(sizeX * sizeY * sizeZ);
    this.editCount = 0;
  }

  inBounds(x, y, z) {
    return (
      Number.isInteger(x) &&
      Number.isInteger(y) &&
      Number.isInteger(z) &&
      x >= 0 && x < this.sizeX &&
      y >= 0 && y < this.sizeY &&
      z >= 0 && z < this.sizeZ
    );
  }

  index(x, y, z) {
    return (z * this.sizeX + x) * this.sizeY + y;
  }

  getBlock(x, y, z) {
    if (!this.inBounds(x, y, z)) return AIR;
    return this.data[this.index(x, y, z)];
  }

  // Returns false if out of bounds; true after a successful edit.
  setBlock(x, y, z, type) {
    if (!this.inBounds(x, y, z)) return false;
    if (type === this.data[this.index(x, y, z)]) return false;
    this.data[this.index(x, y, z)] = type;
    this.editCount++;
    return true;
  }

  isSolidAt(x, y, z) {
    return isSolid(this.getBlock(x, y, z));
  }

  // Highest solid block y at column (x,z), or -1 if the column is empty.
  surfaceY(x, z) {
    if (x < 0 || x >= this.sizeX || z < 0 || z >= this.sizeZ) return -1;
    for (let y = this.sizeY - 1; y >= 0; y--) {
      if (this.isSolidAt(x, y, z)) return y;
    }
    return -1;
  }

  // First solid block y at or above `y` for column (x,z) (for spawn clamping), or -1.
  firstSolidYAtOrAbove(x, z, y) {
    if (x < 0 || x >= this.sizeX || z < 0 || z >= this.sizeZ) return -1;
    for (let yy = y; yy < this.sizeY; yy++) {
      if (this.isSolidAt(x, yy, z)) return yy;
    }
    return -1;
  }

  // ---- Serialization -------------------------------------------------

  serialize() {
    return {
      sizeX: this.sizeX,
      sizeY: this.sizeY,
      sizeZ: this.sizeZ,
      editCount: this.editCount,
      // Base64 the byte array so localStorage stays text-safe.
      data: btoaBytes(this.data),
    };
  }

  static deserialize(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const { sizeX, sizeY, sizeZ, data, editCount } = raw;
    if (
      !Number.isInteger(sizeX) || !Number.isInteger(sizeY) || !Number.isInteger(sizeZ) ||
      sizeX < 1 || sizeY < 1 || sizeZ < 1
    ) return null;
    let bytes = null;
    if (typeof data === 'string') {
      try { bytes = atobBytes(data); } catch { return null; }
    }
    if (!bytes || bytes.length !== sizeX * sizeY * sizeZ) return null;
    // Sanity: every stored value must be a valid block id.
    for (let i = 0; i < bytes.length; i++) {
      if (bytes[i] > 5) return null;
    }
    const w = new World(sizeX, sizeY, sizeZ);
    w.data.set(bytes);
    w.editCount = Number.isInteger(editCount) ? editCount : 0;
    return w;
  }
}

// Small base64 helpers kept in pure JS so Node tests don't need atob/btoa.
function btoaBytes(bytes) {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return b64Encode(bin);
}

function atobBytes(b64) {
  const bin = b64Decode(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

const B64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function b64Encode(input) {
  if (typeof globalThis.btoa === 'function') return globalThis.btoa(input);
  let out = '';
  for (let i = 0; i < input.length; i += 3) {
    const a = input.charCodeAt(i);
    const b = i + 1 < input.length ? input.charCodeAt(i + 1) : -1;
    const c = i + 2 < input.length ? input.charCodeAt(i + 2) : -1;
    out += B64_ALPHABET[a >> 2];
    out += B64_ALPHABET[((a & 3) << 4) | (b === -1 ? 0 : b >> 4)];
    out += b === -1 ? '=' : B64_ALPHABET[((b & 15) << 2) | (c === -1 ? 0 : c >> 6)];
    out += c === -1 ? '=' : B64_ALPHABET[c & 63];
  }
  return out;
}

function b64Decode(input) {
  if (typeof globalThis.atob === 'function') return globalThis.atob(input);
  const clean = String(input).replace(/[^A-Za-z0-9+/]/g, '');
  let out = '';
  for (let i = 0; i < clean.length; i += 4) {
    const n1 = B64_ALPHABET.indexOf(clean[i]);
    const n2 = B64_ALPHABET.indexOf(clean[i + 1]);
    const n3 = clean[i + 2] === '=' ? -1 : B64_ALPHABET.indexOf(clean[i + 2]);
    const n4 = clean[i + 3] === '=' ? -1 : B64_ALPHABET.indexOf(clean[i + 3]);
    out += String.fromCharCode((n1 << 2) | (n2 >> 4));
    if (n3 !== -1) out += String.fromCharCode(((n2 & 15) << 4) | (n3 >> 2));
    if (n4 !== -1) out += String.fromCharCode(((n3 & 3) << 6) | n4);
  }
  return out;
}
