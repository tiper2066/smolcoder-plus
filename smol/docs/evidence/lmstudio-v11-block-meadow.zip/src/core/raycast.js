// DDA voxel raycast (Amanatides & Woo). Returns the first solid block hit
// and the face normal of the cell it entered, so we know where to place a block.

import { AIR } from './blocks.js';

export function raycast(world, origin, direction, maxDistance = 8) {
  const o = { x: origin.x, y: origin.y, z: origin.z };
  const d = normalize({ x: direction.x, y: direction.y, z: direction.z });
  if (d.x === 0 && d.y === 0 && d.z === 0) return null;

  let ix = Math.floor(o.x);
  let iy = Math.floor(o.y);
  let iz = Math.floor(o.z);

  const stepX = d.x > 0 ? 1 : -1;
  const stepY = d.y > 0 ? 1 : -1;
  const stepZ = d.z > 0 ? 1 : -1;

  const tDeltaX = d.x !== 0 ? Math.abs(1 / d.x) : Infinity;
  const tDeltaY = d.y !== 0 ? Math.abs(1 / d.y) : Infinity;
  const tDeltaZ = d.z !== 0 ? Math.abs(1 / d.z) : Infinity;

  let tMaxX = d.x !== 0 ? ((stepX > 0 ? ix + 1 - o.x : o.x - ix) * tDeltaX) : Infinity;
  let tMaxY = d.y !== 0 ? ((stepY > 0 ? iy + 1 - o.y : o.y - iy) * tDeltaY) : Infinity;
  let tMaxZ = d.z !== 0 ? ((stepZ > 0 ? iz + 1 - o.z : o.z - iz) * tDeltaZ) : Infinity;

  let face = { x: 0, y: 0, z: 0 };
  let t = 0;

  while (t <= maxDistance) {
    if (world.inBounds(ix, iy, iz) && world.getBlock(ix, iy, iz) !== AIR) {
      return { x: ix, y: iy, z: iz, face, type: world.getBlock(ix, iy, iz) };
    }
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      ix += stepX; t = tMaxX; tMaxX += tDeltaX;
      face = { x: -stepX, y: 0, z: 0 };
    } else if (tMaxY < tMaxZ) {
      iy += stepY; t = tMaxY; tMaxY += tDeltaY;
      face = { x: 0, y: -stepY, z: 0 };
    } else {
      iz += stepZ; t = tMaxZ; tMaxZ += tDeltaZ;
      face = { x: 0, y: 0, z: -stepZ };
    }
  }
  return null;
}

function normalize(v) {
  const len = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
  if (len === 0) return v;
  return { x: v.x / len, y: v.y / len, z: v.z / len };
}

// True if an axis-aligned player box (feet at pos) overlaps the block cell
// (bx, by, bz). Used to refuse placements inside the player body.
export function playerIntersectsBlock(pos, bx, by, bz, halfW = 0.3, height = 1.8) {
  const px = pos.x, py = pos.y, pz = pos.z;
  return (
    px + halfW > bx && px - halfW < bx + 1 &&
    py + height > by && py < by + 1 &&
    pz + halfW > bz && pz - halfW < bz + 1
  );
}
