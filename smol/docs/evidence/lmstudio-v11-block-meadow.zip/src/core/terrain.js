// Deterministic seeded terrain generation. Pure logic, no rendering.

import { World } from './world.js';
import { GRASS, DIRT, STONE, WOOD, LEAVES } from './blocks.js';

export const WORLD_SIZE_X = 48;
export const WORLD_SIZE_Z = 48;
export const WORLD_SIZE_Y = 24;

// ---- Seeded PRNG (mulberry32) ---------------------------------------
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Cheap value-noise: hash a lattice point, bilinearly interpolate.
function hash2(x, z, seed) {
  let h = seed >>> 0;
  h = Math.imul(h ^ x, 0x27d4eb2d);
  h = Math.imul(h ^ z, 0x165667b1);
  h ^= h >>> 15;
  h = Math.imul(h, 0x2c1b3c6d);
  return ((h ^ (h >>> 13)) >>> 0) / 4294967296;
}

function smooth(t) {
  return t * t * (3 - 2 * t);
}

export function valueNoise2(x, z, seed) {
  const xi = Math.floor(x);
  const zi = Math.floor(z);
  const tx = smooth(x - xi);
  const tz = smooth(z - zi);
  const a = hash2(xi, zi, seed);
  const b = hash2(xi + 1, zi, seed);
  const c = hash2(xi, zi + 1, seed);
  const d = hash2(xi + 1, zi + 1, seed);
  const top = a + (b - a) * tx;
  const bot = c + (d - c) * tx;
  return top + (bot - top) * tz;
}

// Fractal (2-octave) noise in [0,1].
export function fbm2(x, z, seed) {
  return 0.7 * valueNoise2(x, z, seed) + 0.3 * valueNoise2(x * 2.3, z * 2.3, seed ^ 0x9e3779b9);
}

// Lake: a smooth bowl offset from the world center.
export function lakeDepth(x, z) {
  const cx = WORLD_SIZE_X / 2 - 8;
  const cz = WORLD_SIZE_Z / 2 + 6;
  const dx = x - cx;
  const dz = z - cz;
  const r = Math.sqrt(dx * dx + dz * dz);
  const R = 9;
  if (r >= R) return 0;
  const t = 1 - r / R;
  return t * t * 5;
}

// Heightmap in blocks (float before rounding).
export function heightAt(x, z, seed) {
  const base = 6;
  const n = fbm2(x * 0.08 + 13.1, z * 0.08 + 7.7, seed);
  let h = base + n * 9;
  const lake = lakeDepth(x, z);
  if (lake > 0) h -= lake;
  return h;
}

// Build a complete world: layered ground (grass/dirt/stone), air below lake
// level, and a handful of trees on dry land.
export function generateWorld(seed = 1337, sizeX = WORLD_SIZE_X, sizeY = WORLD_SIZE_Y, sizeZ = WORLD_SIZE_Z) {
  const world = new World(sizeX, sizeY, sizeZ);

  for (let x = 0; x < sizeX; x++) {
    for (let z = 0; z < sizeZ; z++) {
      const h = Math.max(1, Math.round(heightAt(x, z, seed)));
      const topY = Math.min(h, sizeY - 1);
      for (let y = 0; y <= topY; y++) {
        let type;
        if (y === topY) type = topY <= 4 ? DIRT : GRASS;
        else if (y >= topY - 3) type = DIRT;
        else type = STONE;
        world.data[world.index(x, y, z)] = type;
      }
    }
  }

  // Trees: candidate spots on dry, flat-ish ground with enough headroom.
  const rand = mulberry32(seed ^ 0x51ed270b);
  let placed = 0;
  let attempts = 0;
  const targetTrees = 7;
  while (placed < targetTrees && attempts < 400) {
    attempts++;
    const x = 2 + Math.floor(rand() * (sizeX - 4));
    const z = 2 + Math.floor(rand() * (sizeZ - 4));
    const topY = world.surfaceY(x, z);
    if (topY < 2 || topY > sizeY - 7) continue;
    if (world.getBlock(x, topY, z) !== GRASS) continue;
    if (lakeDepth(x, z) > 0) continue;
    const h0 = heightAt(x, z, seed);
    if (Math.abs(heightAt(x + 1, z, seed) - h0) > 1.2) continue;
    if (Math.abs(heightAt(x - 1, z, seed) - h0) > 1.2) continue;
    if (Math.abs(heightAt(x, z + 1, seed) - h0) > 1.2) continue;
    if (Math.abs(heightAt(x, z - 1, seed) - h0) > 1.2) continue;
    placeTree(world, x, z, topY, sizeY);
    placed++;
  }

  return world;
}

// A 4-tall trunk with a rounded 3x3x3 canopy.
function placeTree(world, x, z, topY, sizeY) {
  for (let i = 1; i <= 4; i++) {
    if (topY + i < sizeY) world.setBlock(x, topY + i, z, WOOD);
  }
  const cy = topY + 5;
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (dx === 0 && dy === 0 && dz === 0) continue;
        const y = cy + dy;
        if (y < 0 || y >= sizeY) continue;
        if (!world.isSolidAt(x + dx, y, z + dz)) {
          world.setBlock(x + dx, y, z + dz, LEAVES);
        }
      }
    }
  }
}
