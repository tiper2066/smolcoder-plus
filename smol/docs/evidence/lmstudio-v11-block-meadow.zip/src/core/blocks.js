// Block type constants and metadata. Air is 0, solid blocks are 1+.
export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const WOOD = 4;
export const LEAVES = 5;

// Hotbar order (slots 0..4) maps to number keys 1..5.
export const HOTBAR = [GRASS, DIRT, STONE, WOOD, LEAVES];

// Base color per block (top face). Side/bottom variants are derived.
export const BLOCK_COLORS = {
  [GRASS]: { top: 0x5daa42, side: 0x7a5230, bottom: 0x6b4527 },
  [DIRT]: { top: 0x7a5230, side: 0x7a5230, bottom: 0x6b4527 },
  [STONE]: { top: 0x8b8f98, side: 0x7f838c, bottom: 0x6f737c },
  [WOOD]: { top: 0x8a6a3f, side: 0x6b4a2b, bottom: 0x5a3d22 },
  [LEAVES]: { top: 0x3e7d2f, side: 0x357028, bottom: 0x2d5f21 },
};

export const BLOCK_NAMES = {
  [GRASS]: 'Grass',
  [DIRT]: 'Dirt',
  [STONE]: 'Stone',
  [WOOD]: 'Wood',
  [LEAVES]: 'Leaves',
};

export function isSolid(type) {
  return type !== AIR;
}

export function isValidType(type) {
  return (
    typeof type === 'number' &&
    Number.isInteger(type) &&
    type >= 1 &&
    type <= 5
  );
}
