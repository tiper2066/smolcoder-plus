// localStorage-backed save/load. Never throws; invalid data yields nulls.

import { World } from './world.js';
import { generateWorld, WORLD_SIZE_X, WORLD_SIZE_Y, WORLD_SIZE_Z } from './terrain.js';
import { isValidType, HOTBAR } from './blocks.js';

export const SAVE_KEY = 'block-meadow.save.v1';

export function loadSave() {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const obj = JSON.parse(raw);
    if (!obj || typeof obj !== 'object') return null;
    const world = World.deserialize(obj.world);
    if (!world) return null;
    const selected = HOTBAR.includes(obj.selected) ? obj.selected : HOTBAR[0];
    const player = validPos(obj.player) ? obj.player : null;
    return { world, selected, player };
  } catch (err) {
    console.warn('loadSave failed:', err);
    return null;
  }
}

export function saveGame(state) {
  try {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({
        world: state.world.serialize(),
        selected: state.selected,
        player: state.player,
        savedAt: Date.now(),
      })
    );
    return true;
  } catch (err) {
    console.warn('saveGame failed:', err);
    return false;
  }
}

export function clearSave() {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch {}
}

export function validPos(p) {
  return (
    p &&
    typeof p.x === 'number' &&
    typeof p.y === 'number' &&
    typeof p.z === 'number' &&
    Number.isFinite(p.x) &&
    Number.isFinite(p.y) &&
    Number.isFinite(p.z) &&
    p.x >= 0 && p.x < WORLD_SIZE_X &&
    p.z >= 0 && p.z < WORLD_SIZE_Z &&
    p.y >= 0 && p.y < WORLD_SIZE_Y
  );
}

export function makeInitialState(seed = 1337) {
  const world = generateWorld(seed);
  const cx = Math.floor(world.sizeX / 2);
  const cz = Math.floor(world.sizeZ / 2);
  const spawn = findSpawn(world, cx, cz);
  return {
    world,
    selected: HOTBAR[0],
    player: { x: spawn.x, y: spawn.y, z: spawn.z },
  };
}

// Pick a spawn column near the center that is on dry land, then stand on it.
export function findSpawn(world, x, z) {
  const y = world.surfaceY(x, z);
  if (y > 0 && y < world.sizeY - 3) {
    return { x: x + 0.5, y: y + 1.01, z: z + 0.5 };
  }
  // Spiral out until we find a dry column.
  for (let r = 1; r < 20; r++) {
    for (let dx = -r; dx <= r; dx++) {
      for (let dz = -r; dz <= r; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue;
        const xx = x + dx, zz = z + dz;
        const yy = world.surfaceY(xx, zz);
        if (yy > 2 && yy < world.sizeY - 3) {
          return { x: xx + 0.5, y: yy + 1.01, z: zz + 0.5 };
        }
      }
    }
  }
  return { x: x + 0.5, y: world.sizeY - 2, z: z + 0.5 };
}
