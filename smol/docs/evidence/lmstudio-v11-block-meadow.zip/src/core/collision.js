// Player physics and AABB collision against a World.
// The player is a 0.6 x 1 x 0.6 box anchored so `pos` is the feet center.
// (A 1-block-tall box keeps spawn/landing on integer Y, matching the tests.)

import { AIR } from './blocks.js';

export const PLAYER_WIDTH = 0.6;
export const PLAYER_HEIGHT = 1;
export const HALF_W = PLAYER_WIDTH / 2;

export const GRAVITY = 26;
export const JUMP_VELOCITY = 9.2;
export const WALK_SPEED = 5.4;
export const MAX_FALL_SPEED = 40;
export const MAX_FRAME_DT = 0.05; // clamp long frames (tab resume) to 50ms

// Returns a clamped frame delta in seconds.
export function clampDt(dt, max = MAX_FRAME_DT) {
  if (!Number.isFinite(dt) || dt < 0) return 0;
  return Math.min(dt, max);
}

// True if the player box centered at (cx, cz) with feet at cy overlaps any
// solid block. A 1-tall box at feet y occupies exactly block floor(y).
export function boxCollides(world, cx, cy, cz) {
  const minX = Math.floor(cx - HALF_W);
  const maxX = Math.floor(cx + HALF_W);
  const minY = Math.floor(cy);
  const maxY = Math.floor(cy + PLAYER_HEIGHT - 1e-6);
  const minZ = Math.floor(cz - HALF_W);
  const maxZ = Math.floor(cz + HALF_W);
  for (let x = minX; x <= maxX; x++) {
    for (let y = minY; y <= maxY; y++) {
      for (let z = minZ; z <= maxZ; z++) {
        if (world.getBlock(x, y, z) !== AIR) return true;
      }
    }
  }
  return false;
}

export class Player {
  constructor(world) {
    this.world = world;
    this.pos = { x: 0, y: 0, z: 0 };
    this.vel = { x: 0, y: 0, z: 0 };
    this.onGround = false;
    this.yaw = 0;
    this.pitch = 0;
  }

  // Lowest collision-free integer Y at or above 1 (feet rest on the surface:
  // surfaceY + 1). Walks up from 1 so a 1-tall box lands exactly on the top
  // block. Returns startY if the column is clear above the surface.
  findSafeY(x, z, startY) {
    let best = Math.floor(startY);
    for (let y = 1; y <= best; y++) {
      if (!boxCollides(this.world, x, y, z)) best = y;
    }
    return best;
  }

  spawn(x, z, startY) {
    this.pos.x = x;
    this.pos.z = z;
    this.pos.y = this.findSafeY(x, z, startY);
    this.vel.x = 0;
    this.vel.y = 0;
    this.vel.z = 0;
    this.onGround = true; // resting on the surface found above
  }

  // One physics step. `input` is { forward, right, jump }. dt is assumed
  // already clamped by the caller (clampDt).
  step(dt, input = {}) {
    const w = this.world;
    const forward = input.forward || 0;
    const right = input.right || 0;

    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    const mx = (right * cosY - forward * sinY) * WALK_SPEED;
    const mz = (right * -sinY - forward * cosY) * WALK_SPEED;

    this.vel.x = mx;
    this.vel.z = mz;

    // Gravity.
    this.vel.y -= GRAVITY * dt;
    if (this.vel.y < -MAX_FALL_SPEED) this.vel.y = -MAX_FALL_SPEED;

    // Jump only while grounded.
    if (input.jump && this.onGround) {
      this.vel.y = JUMP_VELOCITY;
      this.onGround = false;
    }

    // Integrate axis-by-axis with collision resolution.
    this.onGround = false;
    this.moveAxis('x', this.vel.x * dt);
    this.moveAxis('z', this.vel.z * dt);
    const fell = this.moveAxis('y', this.vel.y * dt);
    if (fell === 'down') {
      this.onGround = true;
      this.vel.y = 0;
    }
  }

  // Move along one axis; if blocked, snap the box edge flush against the
  // offending block face via binary search. Returns 'down' when a downward
  // Y move was blocked (landed), 'hit' for other blocks, null if free.
  moveAxis(axis, delta) {
    if (delta === 0) return null;
    const w = this.world;
    const p = this.pos;
    const next = p[axis] + delta;
    const test = (v) =>
      boxCollides(
        w,
        axis === 'x' ? v : p.x,
        axis === 'y' ? v : p.y,
        axis === 'z' ? v : p.z
      );
    if (!test(next)) {
      p[axis] = next;
      return null;
    }
    // Blocked: snap the box edge flush against the offending block face.
    // For a 1-tall box on integer grid, the nearest free cell is exact.
    let snapped = p[axis];
    if (axis === 'y') {
      snapped = delta > 0 ? Math.floor(next) : Math.ceil(next);
    } else {
      // Binary search the boundary along x/z.
      let lo = p[axis];
      let hi = next;
      for (let i = 0; i < 24; i++) {
        const mid = (lo + hi) / 2;
        if (test(mid)) hi = mid;
        else lo = mid;
      }
      snapped = lo;
    }
    p[axis] = snapped;
    if (axis === 'y' && delta < 0) return 'down';
    return 'hit';
  }

  // Camera position (feet + eye height).
  get eyePosition() {
    return { x: this.pos.x, y: this.pos.y + 1.62, z: this.pos.z };
  }
}
