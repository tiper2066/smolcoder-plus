import { AIR } from './blocks.js';

export const PLAYER = {
  width: 0.6,   // radius (collision box half-width)
  height: 1.8,
  eye: 1.62,
  speed: 5.2,
  sprint: 8.0,
  gravity: 22,
  jump: 7.6,
  maxDelta: 1 / 20 // clamp dt so tab restore can't launch the player
};

export const clampDelta = (dt) => Math.min(Math.max(dt, 0), PLAYER.maxDelta);

export function isSolid(world, x, y, z) {
  const t = world.blocks
    ? (typeof world.getBlock === 'function'
        ? world.getBlock(x, y, z)
        : (world.blocks[(z * world.size + x) * world.height + y] ?? AIR))
    : AIR;
  return t !== AIR;
}

// Solid check using a provided getBlock function (world may be custom).
export function solidAt(getBlock, x, y, z) {
  return getBlock(x, y, z) !== AIR;
}

// Collision: player AABB (x-r..x+r, y..y+h, z-r..z+r) against block grid.
export function collides(getBlock, x, y, z, r = PLAYER.width, h = PLAYER.height) {
  const minX = Math.floor(x - r), maxX = Math.floor(x + r);
  const minY = Math.floor(y), maxY = Math.floor(y + h - 0.001);
  const minZ = Math.floor(z - r), maxZ = Math.floor(z + r);
  for (let bx = minX; bx <= maxX; bx++) {
    for (let by = minY; by <= maxY; by++) {
      for (let bz = minZ; bz <= maxZ; bz++) {
        if (solidAt(getBlock, bx, by, bz)) return true;
      }
    }
  }
  return false;
}

export function createPlayer(state = { x: 0, y: 10, z: 0 }) {
  return {
    x: state.x,
    y: state.y,
    z: state.z,
    vx: 0, vy: 0, vz: 0,
    grounded: false
  };
}

// Integrate one step with axis-separated collision.
// opts: { input: {forward, strafe, jump, sprint}, dt }
export function stepPlayer(player, getBlock, dt, input = { forward: 0, strafe: 0, jump: false }) {
  dt = clampDelta(dt);
  const { x: px, y: py, z: pz } = player;
  const r = PLAYER.width, h = PLAYER.height;

  // Gravity
  player.vy -= PLAYER.gravity * dt;
  if (player.vy < -40) player.vy = -40;

  // Horizontal wish direction (supplied already rotated by caller, unit-ish)
  const speed = input.sprint ? PLAYER.sprint : PLAYER.speed;
  const targetVx = input.forward * speed;
  const targetVz = input.strafe * speed;
  // Snappy acceleration
  const accel = player.grounded ? 12 : 4;
  const t = Math.min(1, accel * dt);
  player.vx += (targetVx - player.vx) * t;
  player.vz += (targetVz - player.vz) * t;

  // Jump (only when grounded)
  if (input.jump && player.grounded) {
    player.vy = PLAYER.jump;
    player.grounded = false;
  }

  // Axis-separated moves
  let nx = px + player.vx * dt;
  if (collides(getBlock, nx, py, pz, r, h)) {
    // Push out to nearest face
    if (player.vx > 0) nx = Math.floor(px + r + 0.001) - r - 0.001;
    else if (player.vx < 0) nx = Math.floor(px - r - 0.001) + 1 + r + 0.001;
    player.vx = 0;
    // still try small nudge
    if (collides(getBlock, nx, py, pz, r, h)) { nx = px; }
  }
  player.x = nx;

  let nz = pz + player.vz * dt;
  if (collides(getBlock, player.x, py, nz, r, h)) {
    if (player.vz > 0) nz = Math.floor(pz + r + 0.001) - r - 0.001;
    else if (player.vz < 0) nz = Math.floor(pz - r - 0.001) + 1 + r + 0.001;
    player.vz = 0;
    if (collides(getBlock, player.x, py, nz, r, h)) { nz = pz; }
  }
  player.z = nz;

  // Vertical sweep with exact collision resolution (handles tunneling)
  const nyRaw = py + player.vy * dt;
  let ny = nyRaw;
  if (nyRaw < py) {
    // Swept downward: find top of highest solid block in the swept column
    const feetMin = nyRaw;
    const feetMax = py;
    const top = findTopSolid(getBlock, player.x, player.z, feetMin, feetMax, r, h);
    if (top !== null) {
      ny = top;
      player.vy = 0;
      player.grounded = true;
    } else {
      player.grounded = false;
    }
  } else if (nyRaw > py) {
    // Swept upward: find bottom of lowest solid block the head enters
    const headMin = py + h;
    const headMax = nyRaw + h;
    const bottom = findBottomSolid(getBlock, player.x, player.z, headMin, headMax, r, h);
    if (bottom !== null) {
      ny = Math.min(nyRaw, bottom - h);
      player.vy = 0;
      player.grounded = false;
    } else {
      player.grounded = false;
      // Check if we're standing on something (floor probe)
      if (solidBelow(getBlock, player.x, player.z, py, r, h)) player.grounded = true;
    }
  } else {
    player.grounded = solidBelow(getBlock, player.x, player.z, py, r, h);
  }
  player.y = ny;
  return player;
}

// Highest top surface (integer) of a solid block whose cell [b, b+1) overlaps (feetMin, feetMax)
// and whose AABB intersects the player's horizontal extent. Returns b+1, or null.
function findTopSolid(getBlock, px, pz, feetMin, feetMax, r, h) {
  const minX = Math.floor(px - r), maxX = Math.floor(px + r);
  const minZ = Math.floor(pz - r), maxZ = Math.floor(pz + r);
  const yMin = Math.floor(feetMin);
  const yMax = Math.floor(feetMax - 1e-9);
  let best = null;
  for (let bx = minX; bx <= maxX; bx++) {
    for (let bz = minZ; bz <= maxZ; bz++) {
      for (let by = yMin; by <= yMax; by++) {
        if (getBlock(bx, by, bz) !== 0) {
          const top = by + 1;
          if (top > feetMin - 1e-6 && (best === null || top > best)) best = top;
        }
      }
    }
  }
  return best;
}

// Lowest bottom surface (integer) of a solid block in the swept head range.
function findBottomSolid(getBlock, px, pz, headMin, headMax, r, h) {
  const minX = Math.floor(px - r), maxX = Math.floor(px + r);
  const minZ = Math.floor(pz - r), maxZ = Math.floor(pz + r);
  const yMin = Math.floor(headMin - 1e-9);
  const yMax = Math.floor(headMax);
  let best = null;
  for (let bx = minX; bx <= maxX; bx++) {
    for (let bz = minZ; bz <= maxZ; bz++) {
      for (let by = yMin; by <= yMax; by++) {
        if (getBlock(bx, by, bz) !== 0) {
          if (best === null || by < best) best = by;
        }
      }
    }
  }
  return best;
}

// Is there a solid block directly under the player's feet?
function solidBelow(getBlock, px, pz, py, r, h) {
  const minX = Math.floor(px - r), maxX = Math.floor(px + r);
  const minZ = Math.floor(pz - r), maxZ = Math.floor(pz + r);
  const footY = Math.floor(py + 1e-6);
  for (let bx = minX; bx <= maxX; bx++) {
    for (let bz = minZ; bz <= maxZ; bz++) {
      if (getBlock(bx, footY - 1, bz) !== 0) return true;
    }
  }
  return false;
}

// Can a block be placed at (x,y,z) without intersecting the player AABB?
export function blockIntersectsPlayer(px, py, pz, bx, by, bz, r = PLAYER.width, h = PLAYER.height) {
  return (
    bx + 1 > px - r && bx < px + r &&
    by + 1 > py && by < py + h &&
    bz + 1 > pz - r && bz < pz + r
  );
}
