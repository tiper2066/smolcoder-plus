import * as THREE from 'three';

const PLAYER_RADIUS = 0.3;

// DDA voxel raycast: from origin in direction, up to maxDist.
// Returns {x,y,z,fx,fy,fz,type} for the first solid block hit, or null.
// Uses a provided getBlock(x,y,z) -> type (AIR=0 means empty).
export function raycastVoxel(getBlock, origin, dir, maxDist = 6) {
  let x = Math.floor(origin.x), y = Math.floor(origin.y), z = Math.floor(origin.z);
  const stepX = dir.x > 0 ? 1 : -1;
  const stepY = dir.y > 0 ? 1 : -1;
  const stepZ = dir.z > 0 ? 1 : -1;

  const tDeltaX = Math.abs(1 / (dir.x || 1e-10));
  const tDeltaY = Math.abs(1 / (dir.y || 1e-10));
  const tDeltaZ = Math.abs(1 / (dir.z || 1e-10));

  let tMaxX = ((stepX > 0 ? (x + 1 - origin.x) : (origin.x - x)) ) * tDeltaX;
  let tMaxY = ((stepY > 0 ? (y + 1 - origin.y) : (origin.y - y)) ) * tDeltaY;
  let tMaxZ = ((stepZ > 0 ? (z + 1 - origin.z) : (origin.z - z)) ) * tDeltaZ;

  let face = null;
  let t = 0;

  // If the starting cell is solid, treat as immediate hit (with normal from dir)
  if (getBlock(x, y, z) !== 0) {
    face = faceFromDir(dir);
    return { x, y, z, face, t: 0, type: getBlock(x, y, z) };
  }

  while (t < maxDist) {
    if (tMaxX < tMaxY && tMaxX < tMaxZ) {
      x += stepX; t = tMaxX; tMaxX += tDeltaX; face = { x: -stepX, y: 0, z: 0 };
    } else if (tMaxY < tMaxZ) {
      y += stepY; t = tMaxY; tMaxY += tDeltaY; face = { x: 0, y: -stepY, z: 0 };
    } else {
      z += stepZ; t = tMaxZ; tMaxZ += tDeltaZ; face = { x: 0, y: 0, z: -stepZ };
    }
    const type = getBlock(x, y, z);
    if (type !== 0) {
      return { x, y, z, face, t, type };
    }
  }
  return null;
}

function faceFromDir(dir) {
  if (Math.abs(dir.x) > Math.abs(dir.y) && Math.abs(dir.x) > Math.abs(dir.z)) {
    return { x: dir.x > 0 ? -1 : 1, y: 0, z: 0 };
  }
  if (Math.abs(dir.y) > Math.abs(dir.z)) {
    return { x: 0, y: dir.y > 0 ? -1 : 1, z: 0 };
  }
  return { x: 0, y: 0, z: dir.z > 0 ? -1 : 1 };
}

// Whether placing a block at integer (bx,by,bz) would intersect the player AABB.
export function blockHitsPlayer(px, py, pz, bx, by, bz) {
  return (
    bx + 1 > px - PLAYER_RADIUS && bx < px + PLAYER_RADIUS &&
    by + 1 > py && by < py + 1.8 &&
    bz + 1 > pz - PLAYER_RADIUS && bz < pz + PLAYER_RADIUS
  );
}
