import * as THREE from 'three';
import { createWorld, DEFAULT_SEED, findSpawn, getBlock, setBlock, saveToStorage, loadFromStorage, deserializeWorld, clearSave, inBounds } from './world.js';
import { BLOCK_NAMES, HOTBAR_BLOCKS, GRASS } from './blocks.js';
import { createScene, createTargetOutline } from './sceneSetup.js';
import { createBlockRenderer } from './renderer.js';
import { createPlayer, stepPlayer, blockIntersectsPlayer } from './physics.js';
import { raycastVoxel } from './raycast.js';

const gameRoot = document.getElementById('game-root');
const hud = document.getElementById('hud');
const fpsEl = document.getElementById('fps');
const hotbarWrap = document.getElementById('hotbar-wrap');
const hotbarEl = document.getElementById('hotbar');
const slotEls = Array.from(hotbarEl.querySelectorAll('.slot'));
const menuEl = document.getElementById('menu');
const playBtn = document.getElementById('play-btn');
const menuSaveBtn = document.getElementById('menu-save');
const menuNewBtn = document.getElementById('menu-new');
const saveBtn = document.getElementById('save-btn');
const newWorldBtn = document.getElementById('newworld-btn');
const toastEl = document.getElementById('toast');

let renderer, scene, camera, outline, blockRenderer;
let world, player;
let selectedBlock = GRASS;
let locked = false;
let keys = {};
let pendingJump = false;
let lastTime = performance.now();
let fpsAccum = 0, fpsFrames = 0, fpsValue = 0;

function init() {
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  gameRoot.appendChild(renderer.domElement);

  const { scene: s } = createScene();
  scene = s;

  camera = new THREE.PerspectiveCamera(72, window.innerWidth / window.innerHeight, 0.1, 400);
  camera.rotation.order = 'YXZ';
  scene.add(camera);

  outline = createTargetOutline();
  scene.add(outline);

  blockRenderer = createBlockRenderer(scene);

  // Load or create
  const saved = loadFromStorage(window.localStorage);
  if (saved) {
    const restored = deserializeWorld(saved);
    if (restored) {
      world = restored;
      if (saved.player && isFinite(saved.player.x)) {
        player = { x: saved.player.x, y: saved.player.y, z: saved.player.z, vx: 0, vy: 0, vz: 0, grounded: false };
      } else {
        const spawn = findSpawn(world);
        player = { ...spawn, vx: 0, vy: 0, vz: 0, grounded: false };
      }
      selectedBlock = HOTBAR_BLOCKS.includes(saved.selected) ? saved.selected : GRASS;
      toast('World restored');
    } else {
      world = createWorld();
      player = { ...findSpawn(world), vx: 0, vy: 0, vz: 0, grounded: false };
      toast('Saved data invalid — new world created');
    }
  } else {
    world = createWorld();
    player = { ...findSpawn(world), vx: 0, vy: 0, vz: 0, grounded: false };
  }

  blockRenderer.rebuild(world);
  camera.position.set(player.x, player.y + 1.62, player.z);

  window.addEventListener('resize', onResize);
  document.addEventListener('pointerlockchange', onLockChange);
  document.addEventListener('mousemove', onMouseMove);
  document.addEventListener('mousedown', onMouseDown);
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  window.addEventListener('contextmenu', (e) => e.preventDefault());

  slotEls.forEach((el) => {
    el.addEventListener('click', () => {
      const idx = slotEls.indexOf(el);
      setSelected(HOTBAR_BLOCKS[idx]);
    });
  });

  playBtn.addEventListener('click', () => requestLock());
  menuSaveBtn.addEventListener('click', doSave);
  menuNewBtn.addEventListener('click', doNewWorld);
  saveBtn.addEventListener('click', doSave);
  newWorldBtn.addEventListener('click', doNewWorld);

  setSelected(selectedBlock);
  animate();
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function requestLock() {
  renderer.domElement.requestPointerLock();
}

function onLockChange() {
  locked = document.pointerLockElement === renderer.domElement;
  if (locked) {
    menuEl.hidden = true;
    hud.hidden = false;
    hotbarWrap.hidden = false;
    lastTime = performance.now();
  } else {
    menuEl.hidden = false;
    hud.hidden = true;
    hotbarWrap.hidden = true;
    keys = {};
    pendingJump = false;
  }
}

function onMouseMove(e) {
  if (!locked) return;
  const sens = 0.0022;
  camera.rotation.y -= e.movementX * sens;
  camera.rotation.x -= e.movementY * sens;
  const lim = Math.PI / 2 - 0.01;
  camera.rotation.x = Math.max(-lim, Math.min(lim, camera.rotation.x));
}

function onMouseDown(e) {
  if (!locked) return;
  const target = raycastVoxel((x, y, z) => getBlock(world, x, y, z),
    { x: camera.position.x, y: camera.position.y, z: camera.position.z },
    dirFromCamera(), 6);
  if (!target) return;
  if (e.button === 0) {
    // Remove
    if (setBlock(world, target.x, target.y, target.z, 0)) {
      blockRenderer.markDirty();
      blockRenderer.update(scene, world);
    }
  } else if (e.button === 2) {
    // Place adjacent
    const px = target.x + target.face.x;
    const py = target.y + target.face.y;
    const pz = target.z + target.face.z;
    if (!inBounds(px, py, pz)) return;
    if (getBlock(world, px, py, pz) !== 0) return;
    const p = { x: player.x, y: player.y, z: player.z };
    if (blockIntersectsPlayer(p.x, p.y, p.z, px, py, pz)) return;
    if (setBlock(world, px, py, pz, selectedBlock)) {
      blockRenderer.markDirty();
      blockRenderer.update(scene, world);
    }
  }
}

function dirFromCamera() {
  const d = new THREE.Vector3();
  camera.getWorldDirection(d);
  return d;
}

function onKeyDown(e) {
  if (e.code === 'Space') { pendingJump = true; e.preventDefault(); }
  if (e.code.startsWith('Digit')) {
    const n = parseInt(e.code.slice(5), 10);
    if (n >= 1 && n <= 5) setSelected(HOTBAR_BLOCKS[n - 1]);
  }
  keys[e.code] = true;
}

function onKeyUp(e) { keys[e.code] = false; }

function setSelected(type) {
  selectedBlock = type;
  slotEls.forEach((el, i) => {
    const isSel = HOTBAR_BLOCKS[i] === type;
    el.setAttribute('aria-pressed', isSel ? 'true' : 'false');
  });
}

function doSave() {
  const meta = {
    player: { x: player.x, y: player.y, z: player.z },
    selected: selectedBlock
  };
  const ok = saveToStorage(window.localStorage, world, meta);
  toast(ok ? 'World saved' : 'Save failed');
}

function doNewWorld() {
  const ok = confirm('Start a new world? Current changes will be lost.');
  if (!ok) return;
  clearSave(window.localStorage);
  world = createWorld(DEFAULT_SEED + Math.floor(Math.random() * 1e6));
  const spawn = findSpawn(world);
  player = { ...spawn, vx: 0, vy: 0, vz: 0, grounded: false };
  blockRenderer.rebuild(world);
  camera.position.set(player.x, player.y + 1.62, player.z);
  setSelected(GRASS);
  toast('New world created');
  // Re-lock if we were playing
  if (document.pointerLockElement) requestLock();
  else menuEl.hidden = false;
}

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => toastEl.classList.remove('show'), 2000);
}

function inputVec() {
  // Camera-relative forward/strafe
  const yaw = camera.rotation.y;
  const sinY = Math.sin(yaw), cosY = Math.cos(yaw);
  let f = 0, s = 0;
  if (keys['KeyW']) f += 1;
  if (keys['KeyS']) f -= 1;
  if (keys['KeyD']) s += 1;
  if (keys['KeyA']) s -= 1;
  // forward vector on ground: (-sinYaw, 0, -cosYaw); right: (cosYaw, 0, -sinYaw)
  const forward = { x: -sinY * f + cosY * s, z: -cosY * f - sinY * s };
  const len = Math.hypot(forward.x, forward.z) || 1;
  return { forward: forward.x / len * (f !== 0 || s !== 0 ? 1 : 0), strafe: forward.z / len * (f !== 0 || s !== 0 ? 1 : 0), jump: pendingJump, sprint: !!keys['ShiftLeft'] || !!keys['ShiftRight'] };
}

function animate() {
  requestAnimationFrame(animate);
  const now = performance.now();
  let dt = (now - lastTime) / 1000;
  lastTime = now;
  if (dt > 0.1) dt = 0.1; // clamp on tab restore

  // FPS
  fpsAccum += dt; fpsFrames++;
  if (fpsAccum >= 0.5) {
    fpsValue = Math.round(fpsFrames / fpsAccum);
    fpsEl.textContent = fpsValue + ' FPS';
    fpsAccum = 0; fpsFrames = 0;
  }

  if (locked) {
    const input = inputVec();
    pendingJump = false;
    stepPlayer(player, (x, y, z) => getBlock(world, x, y, z), dt, input);
    camera.position.set(player.x, player.y + 1.62, player.z);

    // Target
    const target = raycastVoxel((x, y, z) => getBlock(world, x, y, z),
      { x: camera.position.x, y: camera.position.y, z: camera.position.z },
      dirFromCamera(), 6);
    if (target) {
      outline.visible = true;
      outline.position.set(target.x + 0.5, target.y + 0.5, target.z + 0.5);
      currentTarget = { x: target.x, y: target.y, z: target.z };
    } else {
      outline.visible = false;
      currentTarget = null;
    }
  }

  renderer.render(scene, camera);
}

let currentTarget = null;

// --- Debug API for automated browser checks ---
window.voxelDebug = {
  snapshot() {
    return {
      player: { x: player.x, y: player.y, z: player.z },
      selected: selectedBlock,
      targeted: currentTarget,
      editCount: world.editCount
    };
  },
  getBlock(x, y, z) { return getBlock(world, x, y, z); },
  teleport(x, y, z) {
    player.x = x; player.y = y; player.z = z;
    player.vx = 0; player.vy = 0; player.vz = 0;
    camera.position.set(x, y + 1.62, z);
    return true;
  }
};

init();
