import * as THREE from 'three';

export const SKY = 0x8fd3ff;
export const FOG = 0xbfe4ff;

export function createScene() {
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(SKY);
  scene.fog = new THREE.Fog(FOG, 40, 140);

  const ambient = new THREE.AmbientLight(0xffffff, 0.55);
  scene.add(ambient);

  const sun = new THREE.DirectionalLight(0xfff3d6, 1.0);
  sun.position.set(40, 80, 20);
  scene.add(sun);
  const fill = new THREE.HemisphereLight(0xbfe0ff, 0x6a8a4f, 0.35);
  scene.add(fill);

  return { scene, ambient, sun };
}

export function createTargetOutline() {
  const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.002, 1.002, 1.002));
  const mat = new THREE.LineBasicMaterial({ color: 0x111111 });
  const outline = new THREE.LineSegments(edges, mat);
  outline.visible = false;
  return outline;
}
