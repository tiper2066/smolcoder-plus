// Block types
export const AIR = 0;
export const GRASS = 1;
export const DIRT = 2;
export const STONE = 3;
export const WOOD = 4;
export const LEAVES = 5;

export const BLOCK_NAMES = {
  [GRASS]: 'grass',
  [DIRT]: 'dirt',
  [STONE]: 'stone',
  [WOOD]: 'wood',
  [LEAVES]: 'leaves'
};

export const HOTBAR_BLOCKS = [GRASS, DIRT, STONE, WOOD, LEAVES];

// Colors per block face-top style simple palette
export const BLOCK_COLORS = {
  [GRASS]: 0x56c15a,
  [DIRT]: 0x8a5a34,
  [STONE]: 0x9a9a9a,
  [WOOD]: 0x7a5230,
  [LEAVES]: 0x3d9e3f
};

export function isValidBlockType(t) {
  return Number.isInteger(t) && t >= 1 && t <= LEAVES;
}

export function isOpaque(type) {
  return type !== AIR && type !== LEAVES;
}
