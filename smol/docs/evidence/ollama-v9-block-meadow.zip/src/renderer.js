import * as THREE from 'three';
import { AIR, GRASS, DIRT, STONE, WOOD, LEAVES, BLOCK_COLORS, isOpaque } from './blocks.js';

// Build per-block instanced meshes from the world block array.
// Rebuilds only when the dirty flag is set (after edits).
export function createBlockRenderer(scene) {
  const geoms = {};
  const mats = {};
  const meshes = {};

  for (const type of [GRASS, DIRT, STONE, WOOD, LEAVES]) {
    const geo = new THREE.BoxGeometry(1, 1, 1);
    // Slight per-type vertex jitter? Keep simple: plain box, colored material.
    const mat = new THREE.MeshLambertMaterial({
      color: BLOCK_COLORS[type],
      // Grass gets a subtle top-cap difference via a second material on top face.
    });
    if (type === GRASS) {
      // Grass: green top, dirt-ish sides
      const sideMat = new THREE.MeshLambertMaterial({ color: 0x8a6a40 });
      const topMat = new THREE.MeshLambertMaterial({ color: BLOCK_COLORS[GRASS] });
      // BoxGeometry material groups: [+x,-x,+y,-y,+z,-z]
      mats[type] = [sideMat, sideMat, topMat, mat, sideMat, sideMat];
    } else if (type === LEAVES) {
      mat.transparent = false;
      mats[type] = mat;
    } else {
      mats[type] = mat;
    }
    geoms[type] = geo;
  }

  let dirty = true;

  function rebuild(world) {
    const { size, height, blocks } = world;
    // Clear old
    for (const key of Object.keys(meshes)) {
      scene.remove(meshes[key]);
      meshes[key].dispose();
      delete meshes[key];
    }
    const lists = { [GRASS]: [], [DIRT]: [], [STONE]: [], [WOOD]: [], [LEAVES]: [] };
    for (let z = 0; z < size; z++) {
      for (let x = 0; x < size; x++) {
        for (let y = 0; y < height; y++) {
          const t = blocks[(z * size + x) * height + y];
          if (t === AIR) continue;
          // Exposed-face culling: skip fully enclosed opaque blocks.
          if (isOpaque(t)) {
            const n = (dx, dy, dz) => {
              const nx = x + dx, ny = y + dy, nz = z + dz;
              if (nx < 0 || nx >= size || nz < 0 || nz >= size || ny < 0 || ny >= height) return true; // world edge -> exposed
              return blocks[(nz * size + nx) * height + ny] === AIR;
            };
            if (!(n(1,0,0) || n(-1,0,0) || n(0,1,0) || n(0,-1,0) || n(0,0,1) || n(0,0,-1))) continue;
          }
          lists[t].push(x + 0.5, y + 0.5, z + 0.5);
        }
      }
    }
    const m = new THREE.Matrix4();
    for (const type of Object.keys(lists)) {
      const arr = lists[type];
      const count = arr.length / 3;
      if (count === 0) continue;
      const mesh = new THREE.InstancedMesh(geoms[type], mats[type], count);
      mesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);
      for (let i = 0; i < count; i++) {
        m.makeTranslation(arr[i * 3], arr[i * 3 + 1], arr[i * 3 + 2]);
        mesh.setMatrixAt(i, m);
      }
      mesh.instanceMatrix.needsUpdate = true;
      mesh.frustumCulled = false;
      scene.add(mesh);
      meshes[type] = mesh;
    }
    dirty = false;
  }

  function markDirty() { dirty = true; }

  function update(scene2, world) {
    if (dirty) rebuild(world);
  }

  return { update, markDirty, rebuild };
}
