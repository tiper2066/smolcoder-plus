import { AIR, GRASS, DIRT, STONE, WOOD, LEAVES, isValidBlockType } from './blocks.js';
import { mulberry32, fbm2D } from './noise.js';

export const WORLD_SIZE = 64; // 64x64, exceeds the 48x48 requirement
export const WORLD_HEIGHT = 24;

export const DEFAULT_SEED = 1337;
const SAVE_KEY = 'blockMeadow.save.v1';

export function inBounds(x, y, z) {
  return (
    Number.isInteger(x) &&
    Number.isInteger(y) &&
    Number.isInteger(z) &&
    x >= 0 && x < WORLD_SIZE &&
    y >= 0 && y < WORLD_HEIGHT &&
    z >= 0 && z < WORLD_SIZE
  );
}

export function createWorld(seed = DEFAULT_SEED, size = WORLD_SIZE, height = WORLD_HEIGHT) {
  const world = {
    seed,
    size,
    height,
    blocks: new Uint8Array(size * size * height),
    editCount: 0
  };

  // Lake center — placed deterministically from the seed, away from edges
  const rng = mulberry32(seed ^ 0x9e3779b9);
  const lake = {
    cx: Math.floor(size * (0.3 + rng() * 0.4)),
    cz: Math.floor(size * (0.3 + rng() * 0.4)),
    r: Math.floor(size * 0.09) + 3
  };
  world.lake = lake;

  const base = 6;

  for (let x = 0; x < size; x++) {
    for (let z = 0; z < size; z++) {
      // Rolling hills via fractal noise
      const h = fbm2D(x / 22, z / 22, seed, 4);
      let surface = Math.floor(base + h * 7);

      // Flatten a gentle basin for the lake
      const dx = x - lake.cx;
      const dz = z - lake.cz;
      const dist = Math.sqrt(dx * dx + dz * dz);
      const waterLevel = base + 1;
      if (dist < lake.r) {
        const t = 1 - dist / lake.r;
        surface = Math.min(surface, base + Math.floor(1 - t * 2) - 1);
        surface = Math.max(0, surface);
      }

      for (let y = 0; y <= surface; y++) {
        let type = STONE;
        if (y === surface) type = dist < lake.r ? DIRT : GRASS;
        else if (y >= surface - 2) type = DIRT;
        setBlockRaw(world, x, y, z, type);
      }
    }
  }

  // Trees: deterministic positions, away from the lake
  const treeRng = mulberry32(seed ^ 0x51ed270b);
  const trees = [];
  let attempts = 0;
  while (trees.length < 14 && attempts < 200) {
    attempts++;
    const tx = 4 + Math.floor(treeRng() * (size - 8));
    const tz = 4 + Math.floor(treeRng() * (size - 8));
    const dx = tx - lake.cx, dz = tz - lake.cz;
    if (Math.sqrt(dx * dx + dz * dz) < lake.r + 2) continue;
    if (trees.some((t) => (t.x - tx) ** 2 + (t.z - tz) ** 2 < 16)) continue;

    let top = -1;
    for (let y = height - 1; y >= 0; y--) {
      if (getBlockRaw(world, tx, y, tz) !== AIR) { top = y; break; }
    }
    if (top < 1 || top >= height - 6) continue;
    const trunkH = 3 + Math.floor(treeRng() * 2);
    if (top + trunkH + 2 >= height) continue;

    for (let i = 1; i <= trunkH; i++) setBlockRaw(world, tx, top + i, tz, WOOD);
    const crownY = top + trunkH;
    for (let lx = -1; lx <= 1; lx++) {
      for (let lz = -1; lz <= 1; lz++) {
        for (let ly = 0; ly <= 1; ly++) {
          const wx = tx + lx, wy = crownY + ly, wz = tz + lz;
          if (inBounds(wx, wy, wz) && getBlockRaw(world, wx, wy, wz) === AIR) {
            setBlockRaw(world, wx, wy, wz, LEAVES);
          }
        }
      }
    }
    setBlockRaw(world, tx, crownY + 2, tz, LEAVES);
    trees.push({ x: tx, z: tz });
  }
  world.trees = trees;
  world.waterLevel = base + 1;
  return world;
}

function index(world, x, y, z) {
  return (z * world.size + x) * world.height + y;
}

export function getBlockRaw(world, x, y, z) {
  if (!inBounds(x, y, z)) return AIR;
  return world.blocks[index(world, x, y, z)];
}

export function setBlockRaw(world, x, y, z, type) {
  if (!inBounds(x, y, z)) return false;
  world.blocks[index(world, x, y, z)] = type;
  return true;
}

// --- Edits (used by gameplay) ---
export function getBlock(world, x, y, z) {
  return getBlockRaw(world, x, y, z);
}

export function setBlock(world, x, y, z, type) {
  if (!isValidBlockType(type) && type !== AIR) return false;
  if (!inBounds(x, y, z)) return false;
  const prev = getBlockRaw(world, x, y, z);
  if (prev === type) return true;
  world.blocks[index(world, x, y, z)] = type;
  world.editCount++;
  return true;
}

export function findSpawn(world) {
  // Find highest solid block at a safe, deterministic spot
  const size = world.size;
  const cx = Math.floor(size / 2);
  let best = null;
  for (let y = world.height - 1; y >= 0; y--) {
    if (getBlockRaw(world, cx, y, cx) !== AIR) { best = y; break; }
  }
  // If the spawn column is under water or missing, scan outward
  if (best === null || getBlockRaw(world, cx, best, cx) === DIRT) {
    outer: for (let r = 1; r < size / 2; r++) {
      for (const [dx, dz] of [[r,0],[0,r],[-r,0],[0,-r],[r,r],[-r,r],[r,-r],[-r,-r]]) {
        const x = cx + dx, z = cx + dz;
        if (!inBounds(x, world.height - 1, z)) continue;
        for (let y = world.height - 1; y >= 0; y--) {
          const t = getBlockRaw(world, x, y, z);
          if (t === GRASS) { return { x: x + 0.5, y: y + 3, z: z + 0.5 }; }
        }
      }
    }
  }
  return { x: cx + 0.5, y: (best ?? 8) + 3, z: cx + 0.5 };
}

// --- Persistence ---
export function serializeState(world, meta = {}) {
  return {
    version: 1,
    seed: world.seed,
    size: world.size,
    height: world.height,
    editCount: world.editCount,
    blocks: Array.from(world.blocks),
    ...meta
  };
}

export function deserializeWorld(data) {
  if (!data || typeof data !== 'object') return null;
  const { size, height, blocks } = data;
  if (!Number.isInteger(size) || !Number.isInteger(height)) return null;
  if (!Array.isArray(blocks) || blocks.length !== size * size * height) return null;
  if (size < 8 || size > 256 || height < 4 || height > 256) return null;
  const world = createWorld(Number(data.seed) || DEFAULT_SEED, size, height);
  let ok = true;
  for (let i = 0; i < blocks.length; i++) {
    const v = blocks[i];
    if (typeof v !== 'number' || !Number.isInteger(v) || v < 0 || v > 5) { ok = false; break; }
    world.blocks[i] = v;
  }
  if (!ok) return null;
  world.editCount = Number(data.editCount) || 0;
  return world;
}

export function saveToStorage(storage, world, meta) {
  try {
    const payload = {
      ...serializeState(world, meta),
      savedAt: Date.now()
    };
    storage.setItem(SAVE_KEY, JSON.stringify(payload));
    return true;
  } catch {
    return false;
  }
}

export function loadFromStorage(storage) {
  try {
    const raw = storage.getItem(SAVE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    return data;
  } catch {
    return null;
  }
}

export function clearSave(storage) {
  try {
    storage.removeItem(SAVE_KEY);
  } catch {}
}
