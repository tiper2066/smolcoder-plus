# Block Meadow

A small, original Minecraft-inspired voxel sandbox built with Three.js and Vite.

## Features

- Seeded, deterministic 64×64 voxel terrain with rolling hills, grass/dirt/stone layers, trees and a lake
- First-person controls with pointer lock, WASD movement, gravity, jump, and axis-separated solid collision
- Block breaking (left click) and placement (right click) within 6-block reach
- 5-slot hotbar (grass, dirt, stone, wood, leaves) selectable via keys 1–5
- Start/pause menu, live FPS counter, crosshair, and target outline
- Save/restore world edits, player position, and selected block to localStorage
- New World with confirmation prompt
- Instanced-mesh rendering for performance
- `window.voxelDebug` API for automated browser verification

## Getting started

```bash
npm install
npm run dev
```

Then open the URL shown in the terminal (typically http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

## Tests

```bash
npm test
```

Runs Node's built-in test runner against world, physics, and raycast modules.

## Controls

| Input | Action |
|---|---|
| W A S D | Move |
| Mouse | Look |
| Space | Jump |
| Left click | Break block |
| Right click | Place block |
| 1–5 | Select block type |
| Shift | Sprint |
| Esc | Pause / release pointer |

## Debug API

```js
window.voxelDebug.snapshot()
// → { player: {x,y,z}, selected: "grass", targeted: {x,y,z} | null, editCount: 0 }

window.voxelDebug.getBlock(x, y, z)  // → block type (0 = air)
window.voxelDebug.teleport(x, y, z)  // → true
```
