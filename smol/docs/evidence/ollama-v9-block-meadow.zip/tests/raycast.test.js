import { test } from 'node:test';
import assert from 'node:assert/strict';
import { raycastVoxel, blockHitsPlayer } from '../src/raycast.js';
import { AIR, STONE } from '../src/blocks.js';

function flatWorld() {
  const size = 8, height = 8;
  const blocks = new Uint8Array(size * size * height);
  for (let x = 0; x < size; x++) for (let z = 0; z < size; z++) blocks[(z * size + x) * height + 0] = STONE;
  return { size, height, blocks };
}

function gb(w) {
  return (x, y, z) => (w.blocks && (x >= 0 && x < w.size && z >= 0 && z < w.size && y >= 0 && y < w.height)
    ? w.blocks[(z * w.size + x) * w.height + y]
    : AIR);
}

test('raycast hits the floor in -Y direction', () => {
  const w = flatWorld();
  const hit = raycastVoxel(gb(w), { x: 4.5, y: 5.5, z: 4.5 }, { x: 0, y: -1, z: 0 }, 10);
  assert.ok(hit, 'should hit floor');
  assert.equal(hit.x, 4);
  assert.equal(hit.y, 0);
  assert.equal(hit.z, 4);
  assert.deepEqual(hit.face, { x: 0, y: 1, z: 0 }, 'normal should be +Y (top face)');
});

test('raycast does not hit through air beyond maxDist', () => {
  const w = flatWorld();
  const hit = raycastVoxel(gb(w), { x: 4.5, y: 5.5, z: 4.5 }, { x: 0, y: 1, z: 0 }, 2);
  assert.equal(hit, null);
});

test('raycast hits side wall with correct normal', () => {
  const w = flatWorld();
  // Put a block at (5, 2, 5)
  w.blocks[(5 * w.size + 5) * w.height + 2] = STONE;
  const hit = raycastVoxel(gb(w), { x: 2.5, y: 2.5, z: 5.5 }, { x: 1, y: 0, z: 0 }, 10);
  assert.ok(hit);
  assert.equal(hit.x, 5);
  assert.equal(hit.y, 2);
  assert.equal(hit.z, 5);
  assert.deepEqual(hit.face, { x: -1, y: 0, z: 0 });
});

test('raycast from inside a solid block returns that block', () => {
  const w = flatWorld();
  const hit = raycastVoxel(gb(w), { x: 4.5, y: 0.5, z: 4.5 }, { x: 1, y: 0, z: 0 }, 10);
  assert.ok(hit);
  assert.equal(hit.y, 0);
});

test('blockHitsPlayer', () => {
  assert.ok(blockHitsPlayer(2.5, 1.0, 2.5, 2, 1, 2));
  assert.ok(!blockHitsPlayer(2.5, 1.0, 2.5, 0, 0, 0));
  assert.ok(!blockHitsPlayer(2.5, 1.0, 2.5, 2, 3, 2), 'above head');
});
