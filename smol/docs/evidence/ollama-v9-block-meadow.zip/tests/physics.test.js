import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createPlayer, stepPlayer, collides, blockIntersectsPlayer, clampDelta, PLAYER } from '../src/physics.js';
import { AIR, STONE } from '../src/blocks.js';

// A minimal world with a flat floor at y=0 and nothing else (open space)
function openWorld() {
  const size = 8, height = 10;
  const blocks = new Uint8Array(size * size * height);
  for (let x = 0; x < size; x++) for (let z = 0; z < size; z++) blocks[(z * size + x) * height + 0] = STONE;
  return { size, height, blocks };
}

function gb(w) {
  return (x, y, z) =>
    x >= 0 && x < w.size && y >= 0 && y < w.height && z >= 0 && z < w.size
      ? (w.blocks[(z * w.size + x) * w.height + y] ?? AIR)
      : AIR;
}

test('clampDelta caps huge frame deltas', () => {
  assert.ok(clampDelta(5) <= 1 / 20);
  assert.ok(clampDelta(-1) === 0);
  assert.equal(clampDelta(0.016), 0.016);
});

test('collides detects player inside a block', () => {
  const w = openWorld();
  assert.ok(collides(gb(w), 0.5, 0, 0.5, 0.3, 1.8), 'inside floor block');
  assert.ok(!collides(gb(w), 0.5, 1, 0.5, 0.3, 1.8), 'standing on floor is fine');
});

test('stepPlayer: falling onto floor sets grounded and rests at surface', () => {
  const w = openWorld();
  const p = createPlayer({ x: 0.5, y: 8, z: 0.5 });
  for (let i = 0; i < 300 && !p.grounded; i++) {
    stepPlayer(p, gb(w), 1 / 60, { forward: 0, strafe: 0, jump: false });
  }
  assert.ok(p.grounded, 'player should land');
  assert.ok(Math.abs(p.y - 1) < 0.001, `should rest at y=1 (got ${p.y})`);
  assert.ok(!collides(gb(w), p.x, p.y, p.z), 'final pos must not collide');
});

test('stepPlayer: jump is ignored when not grounded', () => {
  const w = openWorld();
  const p = createPlayer({ x: 0.5, y: 20, z: 0.5 });
  // player is high up, not grounded
  p.grounded = false;
  const vyBefore = p.vy;
  stepPlayer(p, gb(w), 1 / 60, { forward: 0, strafe: 0, jump: true });
  // Gravity has applied but jump must NOT have boosted upward
  assert.ok(p.vy <= vyBefore, 'jump in air must not add upward velocity');
});

test('stepPlayer: jump adds upward velocity when grounded', () => {
  const w = openWorld();
  const p = createPlayer({ x: 0.5, y: 1, z: 0.5 });
  p.grounded = true;
  p.vy = 0;
  stepPlayer(p, gb(w), 1 / 60, { forward: 0, strafe: 0, jump: true });
  assert.ok(p.vy > 0, 'jump should give upward velocity');
  assert.ok(p.y > 1, 'player should move up');
});

test('stepPlayer: wall blocks horizontal movement (X axis)', () => {
  const w = openWorld();
  // Add a wall at x=4, y=1..3, z=2..5
  for (let y = 1; y <= 3; y++) for (let z = 2; z <= 5; z++) w.blocks[(z * w.size + 4) * w.height + y] = STONE;
  const p = createPlayer({ x: 2.5, y: 2, z: 3.5 });
  p.grounded = false;
  // Drive player into the wall repeatedly
  for (let i = 0; i < 60; i++) {
    p.vx = 30; // force +x movement
    stepPlayer(p, gb(w), 1 / 30, { forward: 0, strafe: 0, jump: false });
    if (collides(gb(w), p.x, p.y, p.z)) break; // we hit the wall
  }
  assert.ok(p.x < 4, `player must not enter wall at x=4 (got x=${p.x.toFixed(3)})`);
  assert.ok(!collides(gb(w), p.x, p.y, p.z), 'final pos must not collide');
});

test('stepPlayer: ceiling blocks upward movement', () => {
  const w = openWorld();
  // Ceiling at y=4 over x=0..3, z=0..3
  for (let x = 0; x < 4; x++) for (let z = 0; z < 4; z++) w.blocks[(z * w.size + x) * w.height + 4] = STONE;
  const p = createPlayer({ x: 0.5, y: 2.2, z: 0.5 });
  p.vy = 50;
  stepPlayer(p, gb(w), 1 / 30, { forward: 0, strafe: 0, jump: false });
  assert.ok(p.y + 1.8 <= 4.001, `head must not poke through ceiling (head at ${(p.y + 1.8).toFixed(3)})`);
  assert.ok(!collides(gb(w), p.x, p.y, p.z));
});

test('huge dt does not launch or bury player (tab-restore guard)', () => {
  const w = openWorld();
  const p = createPlayer({ x: 0.5, y: 5, z: 0.5 });
  // A 5-second frame is clamped to ~0.05s; player should fall a small amount,
  // NOT teleport to y=0 or y=1000, and must not end up inside a block.
  stepPlayer(p, gb(w), 5.0, { forward: 0, strafe: 0, jump: false });
  assert.ok(p.y > 0, `player must not be below ground (y=${p.y})`);
  assert.ok(p.y < 100, `player must not be launched (y=${p.y})`);
  assert.ok(!collides(gb(w), p.x, p.y, p.z), 'must not be inside a block');
});

test('blockIntersectsPlayer: rejects placement inside player body', () => {
  // Player feet at y=1, AABB: x[2.2,2.8] y[1,2.8] z[2.2,2.8]
  assert.ok(blockIntersectsPlayer(2.5, 1.0, 2.5, 2, 1, 2), 'block at (2,1,2) is inside body');
  assert.ok(blockIntersectsPlayer(2.5, 1.0, 2.5, 2, 2, 2), 'block at (2,2,2) is inside body');
  assert.ok(!blockIntersectsPlayer(2.5, 1.0, 2.5, 0, 5, 0), 'far block is outside');
  assert.ok(!blockIntersectsPlayer(2.5, 1.0, 2.5, 2, 3, 2), 'block above head is outside');
  assert.ok(!blockIntersectsPlayer(2.5, 1.0, 2.5, 2, 0, 2), 'block below feet (y=0, player feet at y=1) is outside');
});

test('stepPlayer: horizontal movement works when grounded', () => {
  const w = openWorld();
  const p = createPlayer({ x: 1, y: 1, z: 6 });
  p.grounded = true;
  const zBefore = p.z;
  for (let i = 0; i < 30; i++) {
    stepPlayer(p, gb(w), 1 / 60, { forward: 0, strafe: 1, jump: false });
  }
  assert.ok(p.z !== zBefore, `player should have moved in z (before=${zBefore}, after=${p.z})`);
});
