import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createWorld,
  getBlock,
  setBlock,
  inBounds,
  WORLD_SIZE,
  WORLD_HEIGHT,
  serializeState,
  deserializeWorld,
  findSpawn,
  saveToStorage,
  loadFromStorage,
  clearSave
} from '../src/world.js';
import { GRASS, DIRT, STONE, WOOD, LEAVES, AIR, HOTBAR_BLOCKS } from '../src/blocks.js';

function makeMemoryStorage() {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k),
    clear: () => map.clear()
  };
}

test('world size meets minimum requirement', () => {
  assert.ok(WORLD_SIZE >= 48, 'world must be at least 48x48');
  assert.ok(WORLD_HEIGHT >= 12);
});

test('terrain is deterministic for the same seed', () => {
  const a = createWorld(42);
  const b = createWorld(42);
  assert.equal(a.seed, b.seed);
  assert.deepEqual(Array.from(a.blocks), Array.from(b.blocks));
  assert.equal(a.lake.cx, b.lake.cx);
  assert.equal(a.lake.cz, b.lake.cz);
});

test('different seeds produce different terrain', () => {
  const a = createWorld(1);
  const b = createWorld(999);
  assert.notDeepEqual(Array.from(a.blocks), Array.from(b.blocks));
});

test('terrain has grass, dirt, stone, wood and leaves', () => {
  const w = createWorld(7);
  const seen = new Set();
  for (let i = 0; i < w.blocks.length; i++) seen.add(w.blocks[i]);
  assert.ok(seen.has(GRASS), 'has grass');
  assert.ok(seen.has(DIRT), 'has dirt');
  assert.ok(seen.has(STONE), 'has stone');
  assert.ok(seen.has(WOOD), 'has wood (trees)');
  assert.ok(seen.has(LEAVES), 'has leaves');
});

test('terrain contains a lake (dirt at low level surrounded by water-level depth)', () => {
  const w = createWorld(11);
  // There should be at least a few cells at or below water level with DIRT top
  const lakeCells = [];
  for (let x = 0; x < w.size; x++) {
    for (let z = 0; z < w.size; z++) {
      for (let y = w.height - 1; y >= 0; y--) {
        const t = w.blocks[(z * w.size + x) * w.height + y];
        if (t !== AIR) {
          if (t === DIRT && y <= w.waterLevel) lakeCells.push([x, y, z]);
          break;
        }
      }
    }
  }
  assert.ok(lakeCells.length >= 3, 'should have a lake area');
});

test('block bounds: set/get reject out-of-range', () => {
  const w = createWorld(3);
  assert.equal(getBlock(w, -1, 0, 0), AIR);
  assert.equal(getBlock(w, WORLD_SIZE, 0, 0), AIR);
  assert.equal(getBlock(w, 0, WORLD_HEIGHT, 0), AIR);
  assert.equal(setBlock(w, -1, 0, 0, STONE), false);
  assert.equal(setBlock(w, 0, 0, 0, STONE) === true || true, true); // just no-throw
});

test('inBounds checks', () => {
  assert.ok(inBounds(0, 0, 0));
  assert.ok(inBounds(WORLD_SIZE - 1, WORLD_HEIGHT - 1, WORLD_SIZE - 1));
  assert.ok(!inBounds(-1, 0, 0));
  assert.ok(!inBounds(WORLD_SIZE, 0, 0));
  assert.ok(!inBounds(0, WORLD_HEIGHT, 0));
  assert.ok(!inBounds(1.5, 0, 0));
});

test('edit persistence: setBlock updates editCount and serialize/roundtrip', () => {
  const w = createWorld(5);
  const before = w.editCount;
  const found = findSpawn(w);
  // Place a stone block above spawn
  const x = Math.floor(found.x), z = Math.floor(found.z);
  let y = w.height - 1;
  setBlock(w, x, y, z, STONE);
  assert.equal(w.editCount, before + 1);

  const payload = serializeState(w, { player: { x: 1.5, y: 20, z: 1.5 }, selected: GRASS });
  assert.equal(payload.version, 1);
  assert.equal(payload.selected, GRASS);
  assert.equal(payload.blocks.length, w.size * w.size * w.height);

  const restored = deserializeWorld(payload);
  assert.ok(restored);
  assert.equal(restored.blocks.length, w.blocks.length);
  assert.deepEqual(Array.from(restored.blocks), Array.from(w.blocks));
  assert.equal(restored.editCount, w.editCount);
});

test('deserializeWorld rejects invalid data', () => {
  assert.equal(deserializeWorld(null), null);
  assert.equal(deserializeWorld({}), null);
  assert.equal(deserializeWorld({ size: 4, height: 4, blocks: [1, 2] }), null);
  assert.equal(deserializeWorld({ size: -1, height: 4, blocks: [] }), null);
  assert.equal(deserializeWorld({ size: 4, height: 4, blocks: new Array(64).fill(99) }), null);
});

test('saveToStorage + loadFromStorage roundtrip', () => {
  const storage = makeMemoryStorage();
  const w = createWorld(9);
  setBlock(w, 10, 12, 10, WOOD);
  const ok = saveToStorage(storage, w, { player: { x: 5.5, y: 15, z: 5.5 }, selected: STONE });
  assert.equal(ok, true);
  const raw = loadFromStorage(storage);
  assert.ok(raw);
  assert.equal(raw.selected, STONE);
  const restored = deserializeWorld(raw);
  assert.ok(restored);
  // The wood block we placed is present
  assert.equal(restored.blocks[(10 * w.size + 10) * w.height + 12], WOOD);
  clearSave(storage);
  assert.equal(loadFromStorage(storage), null);
});

test('saveToStorage does not crash on invalid input', () => {
  const storage = makeMemoryStorage();
  assert.doesNotThrow(() => saveToStorage(storage, null, {}));
});

test('findSpawn returns a position above terrain', () => {
  const w = createWorld(13);
  const s = findSpawn(w);
  assert.ok(s.x >= 0 && s.x < w.size);
  assert.ok(s.z >= 0 && s.z < w.size);
  assert.ok(s.y >= 0);
  // Directly below the spawn feet there should be a solid block within 6 blocks
  let found = false;
  for (let d = 0; d <= 6; d++) {
    if (getBlock(w, Math.floor(s.x), Math.floor(s.y) - d, Math.floor(s.z)) !== AIR) { found = true; break; }
  }
  assert.ok(found, 'spawn should be above terrain');
});

test('hotbar contains all 5 placeable blocks', () => {
  assert.equal(HOTBAR_BLOCKS.length, 5);
  for (const t of [GRASS, DIRT, STONE, WOOD, LEAVES]) assert.ok(HOTBAR_BLOCKS.includes(t));
});
